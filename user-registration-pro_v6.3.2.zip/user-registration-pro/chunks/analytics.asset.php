<?php return array('dependencies' => array('react', 'react-dom', 'react-jsx-runtime', 'wp-api-fetch', 'wp-i18n', 'wp-polyfill'), 'version' => '39595d979ef9bc74c048');
