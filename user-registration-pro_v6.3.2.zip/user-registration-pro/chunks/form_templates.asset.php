<?php return array('dependencies' => array('react', 'react-dom', 'react-jsx-runtime', 'wp-api-fetch', 'wp-i18n', 'wp-polyfill'), 'version' => 'be1d22e99e7f1d2bf473');
