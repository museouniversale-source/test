<?php return array('dependencies' => array('react', 'react-dom', 'react-jsx-runtime', 'wp-i18n', 'wp-polyfill'), 'version' => '2d7f951fbfc8fb1b6d43');
