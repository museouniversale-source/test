(function ($) {
  var UR_Stripe_My_Account = {
    init: function () {
      if ("undefined" === typeof window["ur_stripe_params"]) {
        return;
      }

      var ur_stripe_params = window["ur_stripe_params"];

      $(document).on("urm_change_payment_form_toggle", function () {
        var $form = $(".ur-change-payment-container");

        var elements = UR_Stripe_My_Account.setupElements(
          $form,
          ur_stripe_params
        );

        elements.card.addEventListener("change", function (e) {
          if (e.error) {
            if ($form.find("#stripe-errors").length > 0) {
              $form.find("#stripe-errors").html(e.error.message);
            } else {
              if ($form.find("#stripe-errors").length > 0) {
                $form.find("#stripe-errors").remove();
              }
              var error_message =
                '<label id="stripe-errors" class="user-registration-error" role="alert">' +
                e.error.message +
                "</label>";
              $form
                .find(".ur-form-grid .ur-card-information-box")
                .append(error_message);
            }
          } else {
            if ($form.find("#stripe-errors").length > 0) {
              $form.find("#stripe-errors").remove();
            }
          }
        });

        $(document).on("click", "#save_change_payment", function (e) {
          $form = $(".ur-change-payment-container");
          if (
            $form
              .find(".user-registration-change-payment")
              .hasClass("StripeElement--empty")
          ) {
            if ($form.find("#stripe-errors").length > 0) {
              $form
                .find("#stripe-errors")
                .html(user_registration_params.message_required_fields);
            } else {
              var error_message =
                '<label id="stripe-errors" class="user-registration-error" role="alert">' +
                user_registration_params.message_required_fields +
                "</label>";
              $form
                .find(".ur-form-grid .ur-card-information-box")
                .append(error_message);
            }
            return false;
          }

          if (
            $form
              .find(".ur-stripe-element-active")
              .hasClass("StripeElement--invalid")
          ) {
            return false;
          }
          $(this).prop("disabled", true);
          $form
            .find(".user-registration-save-change-payment")
            .find("span")
            .addClass("ur-front-spinner");
          elements.stripe
            .createPaymentMethod({
              type: "card",
              card: elements.card,
            })
            .then(function (result) {
              // Handle result.error or result.paymentMethod
              if (undefined !== result.paymentMethod) {
                $.ajax({
                  url: ur_stripe_params.ajax_url,
                  method: "POST",
                  data: {
                    action: "ur_stripe_update_customer_payment",
                    security: ur_stripe_params.payment_nonce,
                    paymentMethod: result.paymentMethod,
                  },
                }).done(function (result) {
                  Swal.fire({
                    icon: "success",
                    title: ur_stripe_params.change_payment_message,
                    customClass:
                      "user-registration-swal2-modal user-registration-swal2-modal--center",
                    showConfirmButton: false,
                    timer: 2000,
                  }).then(function (result) {
                    window.location.reload();
                  });
                });
              }
            });
        });
      });

      $("#ur_change_payment").on("click", function (e) {
        e.preventDefault();
        $(".ur-account-table-container").hide();
        var html = '<div class="ur-change-payment-container">';
        html +=
          '<div class="ur-frontend-form change-payment" id="ur-frontend-form">';
        html += '<div class="ur-form-row">';
        html += '<div class="ur-form-grid">';
        html += '<div class="ur-change-payment-title">';
        html += "<label>" + ur_stripe_params.change_payment_title + "</label>";
        html += "</div>";
        html += '<div  class="ur-card-information-box">';
        html +=
          '<label class="ur-change-payment-label">' +
          ur_stripe_params.change_payment_card_info +
          "</label>";
        html += '<div class="user-registration-change-payment">';
        html += "</div>";
        html += "</div>";
        html += '<div class="clear"></div>';
        html += '<div class="user-registration-save-change-payment">';
        html +=
          '<input type="hidden" id="user-registration-login-nonce" name="user-registration-login-nonce" value="' +
          ur_stripe_params.change_payment_nonce +
          '">';
        html += "<span></span>";
        html +=
          '<input type="button" class="save_change_payment" id="save_change_payment" value="Update" />';
        html += "</div>";
        html += "</div>";
        html += "</div>";
        html += "</div>";
        html += "</div>";

        $(".ur-account-table-container").parent().append(html);
        $(window).scrollTop($(".ur-change-payment-container").offset().top);
        $(document).trigger("urm_change_payment_form_toggle");
      });

      $("#ur_cancel_payment").on("click", function (e) {
        e.preventDefault();
        var $cancel_url = $(this).attr("href");
        var title =
          '<span class="user-registration-swal2-modal__title">' +
          ur_stripe_params.cancel_subscription_title;

        swal.fire({
          title: title,
          html: ur_stripe_params.cancel_subscription_html,
          confirmButtonText: ur_stripe_params.cancel_subscription_button_text,
          confirmButtonColor: "#FF4149",
          showConfirmButton: true,
          showCancelButton: true,
          cancelButtonText: ur_stripe_params.cancel_button_text,
          customClass: {
            container: "user-registration-swal2-container",
          },
          focusConfirm: false,
          showLoaderOnConfirm: true,
          preConfirm: function () {
            Swal.fire({
              icon: "success",
              title: ur_stripe_params.cancel_subscription_success_button_text,
              customClass:
                "user-registration-swal2-modal user-registration-swal2-modal--center",
              showConfirmButton: false,
              timer: 2000,
            });
            window.location.href = $cancel_url;
          },
        });
        return false;
      });
    },
    /**
     * Set up Stripe.js and Elements to use in checkout form.
     *
     * @param {object} form Forms.
     * @param {object} data Forms stripe information.
     *
     * @return object Stripe, Card and client secret.
     */
    setupElements: function (form, data) {
      var stripe = Stripe(data.publishable_key);

      // Instance of Elements.
      var elements = stripe.elements();

      // Custom styling.
      var style = {
        base: {
          color: "#32325d",
          fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
          fontSmoothing: "antialiased",
          fontSize: "14px",
          "::placeholder": {
            color: "#8f9194",
          },
        },
        invalid: {
          color: "#fa755a",
          iconColor: "#fa755a",
        },
      };

      var card = elements.create("card", {
        style: style,
      });

      var $card_input = $(".user-registration-change-payment");

      if ($card_input.length > 0) {
        card.mount($card_input.get(0));
      }
      return {
        stripe: stripe,
        card: card,
        clientSecret: "",
      };
    },
  };

  $(document).ready(function () {
    UR_Stripe_My_Account.init();
  });
})(jQuery);
