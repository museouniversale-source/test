/* global  user_registration_params */
/* global  ur_stripe_params */
/**
 * Script to handle payment options for stripe.
 *
 * @since 1.0.0
 */
(function ($) {
  var UR_Stripe = {
    elements: {},
    init: function () {
      var stripeForms = $("[data-gateway*='stripe']");
      if (stripeForms.length === 0) {
        return;
      }

      UR_Stripe.init_stripe_elements();
      UR_Stripe.append_data_before_form_submit();
      UR_Stripe.start_payment_process();
      UR_Stripe.check_ideal_response();
    },
    /**
     * Start stripe payment process.
     */
    start_payment_process: function () {
      $(document).on(
        "user_registration_frontend_before_form_submit",
        function (event, data, $this, $error_message) {
          var $stripe_fields = $($this)
            .closest(".ur-frontend-form")
            .find(".field-stripe_gateway")
            .is(":hidden");
          if (true === $stripe_fields) {
            return;
          }
          var is_empty = $($this)
            .closest(".ur-frontend-form")
            .find(".field-stripe_gateway .StripeElement--empty").length;

          if (0 < is_empty) {
            $error_message.message = ur_stripe_params.empty_card_details;
          }
        },
      );

      $(document).on(
        "user_registration_frontend_before_ajax_complete_success_message",
        function (event, ajax_response, ajaxFlag, form) {
          var flag = true;
          var $stripe_fields = $(".ur-frontend-form").find(
            ".field-stripe_gateway",
          ).length;

          var $stripe_hidden = -1;
          var $urcl_hide_fields = $("#urcl_hide_fields").val();

          if (
            typeof $urcl_hide_fields !== "undefined" &&
            "" !== $urcl_hide_fields
          ) {
            var $urcl_hide_fields_array = JSON.parse($urcl_hide_fields);
            $stripe_hidden = $.inArray(
              "stripe_gateway",
              $urcl_hide_fields_array,
            );
          }

          if (!$stripe_fields || $stripe_hidden !== -1) {
            return;
          }
          try {
            var $registration_form = $(form);
            var response = JSON.parse(ajax_response.responseText);
            if (
              typeof response.success !== "undefined" &&
              response.success === true
            ) {
              $registration_form
                .find(".ur-submit-button")
                .prop("disabled", true);

              if (
                "undefined" === typeof response.data.payment_process ||
                false === response.data.payment_process
              ) {
                return;
              }
              flag = false;

              var paymentMethodButton = $registration_form.find(
                ".ur-stripe-element-selected",
              );
              var paymentMethod = $(paymentMethodButton).attr("id");
              if (!ur_stripe_params.recurring || "ideal" === paymentMethod) {
                UR_Stripe.handleOneTimePayment(
                  $registration_form,
                  response.data,
                );
              } else {
                UR_Stripe.handleRecurringPayment(
                  $registration_form,
                  response.data,
                );
              }
            }
          } catch (e) {
            console.log(e.message);
          }
          ajaxFlag["status"] = flag;
        },
      );
    },
    /**
     * handle OneTime Payment.
     */
    handleOneTimePayment: function ($registration_form, response_data) {
      var paymentMethodButton = $registration_form.find(
        ".ur-stripe-element-selected",
      );
      var paymentMethod = $(paymentMethodButton).attr("id");

      if ("credit_card" === paymentMethod) {
        UR_Stripe.payWithCard($registration_form, response_data);
      } else {
        UR_Stripe.payWithIdeal($registration_form, response_data);
      }
    },
    /**
     * Card Payment.
     */
    payWithCard: function ($registration_form, response_data) {
      UR_Stripe.elements.stripe
        .confirmCardPayment(response_data.clientSecret, {
          payment_method: {
            card: UR_Stripe.elements.card,
          },
        })
        .then(function (result) {
          $.ajax({
            url: ur_stripe_params.ajax_url,
            method: "POST",
            data: {
              action: "ur_stripe_update_user_payment_status",
              payment_result: result,
              payment_method: "card",
              payment_status: result.error ? "failed" : "succeeded",
              user_id: response_data.user_id,
              _wpnonce: ur_stripe_params.payment_nonce,
            },
          }).done(function (response) {
            var data = {
              user_id: response_data.user_id,
              form_id: response_data.form_id,
              response_data: response_data,
            };
            if (result.error) {
              var error = "";
              if (undefined !== result.error.message) {
                error = result.error.message;
              }

              // Show error to your customer
              UR_Stripe.error_message(error, data);
            } else {
              // The payment has been processed!
              UR_Stripe.success_message(data);
            }
          });
        });
    },
    /**
     * iDeal Payment.
     */
    payWithIdeal: function ($registration_form, response_data) {
      var redirect_uri = new URL(window.location.href);
      redirect_uri.searchParams.set("form_id", response_data.form_id);
      redirect_uri.searchParams.append("user_id", response_data.user_id);
      localStorage.setItem(
        "ur_stripe_form_with_ideal_response",
        JSON.stringify(response_data),
      );
      UR_Stripe.elements.stripe
        .confirmIdealPayment(
          response_data.clientSecret,
          {
            payment_method: {
              ideal: UR_Stripe.elements.ideal,
            },
            return_url: redirect_uri,
          },
          {
            handleActions: true,
          } /** Set false If we don't want the ideal confirmation popup */,
        )
        .then(function (result) {
          var data = {
            user_id: response_data.user_id,
            form_id: response_data.form_id,
            response_data: response_data,
          };
          if (result.error) {
            var error = "";
            if (undefined !== result.error.message) {
              error = result.error.message;
            }

            // Show error to your customer
            UR_Stripe.error_message(error, data);
          } else {
            // The payment has been processed!
            UR_Stripe.success_message(data);
          }
        });
    },
    /**
     * handle Recurring Payment.
     */
    handleRecurringPayment: function ($registration_form, response_data) {
      var customer_details = JSON.parse(
        ur_stripe_params.customer_details_fields,
      );
      var customer_data = {};

      if (0 < Object.keys(customer_details).length) {
        $.each(customer_details, function (index, value) {
          if ($.isArray(value)) {
            var full_name = "";

            $.each(value, function (key, field) {
              full_name =
                full_name +
                " " +
                $registration_form.find("[data-id='" + field + "']").val();
            });
            customer_data[index] = full_name;
          } else {
            value = "" !== value ?
              $registration_form.find("[data-id='" + value + "']").val() :
              "";
            customer_data[index] = value;
          }
        });
      }
      UR_Stripe.processSubscription($registration_form, {
        paymentElements: UR_Stripe.elements,
        user_id: response_data.user_id,
        form_id: response_data.form_id,
        customer_data: customer_data,
        response_data: response_data,
      });
    },
    /**
     * Pull a human-readable message out of a WP AJAX or Stripe-shaped response.
     *
     * @param {object|string} result Parsed AJAX body or thrown value.
     * @return {string}
     */
    extractAjaxError: function (result) {
      if (!result) {
        return "Unable to complete the payment.";
      }

      if ("string" === typeof result) {
        return result;
      }

      if (result.error && result.error.message) {
        return result.error.message;
      }

      if (result.data) {
        if ("string" === typeof result.data) {
          return result.data;
        }
        if (result.data.message) {
          return result.data.message;
        }
      }

      if (result.message) {
        return result.message;
      }

      return "Unable to complete the payment.";
    },

    /**
     * Process Subscription Payment.
     * @param {mixed} $registration_form
     * @param {object} data
     */
    processSubscription: function ($registration_form, data) {
      // Create customer.
      $.ajax({
        url: ur_stripe_params.ajax_url,
        method: "POST",
        data: {
          action: "ur_stripe_create_customer",
          user_id: data.user_id,
          security: ur_stripe_params.payment_nonce,
          customer_data: data.customer_data,
          form_id: data.form_id,
        },
      })
        .then(function (result) {
          // WP AJAX uses { success: false, data: ... }, not Stripe's { error: ... }.
          if (!result || false === result.success || result.error) {
            throw result;
          }

          if (!result.data || !result.data.customer) {
            throw result;
          }

          return $.extend({}, data, {
            customerId: result.data.customer.id,
          });
        })
        .then(UR_Stripe.createPaymentMethod)
        .then(UR_Stripe.createSubscription)
        .then(UR_Stripe.handleCustmerActionRequried)
        .then(UR_Stripe.handleOnComplete)
        .fail(function (error, data) {
          $.ajax({
            url: ur_stripe_params.ajax_url,
            method: "POST",
            data: {
              action: "ur_stripe_update_user_payment_status",
              payment_result: error,
              payment_method: "card",
              payment_status: "failed",
              user_id: data ? data.user_id : 0,
              _wpnonce: ur_stripe_params.payment_nonce,
            },
          });

          if (error && undefined !== error.responseText) {
            try {
              error = JSON.parse(error.responseText);
              error = error.data;
            } catch (e) {
              // Keep the original error if responseText is not JSON.
            }
          } else if (error && "object" === typeof error) {
            error = UR_Stripe.extractAjaxError(error);
          }
          UR_Stripe.error_message(error, data);
        });
    },

    /**
     * Create payment method.
     *
     * @param {object} data Contains Stripe, card, formid, paymentItems, current form selector and customerId.
     */
    createPaymentMethod: function (data) {
      var dfd = $.Deferred();
      var paymentMethodData = {
        type: "card",
        card: data.paymentElements.card,
      };

      // Create payment method.
      data.paymentElements.stripe
        .createPaymentMethod(paymentMethodData)
        .then(function (result) {
          if (result.error) {
            dfd.reject(result, data);
            return;
          }

          dfd.resolve(
            $.extend({}, data, {
              paymentMethodId: result.paymentMethod.id,
            }),
          );
        })
        .catch(function (error) {
          dfd.reject(error, data);
        });

      return dfd;
    },

    /**
     * Create subscription.
     *
     * @param {object} dataContains Stripe, card, formid, paymentItems, current form selector, customerId and paymentMethodId.
     */
    createSubscription: function (data) {
      var dfd = $.Deferred();
      var ur_stripe_params = window["ur_stripe_params"];
      $.ajax({
        url: ur_stripe_params.ajax_url,
        method: "POST",
        data: {
          action: "ur_stripe_create_subscription",
          security: ur_stripe_params.payment_nonce,
          user_id: data.user_id,
          payment_method_id: data.paymentMethodId,
          form_id: data.form_id,
        },
      })
        .done(function (result) {
          var message;
          var paymentIntent;

          // WP AJAX errors arrive here as HTTP 200 with success:false — not as result.error.
          if (!result || false === result.success || result.error) {
            message = UR_Stripe.extractAjaxError(result);
            dfd.reject(message, data);
            return;
          }

          if (!result.data || !result.data.subscription) {
            message = UR_Stripe.extractAjaxError(result);
            dfd.reject(message, data);
            return;
          }

          paymentIntent = result.data.payment_intent || null;

          if ("trialing" !== result.data.subscription.status) {
            if (
              paymentIntent &&
              "requires_payment_method" === paymentIntent.status
            ) {
              message = "Your card was declined";
              dfd.reject(message, data);
              return;
            }
          }

          $.ajax({
            url: ur_stripe_params.ajax_url,
            method: "POST",
            data: {
              action: "ur_stripe_update_user_payment_status",
              payment_result: result,
              payment_method: "card",
              payment_status: result.error ? "failed" : "succeeded",
              user_id: data.user_id,
              _wpnonce: ur_stripe_params.payment_nonce,
            },
          }).done(function (response) {
            if (result.error) {
              var error = "";
              if (undefined !== result.error.message) {
                error = result.error.message;
              }

              // Show error to your customer
              UR_Stripe.error_message(error, data);
            } else {
              // The payment has been processed!
              UR_Stripe.success_message(data);
            }
          });

          return dfd.resolve(
            $.extend({}, data, {
              subscription: result.data.subscription,
              payment_intent: result.data.payment_intent || null,
            }),
          );
        })
        .fail(function (error) {
          if (error && undefined !== error.responseText) {
            try {
              error = JSON.parse(error.responseText);
              error = error.data;
            } catch (e) {
              // Keep the original error if responseText is not JSON.
            }
          } else if (error && "object" === typeof error) {
            error = UR_Stripe.extractAjaxError(error);
          }
          UR_Stripe.error_message(error, data);
          dfd.reject(error, data);
        });

      return dfd;
    },

    /**
     * Handle customer action if it is required.
     *
     * @param {object} data Contains stripe, card, formid, paymentItems, form_selector, customerId, paymentMethodId and subscription.
     *
     */
    handleCustmerActionRequried: function (data) {
      var dfd = $.Deferred();
      if (
        data.subscription &&
        (data.subscription.status === "active" ||
          data.subscription.status === "trialing")
      ) {
        dfd.resolve({
          subscription: data.subscription,
          form_id: data.form_id,
          response_data: data.response_data,
        });
        return dfd;
      }

      var paymentIntent = data.payment_intent || null;

      if (
        data.subscription &&
        "trialing" !== data.subscription.status &&
        paymentIntent &&
        "requires_action" === paymentIntent.status
      ) {
          data.paymentElements.stripe
            .confirmCardPayment(paymentIntent.client_secret, {
              payment_method: data.paymentMethodId,
            })
            .then(function (result) {
              var message;
              if (result.error) {
                message = result.error.message;
                dfd.reject(message, data);
                return;
              }

              if ("succeeded" === result.paymentIntent.status) {
                data.subscription.status = "active";
                dfd.resolve({
                  subscription: data.subscription,
                  form_id: data.form_id,
                  response_data: data.response_data,
                });
              } else {
                message = "Unable to complete the payment.";
                dfd.reject(message, data);
              }
            });
      } else if (!data.subscription) {
        dfd.reject("Unable to complete the payment.", data);
      }

      return dfd;
    },

    /**
     * Handle subscription complete.
     *
     * @param {object} data  Contains stripe, card, formid, paymentItems, form_selector, customerId, paymentMethodId and subscription.
     */
    handleOnComplete: function (data) {
      //   var subscriptionId = data.subscription.id;
      //   var paymentIntentId = data.subscription.latest_invoice.payment_intent.id;
      if (
        data.subscription &&
        (data.subscription.status === "active" ||
          data.subscription.status === "trialing")
      ) {
        UR_Stripe.success_message(data);
      }
    },
    /**
     * Send data to $_POST
     */
    append_data_before_form_submit: function () {
      $(document).on(
        "user_registration_frontend_validate_before_form_submit",
        function (event, pointer) {
          if (
            $(pointer)
              .find(".ur-stripe-element-active")
              .hasClass("StripeElement--empty")
          ) {
            if ($(pointer).find("#stripe-errors").length === 0) {
              var error_message =
                '<label id="stripe-errors" class="user-registration-error" role="alert">' +
                user_registration_params.message_required_fields +
                "</label>";
              $(pointer)
                .find(".ur-stripe-element-active")
                .append(error_message);
            }
          }
        },
      );

      $(document).on(
        "user_registration_frontend_before_form_submit",
        function (event, data, pointer, $error_message) {
          var paymentMethodButton = $(pointer).find(
            ".ur-stripe-element-selected",
          );
          var paymentMethod = $(paymentMethodButton).attr("id");
          data["ur_stripe_payment_method"] = paymentMethod;
        },
      );
    },
    /**
     * Handles credit card validation and stripe payment process while registration.
     */
    init_stripe_elements: function () {
      $(".ur-frontend-form").each(function () {
        var $registration_form = $(this);
        var form_id = $registration_form.find("form.register").data("form-id");

        if ("undefined" === typeof form_id) {
          return;
        }

        if ("undefined" === typeof window["ur_stripe_params"]) {
          return;
        }

        var ur_stripe_params = window["ur_stripe_params"];

        if (
          ur_stripe_params.enabled_gateways.stripe !== "1" &&
          "undefined" !== typeof ur_stripe_params.enabled_gateways.stripe
        ) {
          return;
        }

        if ($registration_form.find(".ur-tab-button").length > 1) {
          UR_Stripe.hideElement($registration_form, "ideal");
          UR_Stripe.showElement($registration_form, "credit_card");
        } else {
          if ($registration_form.find("#credit_card").length < 1) {
            $registration_form
              .find("#ideal")
              .addClass("ur-stripe-element-selected");
          }
        }
        $registration_form
          .find(".ur-tab-button")
          .each(function ($key, $button) {
            var id = $($button).attr("id");
            if (id === "credit_card") {
              $registration_form
                .find("#" + id)
                .addClass("ur-stripe-element-selected");
            }
            $($button).on("click", function (evt) {
              evt.preventDefault();
              if (id === "credit_card") {
                if ($registration_form.find("#stripe-errors").length > 0) {
                  $registration_form.find("#stripe-errors").remove();
                  UR_Stripe.elements.card.clear();
                }
                UR_Stripe.showElement($registration_form, id);
                UR_Stripe.hideElement($registration_form, "ideal");
                $registration_form
                  .find("#" + id)
                  .addClass("ur-stripe-element-selected");
                $registration_form
                  .find("#ideal")
                  .removeClass("ur-stripe-element-selected");
              } else {
                if ($registration_form.find("#stripe-errors").length > 0) {
                  $registration_form.find("#stripe-errors").remove();
                  UR_Stripe.elements.card.clear();
                }
                UR_Stripe.hideElement($registration_form, "credit_card");
                UR_Stripe.showElement($registration_form, id);
                $registration_form
                  .find("#" + id)
                  .addClass("ur-stripe-element-selected");
                $registration_form
                  .find("#credit_card")
                  .removeClass("ur-stripe-element-selected");
              }
            });
          });

        var elements = UR_Stripe.setupElements(this, ur_stripe_params);

        elements.card.addEventListener("change", function (e) {
          if (e.error) {
            if ($registration_form.find("#stripe-errors").length > 0) {
              $registration_form.find("#stripe-errors").html(e.error.message);
            } else {
              var error_message =
                '<label id="stripe-errors" class="user-registration-error" role="alert">' +
                e.error.message +
                "</label>";
              $registration_form.find(".ur-tab-content").append(error_message);
            }
          } else {
            if ($registration_form.find("#stripe-errors").length > 0) {
              $registration_form.find("#stripe-errors").remove();
            }
          }
        });

        UR_Stripe.elements = elements;
      });
    },
    /**
     * Show Selected Payment Method Element.
     * @param {selector} $registration_form
     * @param {string} id
     */
    showElement: function ($registration_form, id) {
      $registration_form
        .find('[data-id="' + id + '"]')
        .removeClass("ur-stripe-element-hidden");
      $registration_form
        .find('[data-id="' + id + '"]')
        .addClass("ur-stripe-element-active");
    },

    /**
     * Hide Unselected Payment Method Element.
     * @param {selector} $registration_form
     * @param {string} id
     */
    hideElement: function ($registration_form, id) {
      $registration_form
        .find('[data-id="' + id + '"]')
        .addClass("ur-stripe-element-hidden");
      $registration_form
        .find('[data-id="' + id + '"]')
        .removeClass("ur-stripe-element-active");
    },
    /**
     * Set up Stripe.js and Elements to use in checkout form.
     *
     * @param {object} form Forms.
     * @param {object} data Forms stripe information.
     *
     * @return object Stripe, Card and client secret.
     */
    setupElements: function (form, data) {
      var stripe = Stripe(data.publishable_key);

      // Instance of Elements.
      var elements = stripe.elements();

      // Custom styling.
      var style = {
        base: {
          color: "#32325d",
          fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
          fontSmoothing: "antialiased",
          fontSize: "14px",
          "::placeholder": {
            color: "#8f9194",
          },
        },
        invalid: {
          color: "#fa755a",
          iconColor: "#fa755a",
        },
      };

      var card = elements.create("card", {
        style: style,
        hidePostalCode:
          data.urm_hide_stripe_card_postal_code === "1" ? true : false,
      });

      var idealBank = elements.create("idealBank", { style: style });

      var $card_input = $(form).find('[data-id="credit_card"]');
      if ($card_input.length > 0) {
        card.mount($card_input.get(0));
      }
      var $ideal_input = $(form).find('[data-id="ideal"]');
      if ($ideal_input.length > 0) {
        idealBank.mount($ideal_input.get(0));
      }
      return {
        stripe: stripe,
        card: card,
        ideal: idealBank,
        clientSecret: "",
      };
    },
    /**
     * Perform and throw success/error message according to login option.
     * @param {*} message
     * @param {*} type
     * @param {*} $submit_node
     * @param {*} position
     */
    show_message: function (message, type, $submit_node, position) {
      $submit_node.closest(".user-registration").find(".ur-message").remove();

      // Check if the form is edit-profile form.
      var wrapper;
      if (
        $(".ur-frontend-form")
          .find("form.edit-profile")
          .hasClass("user-registration-EditProfileForm")
      ) {
        wrapper = $('<div class="user-registration-' + type + '"/>');
        wrapper.append(message);
        var my_account_selector = $(".user-registration").find(
          ".user-registration-MyAccount-navigation",
        );
        if (my_account_selector.length) {
          wrapper.insertBefore(".user-registration-MyAccount-navigation");
        } else {
          wrapper.insertBefore(".ur-frontend-form");
        }
      } else {
        wrapper = $(
          '<div class="ur-message user-registration-' +
            type +
            '" id="ur-submit-message-node"/>',
        );
        wrapper.append(message);

        // Check the position set by the admin and append message accordingly.
        if ("1" === position) {
          $submit_node.append(wrapper);
          $(window).scrollTop(
            $submit_node.find(".ur-button-container").offset().top,
          );
        } else {
          $submit_node.prepend(wrapper);
          $(window).scrollTop(
            $submit_node.closest(".ur-frontend-form").offset().top,
          );
        }
      }

      $(document).trigger("user_registration_frontend_after_ajax_complete", [
        message,
        type,
        $submit_node,
      ]);
      $submit_node.find(".ur-submit-button").prop("disabled", false);
    },
    /**
     * Perform Success Operation and throw success message.
     * @param {*} data
     */
    success_message: function (data) {
      var ursL10n = user_registration_params.ursL10n;
      var $registration_form = $("#user-registration-form-" + data.form_id);
      /**
       * Remove Spinner.
       */
      $registration_form
        .find(".ur-submit-button")
        .find("span")
        .removeClass("ur-front-spinner");

      var response_data = data.response_data;

      var message = $('<ul class=""/>');
      var success_message_position = response_data.success_message_positon;

      /**
       * Append Success Message according to login option.
       */
      if (response_data.form_login_option === "admin_approval") {
        message.append("<li>" + ursL10n.user_under_approval + "</li>");
      } else if (
        response_data.form_login_option === "email_confirmation" ||
        response_data.form_login_option ===
          "admin_approval_after_email_confirmation"
      ) {
        message.append("<li>" + ursL10n.user_email_pending + "</li>");
      } else {
        message.append("<li>" + ursL10n.user_successfully_saved + "</li>");
      }
      if (
        "undefined" !==
        typeof response_data.auto_password_generation_success_message
      ) {
        message.append(
          "<li>" +
            response_data.auto_password_generation_success_message +
            "</li>",
        );
      }

      var redirect_url = "";
      if ("undefined" !== typeof response_data.role_based_redirect_url) {
        redirect_url = response_data.role_based_redirect_url;
      }
      if ("undefined" !== typeof response_data.redirect_url) {
        redirect_url = response_data.redirect_url;
      }

      if ("undefined" !== typeof redirect_url && redirect_url !== "") {
        window.setTimeout(function () {
          window.location = redirect_url;
        }, 1000);
      } else {
        if (
          typeof response_data.auto_login !== "undefined" &&
          response_data.auto_login
        ) {
          location.reload();
        }
      }

      $registration_form.find("form")[0].reset();
      $registration_form.find(".ur-total-amount").each(function () {
        if (
          "hidden" === $(this).attr("type") ||
          "text" === $(this).attr("type")
        ) {
          $(this).val("0");
        } else {
          $(this).text("0");
        }
      });

      jQuery("#billing_country").trigger("change");
      jQuery("#shipping_country").trigger("change");
      UR_Stripe.setupElements($registration_form, ur_stripe_params);
      UR_Stripe.show_message(
        message,
        "message",
        $registration_form.find("form"),
        success_message_position,
      );
    },
    /**
     * Throw Error message.
     * @param {*} error
     * @param {*} data
     */
    error_message: function (error, data) {
      if (undefined !== typeof data.response_data.success_message_position) {
        UR_Stripe.show_message(
          error,
          "error",
          $("#user-registration-form-" + data.form_id),
          data.response_data.success_message_position,
        );
      } else {
        if ($("#stripe-errors").length > 0) {
          $("#stripe-errors").html(error);
          $("#stripe-errors").css("display", "");
        } else {
          var error_message =
            '<label id="stripe-errors" class="user-registration-error" role="alert">' +
            error +
            "</label>";
          $("#user-registration-form-" + data.form_id)
            .find(".ur-tab-content")
            .append(error_message);
        }
      }
      $("#user-registration-form-" + data.form_id)
        .find(".ur-submit-button")
        .find("span")
        .removeClass("ur-front-spinner");
    },
    /**
     * Check iDeal Response.
     */
    check_ideal_response: function () {
      if (null === localStorage.getItem("ur_stripe_form_with_ideal_response")) {
        // nothing goes here;
      } else {
        if (
          (typeof UR_Stripe.getUrlVars()["payment_intent"] !== "undefined" ||
            UR_Stripe.getUrlVars()["payment_intent"] !== null) &&
          (typeof UR_Stripe.getUrlVars()["payment_intent_client_secret"] !==
            "undefined" ||
            UR_Stripe.getUrlVars()["payment_intent_client_secret"] !== null) &&
          (typeof UR_Stripe.getUrlVars()["redirect_status"] !== "undefined" ||
            UR_Stripe.getUrlVars()["redirect_status"] !== null) &&
          (typeof UR_Stripe.getUrlVars()["user_id"] !== "undefined" ||
            UR_Stripe.getUrlVars()["user_id"] !== null) &&
          (typeof UR_Stripe.getUrlVars()["form_id"] !== "undefined" ||
            UR_Stripe.getUrlVars()["form_id"] !== null)
        ) {
          var payment_intent = UR_Stripe.getUrlVars()["payment_intent"];
          var redirect_status = UR_Stripe.getUrlVars()["redirect_status"];
          var user_id = UR_Stripe.getUrlVars()["user_id"];

          var stripe_response = JSON.parse(
            localStorage.getItem("ur_stripe_form_with_ideal_response"),
          );

          if ("" !== stripe_response) {
            $.ajax({
              url: ur_stripe_params.ajax_url,
              method: "POST",
              data: {
                action: "ur_stripe_update_user_payment_status",
                payment_method: "ideal",
                payment_intent: payment_intent,
                payment_status: redirect_status,
                user_id: user_id,
                _wpnonce: ur_stripe_params.payment_nonce,
              },
            }).done(function (response) {
              var data = {
                user_id: stripe_response.user_id,
                form_id: stripe_response.form_id,
                response_data: stripe_response,
              };

              if (
                typeof response.success !== "undefined" &&
                response.success === true
              ) {
                // The payment has been processed!
                UR_Stripe.success_message(data);
              } else {
                var error = "";
                if (undefined !== response.data.message) {
                  error = response.data.message;
                }
                // Show error to your customer
                UR_Stripe.error_message(error, data);
              }
            });
          }
        }
        localStorage.removeItem("ur_stripe_form_with_ideal_response");
      }
    },
    /**
     * Get Query String after return from ideal payment gateway.
     *
     * @returns
     */
    getUrlVars: function () {
      var vars = [],
        hash;
      var hashes = window.location.href
        .slice(window.location.href.indexOf("?") + 1)
        .split("&");
      for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split("=");
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
      }
      return vars;
    },
  };

  $(document).ready(function () {
    UR_Stripe.init();
  });
})(jQuery);
