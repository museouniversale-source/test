/* global  user_registration_params */

(function ($) {
  var UR_Stripe_Login = {
    elements: {},
    init: function () {
      if ("undefined" === typeof window["ur_stripe_login_params"]) {
        return;
      }

      var ur_stripe_login_params = window["ur_stripe_login_params"];

      $("#ur_stripe_resubscribe").on("click", function () {
        var flag = false;

        swal
          .fire({
            html: ur_stripe_login_params.resubscribe_html,
            confirmButtonText: ur_stripe_login_params.resubscribe_button_text,
            confirmButtonColor: "#FF4149",
            showConfirmButton: true,
            showCancelButton: true,
            cancelButtonText: ur_stripe_login_params.cancel_button_text,
            customClass: {
              container: "user-registration-swal2-container",
            },
            focusConfirm: false,
            allowOutsideClick: false,
            allowEscapeKey: false,
            showLoaderOnConfirm: true,
            didOpen: function () {
              var $form = $("#ur-stripe-payment-box");
              UR_Stripe_Login.elements = UR_Stripe_Login.setupElements(
                $form,
                ur_stripe_login_params
              );
              UR_Stripe_Login.elements.card.addEventListener(
                "change",
                function (e) {
                  $form = $("#ur-stripe-payment-box");
                  if (e.error) {
                    if ($form.find("#stripe-errors").length > 0) {
                      $form.find("#stripe-errors").html(e.error.message);
                    } else {
                      if ($form.find("#stripe-errors").length > 0) {
                        $form.find("#stripe-errors").remove();
                      }
                      var error_message =
                        '<label id="stripe-errors" class="user-registration-error" role="alert">' +
                        e.error.message +
                        "</label>";
                      $form.find("#card-element").append(error_message);
                    }
                  } else {
                    if ($form.find("#stripe-errors").length > 0) {
                      $form.find("#stripe-errors").remove();
                    }
                  }
                }
              );
            },
            preConfirm: function () {
              return new Promise(function (resolve, reject) {
                swal.showLoading();

                var $form = $("#ur-stripe-payment-box");
                if (
                  $form.find("#card-element").hasClass("StripeElement--empty")
                ) {
                  if ($form.find("#stripe-errors").length > 0) {
                    $form
                      .find("#stripe-errors")
                      .html(user_registration_params.message_required_fields);
                  } else {
                    var error_message =
                      '<label id="stripe-errors" class="user-registration-error" role="alert">' +
                      user_registration_params.message_required_fields +
                      "</label>";
                    $form.find("#card-element").append(error_message);
                  }
                  swal.hideLoading();
                  reject();
                  return;
                }

                if (
                  $form.find("#card-element").hasClass("StripeElement--invalid")
                ) {
                  swal.hideLoading();
                  reject();
                  return;
                }

                var user_id = $("#ur_stripe_resubscribe").data("uid");

                /**lOADER */
                UR_Stripe_Login.elements.stripe
                  .createPaymentMethod({
                    type: "card",
                    card: UR_Stripe_Login.elements.card,
                  })
                  .then(function (result) {
                    // Handle result.error or result.paymentMethod
                    if (undefined !== result.paymentMethod) {
                      $.ajax({
                        url: ur_stripe_login_params.ajax_url,
                        method: "POST",
                        data: {
                          action: "ur_stripe_resubscribe_payment",
                          security: ur_stripe_login_params.resubscribe_nonce,
                          paymentMethod: result.paymentMethod,
                          user_id: user_id,
                        },
                      }).done(function (result) {
                        // var result = JSON.parse(result);
                        if (!result.success) {
                          $form = $("#ur-stripe-payment-box");
                          var error_message =
                            '<label id="stripe-errors" class="user-registration-error" role="alert">' +
                            result.data.message +
                            "</label>";
                          $form.find("#card-element").append(error_message);
                          reject();
                        } else {
                          flag = true;
                          resolve();
                        }
                        swal.hideLoading();
                      });
                    }
                  });
              });
            },
          })
          .then((result) => {
            if (flag) {
              swal.close();
              $(".user-registration-error")
                .parent()
                .prepend(
                  '<ul class="user-registration-info"><li><strong>SUCCESS:</strong> ' +
                    ur_stripe_login_params.resubscribe_success_message +
                    "</li></ul>"
                );
              $(".user-registration-error").remove();
              return true;
            }
            return false;
          });
      });
    },
    /**
     * Set up Stripe.js and Elements to use in checkout form.
     *
     * @param {object} form Forms.
     * @param {object} data Forms stripe information.
     *
     * @return object Stripe, Card and client secret.
     */
    setupElements: function (form, data) {
      var stripe = Stripe(data.publishable_key);

      // Instance of Elements.
      var elements = stripe.elements();

      // Custom styling.
      var style = {
        base: {
          color: "#32325d",
          fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
          fontSmoothing: "antialiased",
          fontSize: "14px",
          "::placeholder": {
            color: "#8f9194",
          },
        },
        invalid: {
          color: "#fa755a",
          iconColor: "#fa755a",
        },
      };

      var card = elements.create("card", {
        style: style,
		hidePostalCode: data.urm_hide_stripe_card_postal_code === '1' ? true : false,
      });

      var $card_input = $(form).find("#card-element");
      if ($card_input.length > 0) {
        card.mount($card_input.get(0));
      }
      return {
        stripe: stripe,
        card: card,
        clientSecret: "",
      };
    },
  };

  $(document).ready(function () {
    UR_Stripe_Login.init();
  });
})(jQuery);
