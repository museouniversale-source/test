( function () {
	'use strict';

	// The pro script is the last enqueued VB script, so registerModule is
	// available when this timeout fires. Register ALL modules (core + pro) here
	// so that core modules are not shown as Legacy when the pro plugin is active.
	// The core script (user-registration/assets/js/divi-vb-modules.js) handles
	// registration for the free-plugin-only case where it is the last script.
	window.setTimeout( function () {

		if (
			! window.vendor ||
			! window.vendor.React ||
			! window.vendor.wp ||
			! window.vendor.wp.hooks
		) {
			return;
		}

		var React = window.vendor.React;

		var regFn = ( window.divi &&
		              window.divi.moduleLibrary &&
		              typeof window.divi.moduleLibrary.registerModule === 'function' )
		            ? window.divi.moduleLibrary.registerModule
		            : null;

		if ( ! regFn ) {
			return;
		}

		var placeholderStyle = {
			padding:    '20px',
			textAlign:  'center',
			background: '#f5f5f5',
			border:     '1px dashed #ccc',
			fontFamily: 'sans-serif',
			fontSize:   '13px',
			color:      '#555',
		};

		var vbData = window.urmDiviVbData || {};

		var AJAX_URL   = vbData.ajaxUrl      || '';
		var AJAX_NONCE = vbData.previewNonce || '';

		function createSSR() {
			if ( ! React.useRef || ! React.useEffect || ! AJAX_URL ) {
				return null;
			}

			return function BlockPreview( props ) {
				var ref      = React.useRef( null );
				var cacheKey = JSON.stringify( props.attributes || {} );

				React.useEffect( function() {
					var node = ref.current;
					if ( ! node ) { return; }

					var body = new FormData();
					body.append( 'action', 'urm_d5_preview' );
					body.append( 'nonce',  AJAX_NONCE );
					body.append( 'block',  props.block );
					body.append( 'attrs',  cacheKey );

					var fallback = '<div style="padding:20px;text-align:center;background:#f5f5f5;border:1px dashed #ccc;font-family:sans-serif;font-size:13px;color:#555">'
					               + ( props.title || props.block ) + '</div>';

					// Buttons/inputs rendered inside the VB canvas preview are real,
					// live elements (e.g. the actual download-form submit button) —
					// disable them so editing the layout can't trigger real actions.
					function disableInteractiveElements( container ) {
						if ( ! container || ! container.querySelectorAll ) { return; }
						var els = container.querySelectorAll( 'button, input, select, textarea' );
						for ( var i = 0; i < els.length; i++ ) {
							els[ i ].setAttribute( 'disabled', 'disabled' );
						}
					}

					window.fetch( AJAX_URL, { method: 'POST', body: body } )
						.then( function( r ) { return r.json(); } )
						.then( function( data ) {
							if ( ! node.isConnected ) { return; }
							var html = ( data.success && data.data.html ) ? data.data.html : '';
							node.innerHTML = html
								? '<div style="pointer-events:none;user-select:none">' + html + '</div>'
								: fallback;
							disableInteractiveElements( node );
						} )
						.catch( function() {
							if ( node.isConnected ) { node.innerHTML = fallback; }
						} );
				}, [ cacheKey ] );

				return React.createElement( 'div', { ref: ref } );
			};
		}

		var SSR = createSSR();
		// Expose for any other scripts that rely on window.urmBlockPreview.
		window.urmBlockPreview = SSR;

		function makeRenderer( blockName, title ) {
			return function EditRenderer( props ) {
				var ModuleContainer = window.divi &&
				                      window.divi.module &&
				                      window.divi.module.ModuleContainer;

				var domRef = React.useRef( null );

				var attrs = ( props && props.attrs && typeof props.attrs === 'object' )
					? props.attrs
					: ( props && props.attributes && typeof props.attributes === 'object' )
						? props.attributes
						: {};

				var content = SSR
					? React.createElement( SSR, { block: blockName, attributes: attrs, title: title } )
					: React.createElement( 'div', { style: placeholderStyle }, title );

				if ( ModuleContainer && props && props.id ) {
					return React.createElement(
						ModuleContainer,
						{
							domRef:                   domRef,
							attrs:                    props.attrs || {},
							defaultPrintedStyleAttrs: props.defaultPrintedStyleAttrs,
							elements:                 props.elements,
							id:                       props.id,
							name:                     props.name,
							isFirst:                  props.isFirst,
							isLast:                   props.isLast,
						},
						content
					);
				}

				return content;
			};
		}

		var userStateOptions = {
			'':           { label: '-- Select User State --' },
			'logged_in':  { label: 'Logged In' },
			'logged_out': { label: 'Logged Out' },
		};

		var userStateOptionsNoEmpty = {
			'logged_in':  { label: 'Logged In' },
			'logged_out': { label: 'Logged Out' },
		};

		function register( name, d4Shortcode, title, fields, designSelector ) {
			var attrs = {
				module: { type: 'object', settings: { meta: { meta: {} } } },
			};
			var modSettings = { content: 'auto' };

			// Optional Design-tab controls (text color, background color, border/
			// border-radius, padding/margin) for modules that render a single
			// styleable element, e.g. a button. `designSelector` targets that
			// element specifically so these properties don't just color/border
			// the invisible module wrapper.
			if ( designSelector ) {
				attrs.module.selector = '{{selector}}';
				attrs.module.styleProps = {
					background: { selector: designSelector, important: true },
					border:     { selector: designSelector, important: true },
					font:       { selector: designSelector, important: true },
					spacing:    {
						propertySelectors: { desktop: { value: { padding: designSelector } } },
						important: true,
					},
				};
				attrs.module.settings.decoration = {
					background: {},
					border:     {},
					font:       {},
					spacing:    {},
				};
				modSettings.design = 'auto';
			}

			if ( fields && fields.length ) {
				var contentGroups  = {};
				var settingsGroups = {};

				for ( var i = 0; i < fields.length; i++ ) {
					var f    = fields[ i ];
					var slug = 'content_' + f.key;

					var component;
					if ( f.component ) {
						component = f.component;
					} else if ( f.options ) {
						component = { type: 'field', name: 'divi/select', props: { options: f.options } };
					} else {
						component = { type: 'field', name: 'divi/text' };
					}

					contentGroups[ f.key ] = {
						groupType: 'group-item',
						item: {
							groupSlug:   slug,
							priority:    10,
							render:      true,
							subName:     f.key,
							label:       f.label,
							description: f.desc || '',
							category:    'basic_option',
							features:    { sticky: false, hover: false },
							component:   component,
						},
					};

					settingsGroups[ slug ] = {
						panel:         'content',
						priority:      ( i + 1 ) * 10,
						groupName:     f.key,
						multiElements: true,
						component:     { name: 'divi/composite', props: { groupLabel: f.label } },
					};
				}

				attrs.content = {
					type:     'object',
					settings: {
						innerContent: {
							groupType: 'into-multiple-groups',
							groups:    contentGroups,
						},
					},
				};
				modSettings.groups = settingsGroups;
			}

			try {
				regFn(
					{
						name:        name,
						d4Shortcode: d4Shortcode,
						title:       title,
						moduleIcon:  'divi/module',
						category:    'module',
						attributes:  attrs,
						settings:    modSettings,
					},
					{ renderers: { edit: makeRenderer( name, title ) } }
				);
			} catch ( e ) {
				// A duplicate-registration error means this module was already
				// registered (e.g. by the core script's timeout running before ours).
				// Silently skip so the remaining modules in this batch still register.
			}
		}

		// ── Core modules ──────────────────────────────────────────────────────────

		register(
			'urm/registration-form', 'urm-registration-form', 'URM Registration Form',
			[
				{ key: 'formId',    label: 'Registration Form', desc: 'Select the registration form to display.',       options: vbData.forms || {} },
				{ key: 'userState', label: 'User State',        desc: 'Show this module to specific user states only.', options: userStateOptions },
			]
		);

		register(
			'urm/login-form', 'urm-login-form', 'URM Login Form',
			[
				{ key: 'redirectUrl',    label: 'Redirect URL',        desc: 'Redirect the user to this URL after login.' },
				{ key: 'logoutRedirect', label: 'Logout Redirect URL', desc: 'Redirect the user to this URL after logout.' },
				{ key: 'userState',      label: 'User State',          desc: 'Show this module to specific user states only.', options: userStateOptionsNoEmpty },
			]
		);

		register(
			'urm/myaccount', 'urm-myaccount', 'URM My Account',
			[
				{ key: 'redirectUrl',    label: 'Redirect URL',        desc: 'Redirect the user to this URL after login.' },
				{ key: 'logoutRedirect', label: 'Logout Redirect URL', desc: 'Redirect the user to this URL after logout.' },
				{ key: 'userState',      label: 'User State',          desc: 'Show this module to specific user states only.', options: userStateOptionsNoEmpty },
			]
		);

		register( 'urm/edit-profile',  'urm-edit-profile',  'URM Edit Profile',  null );
		register( 'urm/edit-password', 'urm-edit-password', 'URM Edit Password', null );

		register(
			'urm/membership-groups', 'urm-membership-groups', 'URM Membership Groups',
			[
				{ key: 'groupId',    label: 'Membership Groups', desc: 'Select the membership group to display.',  options: vbData.membershipGroups || {} },
				{ key: 'buttonText', label: 'Button Text',       desc: 'Label for the sign up button.' },
			]
		);

		register( 'urm/membership-thank-you', 'urm-membership-thank-you', 'URM Membership Thank You', null );

		// ── Pro modules ───────────────────────────────────────────────────────────

		var allowAccessOptions = {
			'all_logged_in_users':   { label: 'All Logged In Users' },
			'guest_users':           { label: 'Guest Users' },
			'choose_specific_roles': { label: 'Roles' },
		};

		// divi/checkboxes requires options as [{value, label}] array, not a plain object.
		var specificRolesArr = Object.keys( vbData.specificRoles || {} ).map( function ( slug ) {
			return { value: slug, label: ( vbData.specificRoles[ slug ] || {} ).label || slug };
		} );

		register(
			'urm/content-restriction', 'urm-content-restriction', 'URM Content Restriction',
			[
				{ key: 'userRole',        label: 'Allow Access To', desc: 'Select who can access this restricted content.',              options: allowAccessOptions },
				{ key: 'selectedRoles',   label: 'Roles',           desc: 'Select the user roles that can access this content. Only applies when "Allow Access To" is set to "Roles".', component: { type: 'field', name: 'divi/checkboxes', props: { options: specificRolesArr } } },
				{ key: 'restrictContent', label: 'Content',         desc: 'HTML content visible only to users with the required role.', component: { type: 'field', name: 'divi/richtext' } },
			]
		);

		register(
			'urm/popup', 'urm-popup', 'URM Popup',
			[
				{ key: 'popupId',       label: 'Popup',         desc: 'Select the popup to display.',              options: vbData.popups || {} },
				{ key: 'isUseAsButton', label: 'Use as Button', desc: 'Show a button trigger or an inline link.', options: { 'on': { label: 'On' }, 'off': { label: 'Off' } } },
				{ key: 'buttonText',    label: 'Button Text',   desc: 'Label for the popup trigger button.' },
			]
		);

		register( 'urm/view-profile-details', 'urm-view-profile-details', 'URM View Profile Details', null );

		register(
			'urm/frontend-listing', 'urm-frontend-listing', "URM Member's Directory",
			[
				{ key: 'listingId', label: "Member's Directory", desc: "Select the Member's Directory to display.", options: vbData.frontendListings || {} },
			]
		);

		register(
			'urm/download-pdf-button', 'urm-download-pdf-button', 'URM Download PDF Button',
			[
				{ key: 'buttonText', label: 'Button Text', desc: 'Label for the download button.' },
			],
			'{{selector}} .user-registration-Button'
		);

	}, 0 ); // end setTimeout

	// ── Content Restriction: show "Roles" settings group only when ────────────────
	// ── "Allow Access To" is set to "Roles". ─────────────────────────────────────
	// Divi 5 has no native show_if; we implement it via a lightweight DOM patch.
	//
	// Architecture: this script loads inside the VB canvas iframe (?app_window=1).
	// The settings panel (.et-vb-modal-group) lives in the PARENT document (?et_fb=1).
	// Cross-frame addEventListener doesn't fire for same-document events, so we
	// inject a <script> into the parent document so it runs in that frame's context,
	// where `document` is the settings-panel document and event listeners work normally.
	( function () {
		var parentWin = window.parent;
		if ( ! parentWin || parentWin === window ) { return; } // already top frame
		var parentDoc = parentWin.document;
		if ( ! parentDoc || ! parentDoc.head ) { return; }

		// Avoid double-injection across HMR or multiple script loads.
		if ( parentWin.__urmRolesVisibilityInjected ) { return; }
		parentWin.__urmRolesVisibilityInjected = true;

		var fn = function () {
			function getUserRoleFromFiber() {
				var titleDiv = document.querySelector( '[data-name="content_userRole"]' );
				if ( ! titleDiv ) { return null; }
				var fiberKey = null;
				Object.keys( titleDiv ).forEach( function ( k ) {
					if ( k.startsWith( '__reactFiber' ) || k.startsWith( '__reactInternalInstance' ) ) {
						fiberKey = k;
					}
				} );
				if ( ! fiberKey ) { return null; }
				var current = titleDiv[ fiberKey ], depth = 0;
				while ( current && depth < 25 ) {
					try {
						var p = current.memoizedProps;
						if ( p && p.attrs ) {
							var v = p.attrs.content &&
							        p.attrs.content.innerContent &&
							        p.attrs.content.innerContent.desktop &&
							        p.attrs.content.innerContent.desktop.value &&
							        p.attrs.content.innerContent.desktop.value.userRole;
							if ( v ) { return v; }
						}
					} catch ( e ) {}
					current = current.return;
					depth++;
				}
				return null;
			}

			function applyRolesVisibility() {
				var rolesGroup = null;
				document.querySelectorAll( '.et-vb-modal-group' ).forEach( function ( g ) {
					var h3 = g.querySelector( 'h3' );
					if ( h3 && h3.textContent.trim() === 'Roles' ) { rolesGroup = g; }
				} );
				if ( ! rolesGroup ) { return; }

				var fiberValue = getUserRoleFromFiber();
				if ( fiberValue !== null ) {
					rolesGroup.style.display = ( fiberValue === 'choose_specific_roles' ) ? '' : 'none';
					return;
				}

				// Fallback: read label from the expanded select widget.
				var allowGroup = null;
				document.querySelectorAll( '.et-vb-modal-group' ).forEach( function ( g ) {
					var h3 = g.querySelector( 'h3' );
					if ( h3 && h3.textContent.trim() === 'Allow Access To' ) { allowGroup = g; }
				} );
				if ( allowGroup ) {
					var nameEl = allowGroup.querySelector( '.et-vb-selected-item .select-option-item__name' );
					if ( nameEl ) {
						rolesGroup.style.display = ( nameEl.textContent.trim() === 'Roles' ) ? '' : 'none';
						return;
					}
				}

				rolesGroup.style.display = 'none';
			}

			// Fire at 80 ms for fast React commits; MutationObserver below catches
			// deferred/batched updates regardless of how long React takes.
			document.addEventListener( 'click', function () {
				setTimeout( applyRolesVisibility, 80 );
			}, true );

			// Watch for (a) new .et-vb-modal-group nodes (panel first open) and
			// (b) any mutation INSIDE an existing group (React DOM commit after a
			// deferred state update, e.g. the selected-item text changing).
			// characterData: true is required to catch React text-node updates.
			var obsTimer = null;
			var obs = new MutationObserver( function ( mutations ) {
				var apply = false;

				for ( var i = 0; i < mutations.length; i++ ) {
					var m = mutations[ i ];

					// Case 1: a .et-vb-modal-group was added (initial panel open).
					if ( m.type === 'childList' ) {
						for ( var j = 0; j < m.addedNodes.length; j++ ) {
							var node = m.addedNodes[ j ];
							if ( node.nodeType !== 1 ) { continue; }
							if (
								node.classList.contains( 'et-vb-modal-group' ) ||
								node.querySelector( '.et-vb-modal-group' )
							) {
								apply = true;
							}
						}
					}

					// Case 2: the mutation happened inside a .et-vb-modal-group
					// (React re-rendered the select widget's chosen text).
					var target = m.target;
					var el = ( target.nodeType === 3 ) ? target.parentElement : target;
					while ( el && el !== document.body ) {
						if ( el.classList && el.classList.contains( 'et-vb-modal-group' ) ) {
							apply = true;
							break;
						}
						el = el.parentElement;
					}

					if ( apply ) { break; }
				}

				if ( apply ) {
					clearTimeout( obsTimer );
					obsTimer = setTimeout( applyRolesVisibility, 50 );
				}
			} );
			obs.observe( document.body, { childList: true, subtree: true, characterData: true } );
		};

		// Inject as a <script> so it runs natively in the parent frame's context.
		var script = parentDoc.createElement( 'script' );
		script.textContent = '(' + fn.toString() + ')()';
		parentDoc.head.appendChild( script );
	} )();

} )();
