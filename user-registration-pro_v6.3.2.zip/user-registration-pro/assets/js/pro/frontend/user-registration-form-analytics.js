(function ($, l10n) {
	var SAVE_VISIT_ACTION = "ur_save_user_post_view";
	var QUEUE_KEY = "ur_fa_visit_queue";
	var FORM_SEEN_KEY = "ur_fa_form_seen";
	var MAX_QUEUED_VISITS = 20;

	var FormAnalytics = {
		/**
		 * Variable to store data.
		 *
		 * @since 1.0.0
		 */
		data: {
			formId: 0,
			userJourney: {
				loadTime: null,
			},
			formAbandonment: {
				formActivated: null,
				formSubmitted: null,
			},
		},

		init: function () {},

		/**
		 * Runs when document is ready.
		 *
		 * @since 1.0.0
		 */
		ready: function () {
			FormAnalytics.setTrackingId();
			FormAnalytics.setFormId();
			FormAnalytics.startUserJourney();

			if (
				"undefined" != typeof l10n.track_form_abandonment &&
				l10n.track_form_abandonment
			) {
				FormAnalytics.startFormAbandonmentCapture();
			}
		},

		/**
		 * Set form id in data variable if the page contains everest form.
		 *
		 * @since 1.0.0
		 */
		setFormId: function () {
			var $form = $(".user-registration form");

			if ($form.length) {
				FormAnalytics.data.formId = $form.data("form-id");
			}
		},

		/**
		 * Set Tracking Id if not exists.
		 *
		 * @since 1.0.0
		 *
		 * @returns void
		 */
		setTrackingId: function () {
			var cookies = document.cookie.split(";");
			var cookieValue = "";
			var cookieExists = cookies.some(function (cookie) {
				if (cookie.trim().startsWith("ur_fa_tracking_id" + "=")) {
					cookieValue = cookie.split("=")[1];
					return true;
				}
				return false;
			});

			if (!cookieExists) {
				var expirationDays = 100;
				var expirationDate = new Date();
				expirationDate.setDate(
					expirationDate.getDate() + expirationDays
				);

				var cookieName = "ur_fa_tracking_id";

				cookieValue =
					Math.floor(Math.random() * Date.now()).toString(36) +
					Math.floor(Math.random() * Date.now()).toString(36);

				var cookieString =
					encodeURIComponent(cookieName) +
					"=" +
					encodeURIComponent(cookieValue) +
					"; expires=" +
					expirationDate.toUTCString() +
					"; path=/" +
					( "https:" === window.location.protocol ? "; Secure" : "" );

				document.cookie = cookieString;
			}

			return;
		},

		/**
		 * Whether the visitor has already seen a registration form in this browser.
		 *
		 * @since xx.xx.xx
		 *
		 * @returns {boolean} True when a form was seen, or when storage is unavailable so visits are sent straight away.
		 */
		isFormSeen: function () {
			try {
				return "1" === window.localStorage.getItem( FORM_SEEN_KEY );
			} catch ( e ) {
				return true;
			}
		},

		/**
		 * Remember that the visitor has seen a registration form.
		 *
		 * @since xx.xx.xx
		 *
		 * @returns {boolean} False when storage is unavailable.
		 */
		markFormSeen: function () {
			try {
				window.localStorage.setItem( FORM_SEEN_KEY, "1" );
				return true;
			} catch ( e ) {
				return false;
			}
		},

		/**
		 * Read the visits held back until the visitor reaches a registration form.
		 *
		 * @since xx.xx.xx
		 *
		 * @returns {Array} Held visits, empty when none or storage is unavailable.
		 */
		getQueuedVisits: function () {
			try {
				var queued = JSON.parse( window.localStorage.getItem( QUEUE_KEY ) );
				return Array.isArray( queued ) ? queued : [];
			} catch ( e ) {
				return [];
			}
		},

		/**
		 * Store the held visits, keeping only the latest MAX_QUEUED_VISITS.
		 *
		 * @since xx.xx.xx
		 *
		 * @param {Array} visits Visits to hold.
		 * @returns {boolean} False when storage is unavailable.
		 */
		setQueuedVisits: function ( visits ) {
			try {
				if ( visits.length ) {
					window.localStorage.setItem( QUEUE_KEY, JSON.stringify( visits.slice( -MAX_QUEUED_VISITS ) ) );
				} else {
					window.localStorage.removeItem( QUEUE_KEY );
				}

				return true;
			} catch ( e ) {
				return false;
			}
		},

		/**
		 * Hold a visit back instead of sending it.
		 *
		 * @since xx.xx.xx
		 *
		 * @param {Object} visit Visit data.
		 * @returns {boolean} False when storage is unavailable and the visit must be sent now.
		 */
		queueVisit: function ( visit ) {
			var queued = FormAnalytics.getQueuedVisits();
			queued.push( visit );

			return FormAnalytics.setQueuedVisits( queued );
		},

		/**
		 * Send every held visit in one request, then clear the queue.
		 *
		 * @since xx.xx.xx
		 */
		flushQueuedVisits: function () {
			var queued = FormAnalytics.getQueuedVisits();

			if ( ! queued.length ) {
				return;
			}

			// Claim the queue before sending so a second open tab cannot send the same visits.
			FormAnalytics.setQueuedVisits( [] );

			var now = Date.now();
			var visits = queued.map( function ( visit ) {
				var sent = $.extend( {}, visit, { age: Math.max( 0, Math.round( ( now - ( visit.ended_at || now ) ) / 1000 ) ) } );
				delete sent.ended_at;

				return sent;
			} );

			if ( ! FormAnalytics.post( { queued_visits: JSON.stringify( visits ) } ) ) {
				FormAnalytics.setQueuedVisits( queued );
			}
		},

		/**
		 * Post fields to the save-visit action.
		 *
		 * @since xx.xx.xx
		 *
		 * @param {Object} fields Flat request fields.
		 * @returns {boolean} False when the browser refused to queue the beacon.
		 */
		post: function ( fields ) {
			// Use sendBeacon to reliably send data even when the page
			// navigates away immediately (e.g. after form submission redirect).
			if ( navigator.sendBeacon ) {
				var beaconData = new FormData();
				beaconData.append( "action", SAVE_VISIT_ACTION );
				beaconData.append( "_wpnonce", l10n.save_visited_nonce );
				$.each( fields, function ( key, value ) {
					beaconData.append( key, value );
				} );

				return navigator.sendBeacon( l10n.ajax_url, beaconData );
			}

			$.ajax({
				url: l10n.ajax_url,
				type: "POST",
				async: false,
				data: $.extend( { action: SAVE_VISIT_ACTION, _wpnonce: l10n.save_visited_nonce }, fields ),
			});

			return true;
		},

		/**
		 * Send one visit now.
		 *
		 * @since xx.xx.xx
		 *
		 * @param {Object} data Visit data.
		 */
		sendVisit: function ( data ) {
			var fields = {};

			$.each( data, function ( key, value ) {
				fields[ "data[" + key + "]" ] = value;
			} );

			FormAnalytics.post( fields );
		},

		/**
		 * Start User Journey tracker hooks.
		 *
		 * @since 1.0.0
		 */
		startUserJourney: function () {
			// No nonce means the server declined this request (e.g. logged-in user) and would reject the beacon.
			if ( ! l10n.save_visited_nonce ) {
				return;
			}

			FormAnalytics.data.userJourney.loadTime = Date.now();

			// Visits are only read for people who reach a registration form, so earlier ones are held back until then.
			if ( FormAnalytics.data.formId ) {
				FormAnalytics.markFormSeen();
				FormAnalytics.flushQueuedVisits();
			}

			// A form added after page load is only noticed once the visitor starts filling it in.
			$(document).one("focusin", ".ur-field-item", function () {
				FormAnalytics.setFormId();
				FormAnalytics.markFormSeen();
				FormAnalytics.flushQueuedVisits();
			});

			$(window).on("beforeunload", function () {
				var userSessionDuration = Math.floor(
					(Date.now() - FormAnalytics.data.userJourney.loadTime) /
						1000
				);

				// The server ignores visits with an empty duration, so do not send them.
				if ( ! userSessionDuration ) {
					return;
				}
				var formSubmitted =
					"undefined" !==
					FormAnalytics.data.formAbandonment.formSubmitted
						? FormAnalytics.data.formAbandonment.formSubmitted
						: false;

				var formAbandoned =
					"undefined" !==
					FormAnalytics.data.formAbandonment.formActivated
						? FormAnalytics.data.formAbandonment.formActivated &&
						  !formSubmitted
						: false;

				var data = {
					user_session_duration: userSessionDuration,
					form_submitted: formSubmitted,
					form_abandoned: formAbandoned,
					form_id: FormAnalytics.data.formId,
					referer: l10n.referer_page,
				};

				var heldBack =
					! FormAnalytics.isFormSeen() &&
					FormAnalytics.queueVisit( $.extend( {}, data, { page_url: window.location.href, ended_at: Date.now() } ) );

				if ( ! heldBack ) {
					FormAnalytics.sendVisit( data );
				}
			});
		},

		/**
		 * Start Form Abandonment Capture hooks.
		 *
		 * @since 1.0.0
		 */
		startFormAbandonmentCapture: function () {
			$(".ur-field-item *").on("focus change", function () {
				if (null == FormAnalytics.data.formAbandonment.formActivated) {
					FormAnalytics.data.formAbandonment.formActivated = true;
				}
			});

			// Use event delegation on document so UR's .off("submit") on form.register
			// cannot remove this handler.
			$(document).on("submit", "form.register", function () {
				FormAnalytics.data.formAbandonment.formSubmitted = true;
			});

			// UR triggers this event on $(document), not $(window).
			$(document).on(
				"user_registration_frontend_after_ajax_complete",
				function (e, ajax_response, type, $this) {
					FormAnalytics.data.formAbandonment.formSubmitted = true;
				}
			);

			$(window).on("beforeunload", function () {
				if (
					"undefined" !== typeof l10n.save_abandoned_value &&
					l10n.save_abandoned_value
				) {
					FormAnalytics.processAndSendAbandonedEntry();
				}
			});
		},

		/**
		 * Process and Send Abandoned Entry request.
		 *
		 * @since 1.0.0
		 */
		processAndSendAbandonedEntry: function () {
			if (
				null === FormAnalytics.data.formAbandonment.formSubmitted &&
				FormAnalytics.data.formAbandonment.formActivated
			) {
				var data = FormAnalytics.getAbandonedFormData();

				data.push(
					{
						name: "action",
						value: "ur_save_abandoned_data",
					},
					{
						name: "_wpnonce",
						value: l10n.save_abandoned_data_nonce,
					}
				);

				// Send the AJAX request
				$.ajax({
					url: l10n.ajax_url,
					type: "POST",
					data: data,
				});
			}
		},

		/**
		 * Get and return Abandoned Entry data in proper format.
		 *
		 * @since 1.0.0
		 */
		getAbandonedFormData: function () {
			var form = $("form.register");

			if (form.length) {
				return form.serializeArray();
			}

			return false;
		},
	};

	FormAnalytics.init();
	$(document).ready(FormAnalytics.ready);
})(jQuery, urFormAnalyticsl10n);
