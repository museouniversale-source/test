/**
 * Script to handle stripe in backend.
 *
 * @since 1.0.2
 */
(function ($) {
  var UR_Stripe_Admin = {
    init: function () {
      UR_Stripe_Admin.initEventStripe(".ur-selected-item");
      $(document).on("click", ".ur-selected-item", function () {
        UR_Stripe_Admin.initEventStripe(this);
      });
      $(document).on(
        "user_registration_handle_selected_item",
        function (event, selected_item) {
          var field_key = $(selected_item).find(".ur-field").data("field-key");

          if ("subscription_plan" === field_key) {
            var $stripe_settings = $(
              "#ur-field-all-settings > #stripe-settings"
            );
            UR_Stripe_Admin.enable_recurring_payment($stripe_settings);
          }
        }
      );
      // Save payment condition to $_POST
      $(document).on(
        "user_registration_admin_before_form_submit",
        function (event, data) {
          var stripe_conditional_settings =
            UR_Stripe_Admin.save_conditional_logic_settings();
          if (stripe_conditional_settings.length > 0) {
            data.data["ur_stripe_conditional_integration"] =
              stripe_conditional_settings;
          }
        }
      );
    },
    initEventStripe: function ($this) {
      var $advance_setting = $($this).find(".ur-advance-setting");
      $.each($advance_setting, function () {
        var $selector = $(this).find("[data-advance-field]");
        switch ($selector.attr("data-advance-field")) {
          case "payment_methods":
            $(document).on(
              "change",
              'select[data-advance-field="payment_methods"]',
              function () {
                UR_Stripe_Admin.trigger_advance_setting_select($(this));
              }
            );
            break;
        }
      });
    },
    /**
     * Stripe Form Settings
     *
     * @since 1.0.2
     */
    formSettings: function () {
      // The sync/address/shipping toggles also render inside the combined Field Sync panel on new forms, not just Stripe's own tab.
      var $stripe_settings = $(
        "#ur-field-all-settings > #stripe-settings, #field-sync-settings"
      );
      var $enable_stripe = $stripe_settings.find(
        "#user_registration_enable_stripe"
      );
      if (!$enable_stripe.is(":checked")) {
        UR_Stripe_Admin.disable_stripe_settings($stripe_settings);
      } else {
        UR_Stripe_Admin.enable_stripe_settings($stripe_settings);
      }

      // Field sync feeds the Stripe customer record on the membership path too, so it
      // stays reachable whether or not this form takes a payment.
      UR_Stripe_Admin.init_sync_stripe_mapping($stripe_settings);

      $stripe_settings
        .find("#user_registration_enable_stripe")
        .on("click", function () {
          UR_Stripe_Admin.disable_stripe_settings($stripe_settings);
          if ($(this).is(":checked")) {
            UR_Stripe_Admin.enable_stripe_settings($stripe_settings);
          }
        });
      $stripe_settings
        .find(
          "#user_registration_enable_stripe_recurring_field input[type='checkbox']"
        )
        .on("click", function () {
          UR_Stripe_Admin.disable_recurring_payment($stripe_settings);
          if ($(this).is(":checked")) {
            UR_Stripe_Admin.enable_recurring_payment($stripe_settings);
          }
        });

      $stripe_settings
        .find(
          "#user_registration_enable_sync_fields_with_stripe_field input[type='checkbox']"
        )
        .on("click", function () {
          UR_Stripe_Admin.disable_sync_stripe_mapping($stripe_settings);
          if ($(this).is(":checked")) {
            UR_Stripe_Admin.enable_sync_stripe_mapping($stripe_settings);
          }
        });

      $stripe_settings
        .find(
          "#user_registration_enable_sync_address_with_stripe_field input[type='checkbox']"
        )
        .on("click", function () {
          UR_Stripe_Admin.disable_sync_address_stripe_mapping($stripe_settings);
          if ($(this).is(":checked")) {
            UR_Stripe_Admin.enable_sync_address_stripe_mapping(
              $stripe_settings
            );
          }
        });

      $stripe_settings
        .find(
          "#user_registration_enable_sync_shipping_address_with_stripe_field input[type='checkbox']"
        )
        .on("click", function () {
          UR_Stripe_Admin.disable_sync_shipping_stripe_mapping(
            $stripe_settings
          );
          if ($(this).is(":checked")) {
            UR_Stripe_Admin.enable_sync_shipping_stripe_mapping(
              $stripe_settings
            );
          }
        });

      $stripe_settings
        .find("#user_registration_stripe_recurring_period")
        .on("change", function () {
          UR_Stripe_Admin.setIntervalCountInput(
            $("#user_registration_stripe_interval_count").val(),
            $(this).val()
          );
        });

      $stripe_settings
        .find("#user_registration_stripe_interval_count")
        .on("input", function () {
          var value = $(this).val();
          var $period = $("#user_registration_stripe_recurring_period").val();

          UR_Stripe_Admin.setIntervalCountInput(value, $period);
        });
    },
    /**
     * This render stripe payment gateway according to payment method chosen ideal,
     * credit card or both into drop section of form builder.
     *
     * @since 1.0.2
     */
    trigger_advance_setting_select: function ($selector) {
      var wrapper = $(".ur-selected-item.ur-item-active");

      if (Array.isArray($selector.val())) {
        var html = "";
        html += '<div class="ur-tab-picker">';
        $.each($selector.val(), function ($key, $gateway) {
          html += '<button class="ur-tab-button" id="' + $gateway + '">';
          if ("credit_card" === $gateway) {
            html += "Credit Card";
          } else if ("ideal" === $gateway) {
            html += "iDEAL";
          }
          html += "</button>";
        });
        html += "</div>";
        html += '<div class="ur-field" data-field-key="stripe_gateway">';

        html +=
          '<div id="user_registration_stripe_gateway" data-gateway="stripe" conditional_rules="">';
        html += '<div class="ur-tab-content">';

        if (
          $selector.val().length < 2 &&
          $selector.val().includes("credit_card")
        ) {
          html +=
            '<div data-id="credit_card" class="StripeElement StripeElement--empty ur-stripe-element-active">';
          html += '<div class="ur-card-icon">';
          html +=
            '<svg focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 21"><g fill="none" fill-rule="evenodd"><g id="unknown" class="Icon-fill"><g id="card" transform="translate(0 2)"><path id="shape" d="M26.58 19H2.42A2.4 2.4 0 0 1 0 16.62V2.38A2.4 2.4 0 0 1 2.42 0h24.16A2.4 2.4 0 0 1 29 2.38v14.25A2.4 2.4 0 0 1 26.58 19zM10 5.83c0-.46-.35-.83-.78-.83H3.78c-.43 0-.78.37-.78.83v3.34c0 .46.35.83.78.83h5.44c.43 0 .78-.37.78-.83V5.83z" opacity=".2"></path><path id="shape" d="M25 15h-3c-.65 0-1-.3-1-1s.35-1 1-1h3c.65 0 1 .3 1 1s-.35 1-1 1zm-6 0h-3c-.65 0-1-.3-1-1s.35-1 1-1h3c.65 0 1 .3 1 1s-.35 1-1 1zm-6 0h-3c-.65 0-1-.3-1-1s.35-1 1-1h3c.65 0 1 .3 1 1s-.35 1-1 1zm-6 0H4c-.65 0-1-.3-1-1s.35-1 1-1h3c.65 0 1 .3 1 1s-.35 1-1 1z" opacity=".3"></path></g></g></g></svg>';
          html += "</div>";
          html +=
            '<input class="card-number" type="text" placeholder="Card Number" disabled>';
          html +=
            '<input class="card-expiration" type="text" placeholder="MM / YY" disabled>';
          html +=
            '<input class ="card-cvc" type="text" placeholder="CVC" disabled>';
          html += "</div>";
        } else if (
          $selector.val().length < 2 &&
          $selector.val().includes("ideal")
        ) {
          html +=
            '<div data-id="ideal" class="StripeElement StripeElement--empty ur-stripe-element-active">';
          html += "Select bank";
          html += "</div>";
        } else if ($selector.val().length > 1) {
          html +=
            '<div data-id="credit_card" class="StripeElement StripeElement--empty ur-stripe-element-active">';
          html += '<div class="ur-card-icon">';
          html +=
            '<svg focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 21"><g fill="none" fill-rule="evenodd"><g id="unknown" class="Icon-fill"><g id="card" transform="translate(0 2)"><path id="shape" d="M26.58 19H2.42A2.4 2.4 0 0 1 0 16.62V2.38A2.4 2.4 0 0 1 2.42 0h24.16A2.4 2.4 0 0 1 29 2.38v14.25A2.4 2.4 0 0 1 26.58 19zM10 5.83c0-.46-.35-.83-.78-.83H3.78c-.43 0-.78.37-.78.83v3.34c0 .46.35.83.78.83h5.44c.43 0 .78-.37.78-.83V5.83z" opacity=".2"></path><path id="shape" d="M25 15h-3c-.65 0-1-.3-1-1s.35-1 1-1h3c.65 0 1 .3 1 1s-.35 1-1 1zm-6 0h-3c-.65 0-1-.3-1-1s.35-1 1-1h3c.65 0 1 .3 1 1s-.35 1-1 1zm-6 0h-3c-.65 0-1-.3-1-1s.35-1 1-1h3c.65 0 1 .3 1 1s-.35 1-1 1zm-6 0H4c-.65 0-1-.3-1-1s.35-1 1-1h3c.65 0 1 .3 1 1s-.35 1-1 1z" opacity=".3"></path></g></g></g></svg>';
          html += "</div>";
          html +=
            '<input class="card-number" type="text" placeholder="Card Number" disabled>';
          html +=
            '<input class="card-expiration" type="text" placeholder="MM / YY" disabled>';
          html +=
            '<input class ="card-cvc" type="text" placeholder="CVC" disabled>';
          html += "</div>";
        }
        html += "</div>";
        html += "</div>";
        wrapper.find(".ur-tab-container").html(html);
      }
    },
    /**
     * Handles interval count does not allow to enter more than year.
     *
     * @since 1.0.2
     */
    setIntervalCountInput: function (value, $period) {
      if (value === "") {
        return;
      }

      if (value < 1) {
        $("#user_registration_stripe_interval_count").val(1);
      } else if (value === undefined || !$.isNumeric(value)) {
        $("#user_registration_stripe_interval_count").val(1);
      } else if ($period === "year" && value > 1) {
        $("#user_registration_stripe_interval_count").val(1);
      } else if ($period === "month" && value > 12) {
        $("#user_registration_stripe_interval_count").val(12);
      } else if ($period === "week" && value > 52) {
        $("#user_registration_stripe_interval_count").val(52);
      } else if ($period === "day" && value > 365) {
        $("#user_registration_stripe_interval_count").val(365);
      }
    },
    /**
     * It enables/shows stripe form settings.
     *
     * @since 1.0.2
     */
    enable_stripe_settings: function ($stripe_settings) {
      $stripe_settings
        .find("#user_registration_stripe_payment_methods_field")
        .show();
      $stripe_settings.find("#subscribtion_section_field").show();
      $stripe_settings
        .find("#user_registration_enable_stripe_recurring_field")
        .show();
      $stripe_settings.find(".ur_conditional_logic_container").show();
      var conditional_logic_container = $stripe_settings.find(
        ".ur_conditional_logic_container"
      );
      var enable_conditional_logic = conditional_logic_container
        .find("#ur_use_conditional_logic")
        .is(":checked");
      if (enable_conditional_logic) {
        conditional_logic_container
          .find(".ur_conditional_logic_wrapper")
          .show();
      }

      var $enable_recurring = $stripe_settings.find(
        "#user_registration_enable_stripe_recurring_field input"
      );

      if (!$enable_recurring.is(":checked")) {
        UR_Stripe_Admin.disable_recurring_payment($stripe_settings);
      } else {
        UR_Stripe_Admin.enable_recurring_payment($stripe_settings);
      }
    },
    /**
     * It enables/shows stripe recurring payment.
     *
     * @since 1.0.2
     */
    enable_recurring_payment: function ($stripe_settings) {
      var subscription_plan_field = $(".ur-selected-item").find(
        ".ur-input-type-subscription_plan"
      ).length;
      if (subscription_plan_field > 0) {
        $stripe_settings
          .find("#user_registration_stripe_plan_name_field")
          .hide();

        $stripe_settings
          .find("#user_registration_stripe_recurring_period_field")
          .hide();
        $stripe_settings
          .find("#user_registration_stripe_interval_count_field")
          .hide();
      } else {
        $stripe_settings
          .find("#user_registration_stripe_plan_name_field")
          .show();
        $stripe_settings
          .find("#user_registration_stripe_recurring_period_field")
          .show();
        $stripe_settings
          .find("#user_registration_stripe_interval_count_field")
          .show();
      }
      $stripe_settings
        .find("#user_registration_stripe_cancellation_action_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_allow_resubscribe_field")
        .show();
      $stripe_settings.find("#subscribtion_mapping_field_section_field").show();
      $stripe_settings
        .find("#user_registration_enable_sync_fields_with_stripe_field")
        .show();

      var $enable_sync_stripe_mapping = $stripe_settings.find(
        "#user_registration_enable_sync_fields_with_stripe_field input"
      );

      if (!$enable_sync_stripe_mapping.is(":checked")) {
        UR_Stripe_Admin.disable_sync_stripe_mapping($stripe_settings);
      } else {
        UR_Stripe_Admin.enable_sync_stripe_mapping($stripe_settings);
      }
    },
    /**
     * It shows stripe sync mapping
     *
     * @since 1.2.0
     */
    enable_sync_stripe_mapping: function ($stripe_settings) {
      $stripe_settings
        .find("#user_registration_stripe_sync_full_name_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_description_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_phone_field")
        .show();
      $stripe_settings
        .find(
          "#user_registration_enable_sync_shipping_address_with_stripe_field"
        )
        .show();
      $stripe_settings
        .find("#user_registration_enable_sync_address_with_stripe_field")
        .show();

      var $enable_sync_shipping_stripe_mapping = $stripe_settings.find(
        "#user_registration_enable_sync_shipping_address_with_stripe_field input"
      );

      if (!$enable_sync_shipping_stripe_mapping.is(":checked")) {
        UR_Stripe_Admin.disable_sync_shipping_stripe_mapping($stripe_settings);
      } else {
        UR_Stripe_Admin.enable_sync_shipping_stripe_mapping($stripe_settings);
      }
      var $enable_sync_address_stripe_mapping = $stripe_settings.find(
        "#user_registration_enable_sync_address_with_stripe_field input"
      );

      if (!$enable_sync_address_stripe_mapping.is(":checked")) {
        UR_Stripe_Admin.disable_sync_address_stripe_mapping($stripe_settings);
      } else {
        UR_Stripe_Admin.enable_sync_address_stripe_mapping($stripe_settings);
      }
    },
    /**
     * It shows stripe sync mapping
     *
     * @since 1.2.0
     */
    disable_sync_shipping_stripe_mapping: function ($stripe_settings) {
      $stripe_settings
        .find("#subscribtion_mapping_shipping_section_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_full_name_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_phone_field")
        .hide();
      $stripe_settings
        .find("#subscribtion_mapping_shipping_address_section_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_city_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_country_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_line1_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_line2_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_postal_code_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_state_field")
        .hide();
    },
    /**
     * It hides stripe sync mapping
     *
     * @since 1.2.0
     */
    disable_sync_address_stripe_mapping: function ($stripe_settings) {
      $stripe_settings
        .find("#subscribtion_mapping_address_section_field")
        .hide();
      $stripe_settings.find("#user_registration_stripe_sync_city_field").hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_country_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_line1_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_line2_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_postal_code_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_state_field")
        .hide();
    },
    /**
     * It shows stripe sync mapping
     *
     * @since 1.2.0
     */
    enable_sync_shipping_stripe_mapping: function ($stripe_settings) {
      $stripe_settings
        .find("#subscribtion_mapping_shipping_section_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_full_name_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_phone_field")
        .show();
      $stripe_settings
        .find("#subscribtion_mapping_shipping_address_section_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_city_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_country_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_line1_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_line2_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_postal_code_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_shipping_state_field")
        .show();
    },
    /**
     * It shows stripe sync mapping
     *
     * @since 1.2.0
     */
    enable_sync_address_stripe_mapping: function ($stripe_settings) {
      $stripe_settings
        .find("#subscribtion_mapping_address_section_field")
        .show();
      $stripe_settings.find("#user_registration_stripe_sync_city_field").show();
      $stripe_settings
        .find("#user_registration_stripe_sync_country_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_line1_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_line2_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_postal_code_field")
        .show();
      $stripe_settings
        .find("#user_registration_stripe_sync_state_field")
        .show();
    },
    /**
     * It disables/hides stripe sync mapping
     *
     * @since 1.2.0
     */
    disable_sync_stripe_mapping: function ($stripe_settings) {
      $stripe_settings
        .find("#user_registration_stripe_sync_full_name_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_description_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_sync_phone_field")
        .hide();
      $stripe_settings
        .find(
          "#user_registration_enable_sync_shipping_address_with_stripe_field"
        )
        .hide();
      $stripe_settings
        .find("#user_registration_enable_sync_address_with_stripe_field")
        .hide();
      UR_Stripe_Admin.disable_sync_address_stripe_mapping($stripe_settings);
      UR_Stripe_Admin.disable_sync_shipping_stripe_mapping($stripe_settings);
    },
    /**
     * It disables/hides stripe recurring payment.
     *
     * @since 1.0.2
     */
    disable_recurring_payment: function ($stripe_settings) {
      $stripe_settings.find("#user_registration_stripe_plan_name_field").hide();
      $stripe_settings
        .find("#user_registration_stripe_cancellation_action_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_allow_resubscribe_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_recurring_period_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_interval_count_field")
        .hide();
    },
    /**
     * It disables/hides stripe form settings.
     *
     * @since 1.0.2
     */
    init_sync_stripe_mapping: function ($stripe_settings) {
      $stripe_settings.find("#subscribtion_mapping_field_section_field").show();
      $stripe_settings
        .find("#user_registration_enable_sync_fields_with_stripe_field")
        .show();

      var $enable_sync = $stripe_settings.find(
        "#user_registration_enable_sync_fields_with_stripe_field input"
      );

      if (!$enable_sync.is(":checked")) {
        UR_Stripe_Admin.disable_sync_stripe_mapping($stripe_settings);
      } else {
        UR_Stripe_Admin.enable_sync_stripe_mapping($stripe_settings);
      }
    },
    disable_stripe_settings: function ($stripe_settings) {
      $stripe_settings
        .find("#user_registration_stripe_payment_methods_field")
        .hide();
      $stripe_settings.find("#subscribtion_section_field").hide();
      $stripe_settings
        .find("#user_registration_enable_stripe_recurring_field")
        .hide();
      $stripe_settings.find("#user_registration_stripe_plan_name_field").hide();
      $stripe_settings
        .find("#user_registration_stripe_cancellation_action_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_allow_resubscribe_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_recurring_period_field")
        .hide();
      $stripe_settings
        .find("#user_registration_stripe_interval_count_field")
        .hide();
      $stripe_settings.find("#subscribtion_section_field").hide();

      $stripe_settings.find(".ur_conditional_logic_container").hide();
    },
    /**
     * save conditional logic from form builder
     */
    save_conditional_logic_settings: function () {
      var stripe_conditional_settings = [];
      var conditional_logic_element = $("div[data-source='stripe']").closest(
        ".ur_conditional_logic_container"
      );

      var form_fields = $(conditional_logic_element).find(
        ".ur-conditional-wrapper"
      );

      var enable_conditional_logic = $(conditional_logic_element)
        .find("#ur_use_conditional_logic")
        .is(":checked");
      var conditional_logic_data = {};
      $.each(form_fields, function (key, field) {
        conditional_logic_data["conditional_field"] = $(this)
          .find(".ur_conditional_field")
          .val();
        conditional_logic_data["conditional_operator"] = $(this)
          .find(".ur-conditional-condition")
          .val();
        conditional_logic_data["conditional_value"] = $(this)
          .find(".ur-conditional-input")
          .val();
      });
      var integration = {
        enable_conditional_logic: enable_conditional_logic,
        conditional_logic_data: conditional_logic_data,
      };
      stripe_conditional_settings.push(integration);
      return stripe_conditional_settings;
    },
  };

  $(document).ready(function () {
    UR_Stripe_Admin.init();
    UR_Stripe_Admin.formSettings();
  });
})(jQuery);
