<?php
/**
 * UserRegistrationStripe Hander Functions.
 *
 * General core functions available on both the front-end and admin.
 *
 * @package UserRegistrationStripe
 *
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'user_registration_field_keys', 'ur_get_stripe_field_type', 10, 2 );

add_filter( 'user_registration_stripe_gateway_admin_template', 'ur_add_stripe_gateway_template', 10, 1 );


/**
 * Assign field type to single item.
 *
 * @param  string $field_type Field Type.
 * @param  string $field_key Field Key.
 * @return string
 */
function ur_get_stripe_field_type( $field_type, $field_key ) {

	if ( 'stripe_gateway' === $field_key ) {
		$field_type = 'stripe_gateway';
	}
	return $field_type;
}

/**
 * Include template for stripe gateway field.
 *
 * @param string $path File Path.
 * @return string  File Path.
 */
function ur_add_stripe_gateway_template( $path ) {

	$path = dirname( __DIR__, 2 ) . '/form/views/admin/admin-stripe-gateway.php';

	return $path;
}

/**
 * Stripe Gateway Info.
 */
function stripe_gateway_info() {
	$gateways     = '';
	$pub_key      = get_option( 'user_registration_stripe_test_publishable_key' );
	$sec_key      = get_option( 'user_registration_stripe_test_secret_key' );
	$live_pub_key = get_option( 'user_registration_stripe_live_publishable_key' );
	$live_sec_key = get_option( 'user_registration_stripe_live_secret_key' );
	$test_mode    = get_option( 'user_registration_stripe_test_mode' );
	$test_mode    = ur_string_to_bool( $test_mode );

	if ( $test_mode ) {
		if ( empty( $pub_key ) || empty( $sec_key ) ) {
			return $gateways;
		} else {
			return 'stripe';
		}
	} elseif ( ! $test_mode ) {
		if ( empty( $live_pub_key ) || empty( $live_sec_key ) ) {
			return $gateways;
		} else {
			return 'stripe';
		}
	}
}
