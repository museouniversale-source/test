<?php
/**
 * Stripe form payment assets.
 *
 * @package UserRegistrationPro/Addons/Stripe
 */

use WPEverest\URMembership\Admin\Services\Stripe\StripeService;

defined( 'ABSPATH' ) || exit;

/**
 * UR_Pro_Stripe Class
 */
class UR_Pro_Stripe {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
		add_action( 'user_registration_enqueue_scripts', array( $this, 'enqueue_scripts' ), 10, 2 );
		add_action( 'user_registration_my_account_enqueue_scripts', array( $this, 'enqueue_scripts' ), 10, 2 );
		add_action( 'user_registration_my_account_enqueue_scripts', array( $this, 'enqueue_login_scripts' ), 10, 2 );
	}

	/**
	 * Publishable key for the configured mode.
	 *
	 * @return string
	 */
	private function get_publishable_key() {
		$mode = ur_string_to_bool( get_option( 'user_registration_stripe_test_mode' ) ) ? 'test' : 'live';

		return get_option( sprintf( 'user_registration_stripe_%s_publishable_key', $mode ), '' );
	}

	/**
	 * Enqueue admin assets on the form builder.
	 */
	public function admin_scripts() {
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_style( 'user-registration-stripe-admin', UR_ASSETS_URL . '/css/user-registration-stripe-admin.css', array(), UR()->version );
		wp_enqueue_script( 'user-registration-stripe-admin-script', UR_ASSETS_URL . "/js/admin/user-registration-stripe-admin{$suffix}.js", array(), UR()->version, true );
	}

	/**
	 * Enqueue the resubscribe assets used on the login and my account screens.
	 *
	 * @param array $form_data_array Form data.
	 * @param int   $form_id         Form ID.
	 */
	public function enqueue_login_scripts( $form_data_array, $form_id ) {
		$stripe_settings = StripeService::get_stripe_settings();

		if ( ! ur_string_to_bool( $stripe_settings['is_stipe_enabled'] ) || empty( $this->get_publishable_key() ) ) {
			return;
		}

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		$resubscribe_html  = '<div id="ur-stripe-payment-box">';
		$resubscribe_html .= '<h3>' . esc_html__( 'Card Information', 'user-registration' ) . '</h3>';
		$resubscribe_html .= '<p id="ur-stripe-message">' . esc_html__( 'Please enter the card details to resubscribe the subscription.', 'user-registration' ) . '</p>';
		$resubscribe_html .= '</div>';
		$resubscribe_html .= '</br><div id="card-element"></div></br>';

		$params = array(
			'ajax_url'                    => admin_url( 'admin-ajax.php' ),
			'publishable_key'             => $this->get_publishable_key(),
			'resubscribe_html'            => $resubscribe_html,
			'resubscribe_nonce'           => wp_create_nonce( 'ur_stripe_resubscribe_nonce' ),
			'resubscribe_button_text'     => esc_html__( 'Resubscribe', 'user-registration' ),
			'cancel_button_text'          => esc_html__( 'Cancel', 'user-registration' ),
			'resubscribe_success_message' => esc_html__( 'Your subscription is now active. You have access to login.', 'user-registration' ),
		);

		wp_enqueue_script( 'user-registration-stripe-v3', 'https://js.stripe.com/v3/', array(), null, true ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- Stripe requires its unversioned URL.
		wp_enqueue_script( 'user-registration-stripe-login', UR_ASSETS_URL . "/js/frontend/user-registration-stripe-login{$suffix}.js", array( 'user-registration' ), UR()->version, true );
		wp_localize_script( 'user-registration-stripe-login', 'ur_stripe_login_params', $params );
	}

	/**
	 * Enqueue the form payment assets when the form has Stripe enabled.
	 *
	 * @param array $form_data_array Form data.
	 * @param int   $form_id         Form ID.
	 */
	public function enqueue_scripts( $form_data_array, $form_id ) {
		$enabled_gateways = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe', false ) );

		if ( ! $enabled_gateways ) {
			return;
		}

		$suffix              = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		$customer_details    = array();
		$cancellation_action = ur_get_single_post_meta( $form_id, 'user_registration_stripe_cancellation_action', 'end_of_cycle' );

		if ( ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_sync_fields_with_stripe', false ) ) ) {
			$sync_keys = array(
				'full_name',
				'description',
				'phone',
				'city',
				'country',
				'line1',
				'line2',
				'postal_code',
				'state',
				'shipping_full_name',
				'shipping_phone',
				'shipping_city',
				'shipping_country',
				'shipping_line1',
				'shipping_line2',
				'shipping_postal_code',
				'shipping_state',
			);

			foreach ( $sync_keys as $sync_key ) {
				$customer_details[ $sync_key ] = maybe_unserialize( ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_' . $sync_key, '' ) );
			}
		}

		$cancel_subscription_html = 'end_of_cycle' === $cancellation_action
			? esc_html__( 'Are you sure do you want to cancel the subscription? You can reactivate it before end of billing cycle.', 'user-registration' )
			: esc_html__( 'Are you sure do you want to cancel the subscription? Once you cancel you cannot reactivate it.', 'user-registration' );

		$params = array(
			'ajax_url'                                    => admin_url( 'admin-ajax.php' ),
			'publishable_key'                             => $this->get_publishable_key(),
			'user_registration_currency'                  => get_option( 'user_registration_payment_currency' ),
			'enabled_gateways'                            => $enabled_gateways,
			'recurring'                                   => ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe_recurring', false ) ),
			'i18n_auth_fail'                              => esc_html__( 'No internet, check you connection and try again.', 'user-registration' ),
			'amount_field_required'                       => esc_html__( 'Payment amount field is required.', 'user-registration' ),
			'empty_card_details'                          => esc_html__( 'Your card number is empty.', 'user-registration' ),
			'reactivate_subscription_title'               => esc_html__( 'Reactivate Subscription', 'user-registration' ),
			'reactivate_subscription_success_button_text' => esc_html__( 'Your subscription has been activated.', 'user-registration' ),
			'cancel_subscription_title'                   => esc_html__( 'Cancel Subscription', 'user-registration' ),
			'cancel_subscription_html'                    => $cancel_subscription_html,
			'cancel_subscription_button_text'             => esc_html__( 'Yes, Please Proceed.', 'user-registration' ),
			'cancel_button_text'                          => esc_html__( 'No', 'user-registration' ),
			'cancel_subscription_success_button_text'     => esc_html__( 'Your subscription has been cancelled.', 'user-registration' ),
			'customer_details_fields'                     => wp_json_encode( $customer_details ),
			'urm_hide_stripe_card_postal_code'            => apply_filters( 'user_registration_membership_disable_stripe_card_postal_code', false ),
			'payment_nonce'                               => wp_create_nonce( 'ur_stripe_payment_nonce' ),
			'change_payment_title'                        => esc_html__( 'Change Your Card Information here', 'user-registration' ),
			'change_payment_card_info'                    => esc_html__( 'Card Information', 'user-registration' ),
			'change_payment_nonce'                        => wp_create_nonce( 'save_change_payment' ),
			'change_payment_message'                      => esc_html__( 'Card information updated successfully.', 'user-registration' ),
		);

		wp_enqueue_style( 'user-registration-stripe-frontend', UR_ASSETS_URL . '/css/user-registration-stripe-frontend.css', array(), UR()->version );
		wp_enqueue_script( 'user-registration-stripe-v3', 'https://js.stripe.com/v3/', array(), null, true ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- Stripe requires its unversioned URL.
		wp_enqueue_script( 'user-registration-stripe', UR_ASSETS_URL . "/js/frontend/user-registration-stripe{$suffix}.js", array( 'user-registration' ), UR()->version, true );
		wp_enqueue_script( 'user-registration-stripe-my-account', UR_ASSETS_URL . "/js/frontend/user-registration-stripe-my-account{$suffix}.js", array( 'user-registration' ), UR()->version, true );
		wp_localize_script( 'user-registration-stripe-my-account', 'ur_stripe_params', $params );
		wp_localize_script( 'user-registration-stripe', 'ur_stripe_params', $params );
	}
}

new UR_Pro_Stripe();
