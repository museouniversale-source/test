<?php
/**
 * Admin class
 *
 * User_Registration_Stripe Admin
 *
 * @package User_Registration_Stripe
 * @since  1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'UR_Pro_Stripe_Admin' ) ) {
	/**
	 * Admin class.
	 * The class manage all the admin behaviors.
	 *
	 * @since 1.0.0
	 */
	class UR_Pro_Stripe_Admin {

		/**
		 * Plugin options
		 *
		 * @var array
		 *
		 * @since 1.0.0
		 */
		public $options = array();

		/**
		 * Plugin version
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $version = UR_VERSION;

		/**
		 * Constructor
		 *
		 * @since 1.0.0
		 */
		public function __construct() {

			add_filter( 'user_registration_payment_fields', array( $this, 'ur_register_stripe_gateway_field' ) );

			add_filter( 'user_registration_one_time_draggable_form_fields', array( $this, 'ur_stripe_gateway_one_time_drag' ), 10, 1 );

			add_filter( 'user_registration_stripe_gateway_advance_class', array( $this, 'ur_stripe_gateway_advance_class' ), 10, 1 );

			// Stripe Settings Hooks.
			if ( is_admin() ) {

				// Hooks for Enble disable stripe in individual form settings.
				add_action( 'user_registration_after_form_settings', array( $this, 'render_stripe_section' ) );
				add_filter( 'user_registration_form_settings_save', array( $this, 'save_stripe_settings' ), 10, 2 );
				add_filter( 'user_registration_field_sync_gateways', array( $this, 'register_field_sync' ), 10, 2 );

				// Field Backward compatibility in form builder.
				add_filter( 'user_registration_form_builder_field_before', array( $this, 'form_builder_field_backward_compatibility' ) );
			}

			add_action( 'user_registration_after_form_settings_save', array( $this, 'create_plan_on_form_save' ) );

			add_filter( 'user_registration_form_settings_save', array( $this, 'save_stripe_conditional_settings' ), 10, 2 );
		}

		/**
		 * Stripe Gateway Advance class.
		 *
		 * @param array $file_data File Data.
		 */
		public function ur_stripe_gateway_advance_class( $file_data ) {

			$path                   = dirname( __DIR__, 2 ) . '/form/settings/class-ur-setting-stripe-gateway.php';
			$file_data['file_path'] = $path;

			return $file_data;
		}

		/**
		 * Handle Credit Card field backword compatibility by replacing with new field i.e stripe_gateway.
		 *
		 * @param mixed $single_field Form Field.
		 */
		public function form_builder_field_backward_compatibility( $single_field ) {
			if ( 'credit_card' === $single_field->field_key ) {

				$single_field->field_key                   = 'stripe_gateway';
				$single_field->general_setting->label      = 'Stripe Gateway';
				$single_field->general_setting->field_name = 'stripe_gateway';
			}
			return $single_field;
		}

		/**
		 * Render Stripe Section.
		 *
		 * @param  int $form_id Form Id.
		 * @return void
		 */
		public function render_stripe_section( $form_id = 0 ) {
			// New forms see the same fields in the combined Field Sync panel instead of their own Stripe tab.
			if ( function_exists( 'ur_legacy_payment_fields_enabled' ) && ! ur_legacy_payment_fields_enabled( $form_id ) ) {
				return;
			}

			$pub_key              = get_option( 'user_registration_stripe_test_publishable_key' );
			$sec_key              = get_option( 'user_registration_stripe_test_secret_key' );
			$live_pub_key         = get_option( 'user_registration_stripe_live_publishable_key' );
			$live_sec_key         = get_option( 'user_registration_stripe_live_secret_key' );
			$integration_settings = get_post_meta( $form_id, 'user_registration_stripe_conditional_integration', true );

			echo '<div id="stripe-settings" data-field-group="payments" ><h3>' . esc_html__( 'Stripe Payment', 'user-registration' ) . '</h3>';

			// Stripe.
			if ( ( ! empty( $pub_key ) && ! empty( $sec_key ) ) || ( ! empty( $live_pub_key ) && ! empty( $live_sec_key ) ) ) {
				$arguments = $this->stripe_form_settings( $form_id );

				foreach ( $arguments as $args ) {
					function_exists( 'user_registration_form_settings_field' ) ? user_registration_form_settings_field( $args['id'], $args ) : user_registration_form_field( $args['id'], $args );
				}

				// Conditional logic gates a form payment, so new sites do not get it.
				$show_conditional_logic = ! function_exists( 'ur_legacy_payment_fields_enabled' ) || ur_legacy_payment_fields_enabled( $form_id );

				// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Settings markup rendered by user_registration_pro_render_conditional_logic().
				if ( $show_conditional_logic ) {
					if ( ! empty( $integration_settings ) && is_array( $integration_settings ) ) {
						foreach ( $integration_settings as $connection ) {
							echo $this->output_stripe_conditional_logic( $form_id, $connection );
						}
					} else {
						echo $this->output_stripe_conditional_logic( $form_id, array() );
					}
				}
				// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
			} else {
				echo "<p class='user-registration-notice user-registration-notice-info'>";
				echo wp_kses_post(
					sprintf(
						/* translators: %s: payment settings URL */
						__( 'Please enter the publishable and secret key on <a href="%s">settings panel</a> to enable stripe.', 'user-registration' ),
						esc_url( admin_url( 'admin.php?page=user-registration-settings&tab=payment' ) )
					)
				);
				echo '</p>';
			}

			echo '</div>';
		}

		/**
		 * Register Stripe into the combined Field Sync panel.
		 *
		 * Hidden when Stripe is disabled. When enabled but the keys for the current
		 * test/live mode are missing, shows a notice that deep-links to Settings >
		 * Payment and highlights the Stripe section.
		 *
		 * @param array $gateways Registered gateways.
		 * @param int   $form_id  Form Id.
		 *
		 * @return array
		 */
		public function register_field_sync( $gateways, $form_id ) {
			if ( function_exists( 'urm_is_payment_gateway_enabled' ) && ! urm_is_payment_gateway_enabled( 'stripe' ) ) {
				return $gateways;
			}

			if ( ! function_exists( 'urm_is_payment_gateway_configured' ) || ! urm_is_payment_gateway_configured( 'stripe' ) ) {
				$gateways[] = array(
					'id'     => 'stripe',
					'label'  => __( 'Stripe', 'user-registration' ),
					'notice' => sprintf(
						'%s <a href="%s">%s</a>',
						esc_html__( 'Stripe is enabled but not configured for the current mode. Add your API keys to enable field sync.', 'user-registration' ),
						esc_url( admin_url( 'admin.php?page=user-registration-settings&tab=payment&method=stripe' ) ),
						esc_html__( 'Go to Stripe settings', 'user-registration' )
					),
				);

				return $gateways;
			}

			// The panel supplies its own "Stripe" section header, so drop Stripe's redundant one.
			$fields = array_values(
				array_filter(
					$this->stripe_form_settings( $form_id ),
					fn( $field ) => 'subscribtion_mapping_field_section' !== ( $field['id'] ?? '' )
				)
			);

			$gateways[] = array(
				'id'     => 'stripe',
				'label'  => __( 'Stripe', 'user-registration' ),
				'toggle' => 'user_registration_enable_sync_fields_with_stripe',
				'fields' => $fields,
			);

			return $gateways;
		}

		/**
		 * Individual Form Settings for Stripe Payment.
		 *
		 * @param int $form_id Form Id.
		 *
		 * @return array $settings
		 */
		public function stripe_form_settings( $form_id ) {

			$get_all_fields         = user_registration_pro_get_conditional_fields_by_form_id( $form_id, '' );
			$all_fields             = array();
			$multiselect_all_fields = array();
			$all_fields['']         = __( '-- Ignore this Field --', 'user-registration' );
			foreach ( $get_all_fields as $key => $fields ) {
				$all_fields[ $key ]             = $fields['label'];
				$multiselect_all_fields[ $key ] = $fields['label'];
			}

			$arguments = array(
				'form_id'      => $form_id,

				'setting_data' => array(
					array(
						'type'              => 'toggle',
						'label'             => __( 'Enable Stripe Payment', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_enable_stripe',
						'class'             => array( 'ur-enhanced-select' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe', false ),
						'tip'               => __( 'Enable payment for this form with Stripe.', 'user-registration' ),
					),
					array(
						'type'  => 'section',
						'id'    => 'subscribtion_section',
						'title' => __( 'Subscription Settings', 'user-registration' ),
						'class' => array( 'ur-form-settings-section' ),
					),
					array(
						'type'              => 'toggle',
						'label'             => __( 'Enable Recurring Subscription Payments', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_enable_stripe_recurring',
						'class'             => array( 'ur-enhanced-select' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe_recurring', false ),
						'tip'               => __( 'Enable subscription with periodical/recurring payments.', 'user-registration' ),
					),
					array(
						'type'              => 'text',
						'label'             => __( 'Plan Name', 'user-registration' ),
						'description'       => 'Note: We have introduced a new subscription plan field. If you drag and drop this field, the current plan will no longer be active, giving priority to the new field. We also recommend switching to the subscription plan field, as this plan option will no longer be available after a few updates.',
						'required'          => false,
						'id'                => 'user_registration_stripe_plan_name',
						'class'             => array( 'ur-input-field' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_plan_name', '' ),
						'tip'               => __( 'Enter a plan name for this form.', 'user-registration' ),
					),
					array(
						'type'              => 'number',
						'label'             => __( 'Recurring Period', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_interval_count',
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_interval_count', '' ),
						'tip'               => __( 'Interval between recurring payments.', 'user-registration' ),
						'class'             => array( 'ur-input-field' ),
					),
					array(
						'type'              => 'select',
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_recurring_period',
						'options'           => array(
							'day'   => __( 'Day(s)', 'user-registration' ),
							'week'  => __( 'Week(s)', 'user-registration' ),
							'month' => __( 'Month(s)', 'user-registration' ),
							'year'  => __( 'Year(s)', 'user-registration' ),
						),
						'class'             => array( 'ur-enhanced-select' ),
						'custom_attributes' => array( 'style' => 'width: 60%; align-self: flex-end;' ),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_recurring_period', 'year' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Subscription Cancellation Action', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_cancellation_action',
						'options'           => array(
							'end_of_cycle' => __( 'Cancel Subscription at the end of billing cycle ', 'user-registration' ),
							'immediately'  => __( 'Cancel Subscription Immediately', 'user-registration' ),
						),
						'class'             => array( 'ur-enhanced-select' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_cancellation_action', 'end_of_cycle' ),
					),
					array(
						'type'              => 'toggle',
						'label'             => __( 'Allow Resubscription', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_allow_resubscribe',
						'class'             => array( 'ur-enhanced-select' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_allow_resubscribe', false ),
						'tip'               => __( 'Enable user to resubscribe a previous cancelled subscription.', 'user-registration' ),
					),
					array(
						'type'  => 'section',
						'id'    => 'subscribtion_mapping_field_section',
						'title' => __( 'Map Fields to sync with stripe', 'user-registration' ),
						'class' => array( 'ur-form-settings-section' ),
					),
					array(
						'type'              => 'toggle',
						'label'             => __( 'Enable Sync Fields with Stripe', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_enable_sync_fields_with_stripe',
						'class'             => array( 'ur-enhanced-select' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_enable_sync_fields_with_stripe', false ),
						'tip'               => __( 'This option allows you to sync extra field with stripe when subscription enabled.', 'user-registration' ),
					),
					array(
						'type'              => 'multiselect',
						'label'             => __( 'Full Name', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_full_name',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $multiselect_all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_full_name', '' ),
						'tip'               => __( 'Select First Name and Last Name field concat will considered as full name.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Description', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_description',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_description', '' ),
						'tip'               => __( 'Select Description.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Phone Number', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_phone',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_phone', '' ),
						'tip'               => __( 'Select Phone.', 'user-registration' ),
					),
					array(
						'type'              => 'toggle',
						'label'             => __( 'Enable Address Mapping', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_enable_sync_address_with_stripe',
						'class'             => array( 'ur-enhanced-select' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_enable_sync_address_with_stripe', false ),
						'tip'               => __( 'This option allows you to enable address fields.', 'user-registration' ),
					),
					array(
						'type'  => 'section',
						'id'    => 'subscribtion_mapping_address_section',
						'title' => __( 'Address', 'user-registration' ),
						'class' => array( 'ur-form-settings-section' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'City', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_city',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_city', '' ),
						'tip'               => __( 'Select City.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Country', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_country',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_country', '' ),
						'tip'               => __( 'Select Country.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Line 1', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_line1',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_line1', '' ),
						'tip'               => __( 'Select Line 1.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Line 2', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_line2',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_line2', '' ),
						'tip'               => __( 'Select Line 2.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Postal Code', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_postal_code',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_postal_code', '' ),
						'tip'               => __( 'Select Postal Code.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'State', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_state',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_state', '' ),
						'tip'               => __( 'Select State.', 'user-registration' ),
					),
					array(
						'type'              => 'toggle',
						'label'             => __( 'Enable Shipping Details', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_enable_sync_shipping_address_with_stripe',
						'class'             => array( 'ur-enhanced-select' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_enable_sync_shipping_address_with_stripe', false ),
						'tip'               => __( 'This option allows you to enable shipping address fields.', 'user-registration' ),
					),
					array(
						'type'  => 'section',
						'id'    => 'subscribtion_mapping_shipping_section',
						'title' => __( 'Shipping Details', 'user-registration' ),
						'class' => array( 'ur-form-settings-section' ),
					),
					array(
						'type'              => 'multiselect',
						'label'             => __( 'Shipping Full Name', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_shipping_full_name',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $multiselect_all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_shipping_full_name', '' ),
						'tip'               => __( 'Select Shipping First Name and Last Name field concat will considered as full name.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Shipping Phone Number', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_shipping_phone',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_shipping_phone', '' ),
						'tip'               => __( 'Select Shipping Phone.', 'user-registration' ),
					),
					array(
						'type'  => 'section',
						'id'    => 'subscribtion_mapping_shipping_address_section',
						'title' => __( 'Shipping Address', 'user-registration' ),
						'class' => array( 'ur-form-settings-section' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Shipping City', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_shipping_city',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_shipping_city', '' ),
						'tip'               => __( 'Select Shipping City.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Shipping Country', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_shipping_country',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_shipping_country', '' ),
						'tip'               => __( 'Select Shipping Country.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Shipping Line 1', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_shipping_line1',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_shipping_line1', '' ),
						'tip'               => __( 'Select Shipping Line 1.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Shipping Line 2', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_shipping_line2',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_shipping_line2', '' ),
						'tip'               => __( 'Select Shipping Line 2.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Shipping Postal Code', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_shipping_postal_code',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_shipping_postal_code', '' ),
						'tip'               => __( 'Select Shipping Postal Code.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Shipping State', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_stripe_sync_shipping_state',
						'class'             => array( 'ur-enhanced-select' ),
						'options'           => $all_fields,
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_stripe_sync_shipping_state', '' ),
						'tip'               => __( 'Select Shipping State.', 'user-registration' ),
					),
				),
			);
			$arguments = apply_filters( 'user_registration_get_stripe_settings', $arguments );

			return $this->filter_legacy_settings( $arguments['setting_data'], $form_id );
		}

		/**
		 * Drop the form payment settings that new sites may no longer use.
		 *
		 * Field sync is kept, since it feeds the Stripe customer record on the membership
		 * path too. Sites already charging through payment fields keep everything.
		 *
		 * @param array $settings Setting data.
		 * @return array
		 */
		private function filter_legacy_settings( $settings, $form_id = 0 ) {
			if ( ! function_exists( 'ur_legacy_payment_fields_enabled' ) || ur_legacy_payment_fields_enabled( $form_id ) ) {
				return $settings;
			}

			/**
			 * Filters the Stripe form settings withheld from sites that never used payment fields.
			 *
			 * @param array $legacy_only Setting ids to drop.
			 *
			 * @since x.x.x
			 */
			$legacy_only = apply_filters(
				'user_registration_stripe_legacy_only_form_settings',
				array(
					'user_registration_enable_stripe',
					'subscribtion_section',
					'user_registration_enable_stripe_recurring',
					'user_registration_stripe_plan_name',
					'user_registration_stripe_interval_count',
					'user_registration_stripe_recurring_period',
					'user_registration_stripe_cancellation_action',
					'user_registration_stripe_allow_resubscribe',
				)
			);

			foreach ( $settings as $index => $setting ) {
				if ( isset( $setting['id'] ) && in_array( $setting['id'], $legacy_only, true ) ) {
					unset( $settings[ $index ] );
				}
			}

			return array_values( $settings );
		}

		/**
		 * Save Stripe Payment Form Settings
		 *
		 * @param  array   $settings Settings.
		 * @param  integer $form_id Form Id.
		 * @return array $settings
		 */
		public function save_stripe_settings( $settings, $form_id = 0 ) {

			$payment_setting = $this->stripe_form_settings( $form_id );
			$settings        = array_merge( $settings, $payment_setting );

			return $settings;
		}

		/**
		 * Register stripe gateway field.
		 *
		 * @param array $fields Fields.
		 * @return array  All registered fields.
		 */
		public function ur_register_stripe_gateway_field( $fields ) {
			$fields = ! in_array( 'stripe_gateway', $fields, true ) ? array_merge( $fields, array( 'stripe_gateway' ) ) : $fields;
			return $fields;
		}

		/**
		 * Make credit card one time draggable.
		 *
		 * @param array $fields One time draggable fields.
		 *
		 * @return array One time draggable fields.
		 */
		public function ur_stripe_gateway_one_time_drag( $fields ) {
			$fields[] = 'stripe_gateway';
			return $fields;
		}

		/**
		 * Create / Update Plan when admin save form.
		 *
		 * @param array $form_data Form Data.
		 */
		public function create_plan_on_form_save( $form_data ) {
			$form_id = $form_data['form_id'];

			$post_data               = ur_get_post_content( $form_id );
			$subscription_plan_field = ur_get_form_data_by_key( $post_data, 'subscription_plan' );

			$stripe_enabled           = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe', false ) );
			$stripe_recurring_enabled = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe_recurring', false ) );

			if ( $stripe_enabled && $stripe_recurring_enabled ) {
				if ( ! empty( $subscription_plan_field ) ) {
					if ( isset( $subscription_plan_field['subscription_plan']->general_setting->options ) ) {
						$plan_lists = $subscription_plan_field['subscription_plan']->general_setting->options;
						if ( ! empty( $plan_lists ) ) {
							$subscription_plan_lists = ur_get_single_post_meta( $form_id, 'user_registration_subscription_products', array() );

							$subscription_plan_lists_updated = array();
							foreach ( $plan_lists as $plan ) {
								$interval_count             = $plan->interval_count;
								$trail_period_enable        = $plan->trail_period_enable;
								$subscription_expiry_enable = $plan->subscription_expiry_enable;
								$subscription_expiry_date   = $plan->subscription_expiry_date;
								if ( '' === $interval_count ) {
									$interval_count = 1;
								}

								$product_id       = 0;
								$existing_product = array();

								if ( is_array( $subscription_plan_lists ) ) {
									// Check if the product already exists.
									$existing_product = array_filter(
										$subscription_plan_lists,
										function ( $product ) use ( $plan ) {
											return $product['plan_name'] === $plan->label;
										}
									);
								}

								if ( empty( $existing_product ) ) {
									// If product does not exist, create a new one.
									$product    = \Stripe\Product::create(
										array(
											'name' => $plan->label,
										)
									);
									$product_id = $product->id;

									if ( ur_string_to_bool( $trail_period_enable ) ) {
										$trail_interval_count = $plan->trail_interval_count;
										if ( '' === $trail_interval_count ) {
											$trail_interval_count = 1;
										}
										// Add the new product to the subscription_plan_lists.
										$subscription_products = array(
											'product_id'   => $product_id,
											'plan_name'    => $plan->label,
											'period'       => $plan->recurring_period,
											'interval_count' => $interval_count,
											'trail_interval_count' => $trail_interval_count,
											'trail_period' => $plan->trail_recurring_period,
											'exact_expiry_date_enable' => $plan->subscription_expiry_enable,
											'exact_expiry_date' => $plan->subscription_expiry_date,
											'currency'     => get_option( 'user_registration_payment_currency', 'USD' ),
										);
									} else {
										// Add the new product to the subscription_plan_lists.
										$subscription_products = array(
											'product_id' => $product_id,
											'plan_name'  => $plan->label,
											'period'     => $plan->recurring_period,
											'interval_count' => $interval_count,
											'exact_expiry_date_enable' => $plan->subscription_expiry_enable,
											'exact_expiry_date' => $plan->subscription_expiry_date,
											'currency'   => get_option( 'user_registration_payment_currency', 'USD' ),
										);
									}
									$subscription_plan_lists_updated[] = $subscription_products;
								} else {
									$existing_product = array_values( $existing_product );

									if ( ! empty( $existing_product ) ) {

										if ( ur_string_to_bool( $trail_period_enable ) ) {
											$trail_interval_count = $plan->trail_interval_count;
											if ( '' === $trail_interval_count ) {
												$trail_interval_count = 1;
											}
											// Add the new product to the subscription_plan_lists.
											$subscription_products = array(
												'product_id' => $existing_product[0]['product_id'],
												'plan_name' => $plan->label,
												'period'   => $plan->recurring_period,
												'interval_count' => $interval_count,
												'trail_interval_count' => $trail_interval_count,
												'trail_period' => $plan->trail_recurring_period,
												'exact_expiry_date_enable' => $plan->subscription_expiry_enable,
												'exact_expiry_date' => $plan->subscription_expiry_date,
												'currency' => get_option( 'user_registration_payment_currency', 'USD' ),
											);
										} else {
											// Add the new product to the subscription_plan_lists.
											$subscription_products = array(
												'product_id' => $existing_product[0]['product_id'],
												'plan_name' => $plan->label,
												'period'   => $plan->recurring_period,
												'interval_count' => $interval_count,
												'exact_expiry_date_enable' => $plan->subscription_expiry_enable,
												'exact_expiry_date' => $plan->subscription_expiry_date,
												'currency' => get_option( 'user_registration_payment_currency', 'USD' ),
											);
										}
										$subscription_plan_lists_updated[] = $subscription_products;
									}
								}
							}
							update_post_meta( $form_id, 'user_registration_subscription_products', $subscription_plan_lists_updated );
						}
					}
				} else {
					$plan_name      = ur_get_single_post_meta( $form_id, 'user_registration_stripe_plan_name', '' );
					$period         = ur_get_single_post_meta( $form_id, 'user_registration_stripe_recurring_period', 'year' );
					$interval_count = ur_get_single_post_meta( $form_id, 'user_registration_stripe_interval_count', '1' );

					if ( $stripe_recurring_enabled && '' !== $plan_name ) {

						if ( '' === $interval_count ) {
							$interval_count = 1;
						}
						$existing_subscription_products = ur_get_single_post_meta( $form_id, 'user_registration_subscription_products', array() );

						if ( is_array( $existing_subscription_products ) && ! empty( $existing_subscription_products ) ) {

							foreach ( $existing_subscription_products as $key => $subscription_products ) {

								if ( $subscription_products['plan_name'] !== $plan_name ) {
									$product = \Stripe\Product::update(
										$subscription_products['product_id'],
										array(
											'name' => $plan_name,
										)
									);
								}

								$product_id = $subscription_products['product_id'];
							}
						} else {
							$product    = \Stripe\Product::create(
								array(
									'name' => $plan_name,
								)
							);
							$product_id = $product->id;
						}

						if ( ! empty( $product ) ) {
							$subscription_products = array(
								array(
									'product_id'     => $product_id,
									'plan_name'      => $plan_name,
									'period'         => $period,
									'interval_count' => $interval_count,
									'currency'       => get_option( 'user_registration_payment_currency', 'USD' ),
								),
							);
							update_post_meta( $form_id, 'user_registration_subscription_products', $subscription_products );
						}
					}
				}
			}
		}

		/**
		 * Save Stripe conditional settings.
		 *
		 * @param array $settings Form settings.
		 * @param int   $form_id  Form ID.
		 *
		 * @return array
		 */
		public function save_stripe_conditional_settings( $settings, $form_id = 0 ) {
			// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Runs inside the form save request, which UR_AJAX verifies first; ur_clean() sanitizes recursively.
			$form_id                     = isset( $_POST['data']['form_id'] ) ? absint( wp_unslash( $_POST['data']['form_id'] ) ) : absint( $form_id );
			$stripe_conditional_settings = isset( $_POST['data']['ur_stripe_conditional_integration'] ) ? ur_clean( wp_unslash( $_POST['data']['ur_stripe_conditional_integration'] ) ) : array();
			// phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

			if ( $form_id ) {
				update_post_meta( $form_id, 'user_registration_stripe_conditional_integration', $stripe_conditional_settings );
			}

			return $settings;
		}

		/**
		 * Output conditional logic markup.
		 *
		 * @param int   $form_id    Form ID.
		 * @param array $connection Connection data.
		 *
		 * @return string
		 */
		public function output_stripe_conditional_logic( $form_id, $connection = array() ) {

			$output = user_registration_pro_render_conditional_logic( $connection, 'stripe', $form_id );
			return $output;
		}
	}
}

new UR_Pro_Stripe_Admin();
