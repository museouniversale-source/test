<?php
/**
 *  UR_Pro_Stripe_Process Stripe Process.
 *
 * @since  1.0.0
 * @package User_Registration_Stripe
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * UR_Pro_Stripe_Process Class
 */
class UR_Pro_Stripe_Process {


	/**
	 * Class Constructor.
	 */
	public function __construct() {
		// If stripe authorizes payment and sends token, process payment first include SDK.
		$pub_key      = get_option( 'user_registration_stripe_test_publishable_key' );
		$sec_key      = get_option( 'user_registration_stripe_test_secret_key' );
		$live_pub_key = get_option( 'user_registration_stripe_live_publishable_key' );
		$live_sec_key = get_option( 'user_registration_stripe_live_secret_key' );

		if ( ! class_exists( '\Stripe\Stripe' ) ) {
			require_once UR_ABSPATH . 'vendor/stripe/stripe-php/init.php';
		}
		// See your keys here: https://dashboard.stripe.com/account .
		if ( ! ur_string_to_bool( get_option( 'user_registration_stripe_test_mode' ) ) ) {
			if ( ( ! empty( $live_pub_key ) && ! empty( $live_sec_key ) ) ) {

				\Stripe\Stripe::setApiKey( get_option( 'user_registration_stripe_live_secret_key', '' ) );
			} else {
				return;
			}
		} elseif ( ( ! empty( $pub_key ) && ! empty( $sec_key ) ) ) {
			\Stripe\Stripe::setApiKey( get_option( 'user_registration_stripe_test_secret_key', '' ) );
		} else {
			return;
		}

		add_filter( 'user_registration_stripe_gateway_frontend_form_data', array( $this, 'user_registration_stripe_form_field_filter' ), 10, 1 );
		add_filter( 'user_registration_form_field_stripe_gateway', array( $this, 'user_registration_stripe_form_field_render' ), 10, 4 );

		// Create payment intent.
		add_action( 'wp_ajax_ur_stripe_update_customer_payment', array( $this, 'update_customer_payment' ) );
		add_action( 'wp_ajax_nopriv_ur_stripe_update_customer_payment', array( $this, 'update_customer_payment' ) );

		// Resubscribe Subscription.
		add_action( 'wp_ajax_ur_stripe_resubscribe_payment', array( $this, 'resubscribe_payment' ) );
		add_action( 'wp_ajax_nopriv_ur_stripe_resubscribe_payment', array( $this, 'resubscribe_payment' ) );

		// Create customer.
		add_action( 'wp_ajax_ur_stripe_create_customer', array( $this, 'create_customer' ) );
		add_action( 'wp_ajax_nopriv_ur_stripe_create_customer', array( $this, 'create_customer' ) );

		// Create subscription.
		add_action( 'wp_ajax_ur_stripe_create_subscription', array( $this, 'create_subscription' ) );
		add_action( 'wp_ajax_nopriv_ur_stripe_create_subscription', array( $this, 'create_subscription' ) );

		// Callback Webhook.
		add_action( 'wp_ajax_ur_stripe_webhook', array( $this, 'stripe_webhook' ) );
		add_action( 'wp_ajax_nopriv_ur_stripe_webhook', array( $this, 'stripe_webhook' ) );

		// Update user's Payment status.
		add_action( 'wp_ajax_ur_stripe_update_user_payment_status', array( $this, 'update_user_payment_status' ) );
		add_action( 'wp_ajax_nopriv_ur_stripe_update_user_payment_status', array( $this, 'update_user_payment_status' ) );

		// Payment Process Hooks.
		if ( is_plugin_active( 'user-registration-pro/user-registration.php' ) ) {
			$is_payment_compatible = true;
			if ( is_plugin_active( 'user-registration-payments/user-registration-payments.php' ) ) {
				if ( version_compare( URP_VERSION, '1.5.3', '<' ) ) {
					$is_payment_compatible = false;
				}
			}
			if ( UR_PRO_ACTIVE && ( version_compare( UR_VERSION, '4.1.1', '<=' ) || ! $is_payment_compatible ) ) {
				add_filter( 'user_registration_success_params_payment_process', array( $this, 'stripe_process' ), 10, 4 );
			} else {
				add_filter( 'user_registration_success_params_stripe_payment_process', array( $this, 'stripe_process' ), 10, 4 );
			}
		}
		add_action( 'template_redirect', array( $this, 'check_my_account_stripe_action' ), 10 );

		// Check payment status on login page.
		add_filter( 'ur_user_before_check_payment_status_on_login', array( $this, 'custom_login_message' ), 10, 2 );

		add_filter( 'user_registration_before_registration_form_template', array( $this, 'check_backward_compatibility' ), 10, 2 );
	}

	/**
	 * Function to update credit card details of the existing customer from the myaccount page.
	 */
	public function resubscribe_payment() {

		check_ajax_referer( 'ur_stripe_resubscribe_nonce', 'security' );

		$user_id = isset( $_POST['user_id'] ) ? absint( wp_unslash( $_POST['user_id'] ) ) : 0;

		// A user may only resubscribe their own account.
		if ( ! is_user_logged_in() || get_current_user_id() !== $user_id ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'user-registration' ) ) );
		}

		$form_id           = ur_get_form_id_by_userid( $user_id );
		$customer_id       = get_user_meta( $user_id, 'ur_payment_customer', true );
		$payment_method_id = isset( $_POST['paymentMethod']['id'] ) ? sanitize_text_field( wp_unslash( $_POST['paymentMethod']['id'] ) ) : '';

		if ( empty( $payment_method_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Missing payment method.', 'user-registration' ) ) );
		}

		$existing_subscription_products = ur_get_single_post_meta( $form_id, 'user_registration_subscription_products', array() );
		$total_amount                   = get_user_meta( $user_id, 'ur_payment_total_amount', true );

		if ( is_array( $existing_subscription_products ) && ! empty( $existing_subscription_products ) ) {
			foreach ( $existing_subscription_products as $key => $subscription_products ) {
				try {
					$price_list = \Stripe\Price::all(
						array(
							'product' => $subscription_products['product_id'],
						)
					);

					$is_price_already_exits = false;
					$price_id               = 0;

					if ( isset( $price_list->data ) && is_array( $price_list->data ) ) {
						$price_data  = $price_list->data;
						$unit_amount = (int) round( floatval( $total_amount ) * 100 );
						foreach ( $price_data as $key => $price ) {
							if ( $price->unit_amount == $unit_amount && 'recurring' === $price->type ) {
								$is_price_already_exits = true;
								$price_id               = $price->id;
								break;
							}
						}
					}

					if ( ! $is_price_already_exits && 0 === $price_id ) {
						$resubscribe_period         = $subscription_products['period'];
						$resubscribe_interval_count = (int) $subscription_products['interval_count'];
						if ( 'year' === $resubscribe_period && $resubscribe_interval_count > 3 ) {
							$resubscribe_interval_count = $resubscribe_interval_count * 12;
							$resubscribe_period         = 'month';
						}
						$price    = \Stripe\Price::create(
							array(
								'product'     => $subscription_products['product_id'],
								'unit_amount' => (int) round( floatval( $total_amount ) * 100 ),
								'currency'    => get_option( 'user_registration_payment_currency', 'USD' ),
								'recurring'   => array(
									'interval'       => $resubscribe_period,
									'interval_count' => $resubscribe_interval_count,
								),
							)
						);
						$price_id = $price->id;
					}

					$customer       = \Stripe\Customer::retrieve( $customer_id );
					$payment_method = \Stripe\PaymentMethod::retrieve( $payment_method_id );
					$payment_method->attach(
						array(
							'customer' => $customer->id,
						)
					);

					\Stripe\Customer::update(
						$customer->id,
						array(
							'invoice_settings' => array(
								'default_payment_method' => $payment_method->id,
							),
						)
					);

					$subscription                               = \Stripe\Subscription::create(
						array(
							'customer' => $customer->id,
							'items'    => array(
								array(
									'price' => $price_id,
								),
							),
							'expand'   => array( 'latest_invoice.payment_intent' ),
						)
					);
					$metas['ur_payment_subscription']           = isset( $subscription->id ) ? $subscription->id : '';
					$metas['ur_payment_customer']               = isset( $subscription->customer ) ? $subscription->customer : '';
					$metas['ur_payment_interval']               = isset( $subscription->plan->interval ) ? $subscription->plan->interval : '';
					$metas['ur_payment_subscription_status']    = isset( $subscription->status ) ? $subscription->status : '';
					$metas['ur_payment_subscription_plan_name'] = ur_get_single_post_meta( $form_id, 'user_registration_stripe_plan_name', '' );
					$metas['ur_payment_subscription_expiry']    = $this->get_subscription_expiry( $subscription );

					// UTC period end, so a replayed renewal event is not applied twice.
					$metas['ur_payment_subscription_period_end'] = $this->get_subscription_period_end( $subscription );

				} catch ( Exception $e ) {
					wp_send_json_error(
						array(
							'message' => $e->getMessage(),
						)
					);
				}
			}
			$payment_status             = 'completed';
			$metas['ur_payment_status'] = $payment_status;

			$metas['ur_payment_transaction'] = isset( $subscription->id ) ? $subscription->id : '';

			/**
			 * Invoice code started.
			 */
			if ( 'active' === $subscription->status ) {
				$payment_invoice = array();

				$invoice['invoice_date'] = gmdate( 'Y-m-d H:i:s' );
				$invoice['invoice_no']   = isset( $subscription->id ) ? $subscription->id : '';

				$invoice_item = get_user_meta( $user_id, 'ur_cart_items' );

				$invoice['invoice_plan']     = $metas['ur_payment_subscription_plan_name'];
				$invoice['invoice_item']     = $invoice_item;
				$invoice['invoice_currency'] = get_user_meta( $user_id, 'ur_payment_currency', true );
				$invoice['invoice_amount']   = get_user_meta( $user_id, 'ur_payment_total_amount', true );
				$invoice['invoice_status']   = $payment_status;

				array_push( $payment_invoice, $invoice );
				$metas['ur_payment_invoices'] = $payment_invoice;
			}
			/**
			 * Invoice code ended.
			 */

			foreach ( $metas as $key => $value ) {
				update_user_meta( $user_id, $key, $value );
			}

			do_action( 'user_registration_after_resubscribe', $form_id, $user_id );

			if ( is_plugin_active( 'user-registration-pro/user-registration.php' ) ) {

				$is_payment_compatible = true;
				if ( is_plugin_active( 'user-registration-payments/user-registration-payments.php' ) ) {
					if ( version_compare( URP_VERSION, '1.5.3', '<' ) ) {
						$is_payment_compatible = false;
					}
				}
				if ( UR_PRO_ACTIVE && ( version_compare( UR_VERSION, '4.1.1', '<=' ) || ! $is_payment_compatible ) ) {
					User_Registration_Payments_Process::send_success_email( $user_id );
					User_Registration_Payments_Process::send_success_admin_email( $user_id );
				} else {
					User_Registration_Pro_Frontend::send_success_email( $user_id );
					User_Registration_Pro_Frontend::send_success_admin_email( $user_id );
				}
			}
			wp_send_json_success( array( 'subscription' => $subscription ) );
		} else {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Plan is not created. Please contact to your administrator.', 'user-registration' ),
				)
			);
		}
	}

	/**
	 * Function to update credit card details of the existing customer from the myaccount page.
	 */
	public function update_customer_payment() {

		check_ajax_referer( 'ur_stripe_payment_nonce', 'security' );

		// Operates on the logged-in user's own Stripe customer.
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'user-registration' ) ) );
		}

		$payment_method_id = isset( $_POST['paymentMethod']['id'] ) ? sanitize_text_field( wp_unslash( $_POST['paymentMethod']['id'] ) ) : '';

		if ( empty( $payment_method_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Missing payment method.', 'user-registration' ) ) );
		}

		$user        = wp_get_current_user();
		$customer_id = get_user_meta( $user->ID, 'ur_payment_customer', true );

		if ( empty( $customer_id ) ) {
			wp_send_json_error( array( 'message' => __( 'No payment profile found for this account.', 'user-registration' ) ) );
		}

		$payment_method = \Stripe\PaymentMethod::retrieve( $payment_method_id );
		$payment_method->attach( array( 'customer' => $customer_id ) );

		\Stripe\Customer::update(
			$customer_id,
			array( 'invoice_settings' => array( 'default_payment_method' => $payment_method_id ) )
		);
	}

	/**
	 * Since we replace credit card field with stripe gateway need to check Backward Compatibility in registration form.
	 *
	 * @param array $form_data_array Form Array.
	 * @param int   $form_id Form Id.
	 * @since 1.1.0
	 */
	public function check_backward_compatibility( $form_data_array, $form_id ) {

		foreach ( $form_data_array as $data ) {
			foreach ( $data as $grid_key => $grid_data ) {
				if ( ! is_array( $grid_data ) && ! is_object( $grid_data ) ) {
					continue;
				}
				foreach ( $grid_data as $grid_data_key => $single_item ) {
					if ( isset( $single_item->field_key ) && 'credit_card' === $single_item->field_key ) {
						$single_item->field_key                        = 'stripe_gateway';
						$single_item->general_setting->field_name      = 'stripe_gateway';
						$single_item->general_setting->label           = __( 'Stripe Gateway', 'user-registration' );
						$single_item->advance_setting->custom_class    = '';
						$single_item->advance_setting->payment_methods = array( 'credit_card' );
					}
				}
			}
		}
		return $form_data_array;
	}

	/**
	 * Login message to display on login form
	 *
	 * @param string $message Payment Status Message.
	 * @param object $user Credentials.
	 */
	public function custom_login_message( $message, $user ) {
		if ( isset( $user->ID ) ) {
			$form_id = ur_get_form_id_by_userid( $user->ID );
			// Check if Stripe Recurring payment is enabled or not.
			$recurring_is_enabled = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe_recurring', false ) );
			if ( $recurring_is_enabled ) {
				$subscription_status = get_user_meta( $user->ID, 'ur_payment_subscription_status', true );
				if ( '' !== $subscription_status && 'canceled' == $subscription_status ) {
					$form_id              = ur_get_form_id_by_userid( $user->ID );
					$allow_resubscription = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_stripe_allow_resubscribe', false ) );

					if ( $allow_resubscription ) {
						/* translators: %s: user ID. */
						$message = '<strong>' . __( 'ERROR:', 'user-registration' ) . '</strong> ' . sprintf( __( 'Your subscription has been canceled. If you want to resubscribe the same subscription then process the payment <a id="ur_stripe_resubscribe" data-uid="%s">here</a>', 'user-registration' ), $user->ID );
					} else {
						$message = '<strong>' . __( 'ERROR:', 'user-registration' ) . '</strong> ' . sprintf( __( 'Your subscription has been canceled.', 'user-registration' ) );
					}
				}
			}
		}
		return $message;
	}

	/**
	 * Implement webhook for stripe call back when payment failed or payment succeeded.
	 */
	public function stripe_webhook() {
		$body      = file_get_contents( 'php://input' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Raw request body, required verbatim for signature verification.
		$signature = isset( $_SERVER['HTTP_STRIPE_SIGNATURE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_STRIPE_SIGNATURE'] ) ) : '';

		/**
		 * Filters the Stripe webhook signing secret used for form payments.
		 *
		 * @param string $secret Signing secret.
		 *
		 * @since x.x.x
		 */
		$secret = apply_filters( 'user_registration_stripe_webhook_secret', get_option( 'user_registration_stripe_webhook_secret', '' ) );

		// This endpoint is public, so only Stripe-signed payloads may act on it.
		if ( empty( $secret ) || empty( $signature ) ) {
			status_header( 400 );
			return;
		}

		try {
			$event_json = \Stripe\Webhook::constructEvent( $body, $signature, $secret );
		} catch ( Exception $e ) {
			ur_get_logger()->warning( 'Stripe form payment webhook rejected: ' . $e->getMessage(), array( 'source' => 'ur-stripe' ) );
			status_header( 400 );
			return;
		}

		// constructEvent() already verified this payload, so it is the event; its evt_ ID is not a subscription ID.
		$event       = $event_json;
		$customer_id = isset( $event->data->object->customer ) ? sanitize_text_field( $event->data->object->customer ) : '';

		if ( empty( $customer_id ) ) {
			wp_send_json_success( __FUNCTION__ );
		}

		// Stripe calls this endpoint logged out, so find the member by the customer ID saved at checkout.
		$user_ids = get_users(
			array(
				'meta_key'   => 'ur_payment_customer', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value' => $customer_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'number'     => 1,
				'fields'     => 'ID',
			)
		);
		$user_id  = $user_ids ? absint( $user_ids[0] ) : 0;
		$form_id  = ur_get_form_id_by_userid( $user_id );

		if ( $user_id ) {
			switch ( $event->type ) {
				case 'invoice.payment_succeeded':
					$subscription_id = $this->get_invoice_subscription_id( $event->data->object );
					$subscription    = $subscription_id ? $this->retrieve_webhook_subscription( $subscription_id ) : null;
					if ( $subscription ) {
						$period_end      = $this->get_subscription_period_end( $subscription );
						$last_period_end = (int) get_user_meta( $user_id, 'ur_payment_subscription_period_end', true );
						// The saved expiry is a display string (site timezone, translated month), so the guard compares the UTC period end saved next to it; a replayed event is not applied twice.
						if ( $period_end && $period_end > $last_period_end ) {
							update_user_meta( $user_id, 'ur_payment_subscription_expiry', $this->get_subscription_expiry( $subscription ) );
							update_user_meta( $user_id, 'ur_payment_subscription_period_end', $period_end );
							update_user_meta( $user_id, 'ur_payment_subscription_status', $subscription->status );
							if ( is_plugin_active( 'user-registration-pro/user-registration.php' ) ) {

								$is_payment_compatible = true;
								if ( is_plugin_active( 'user-registration-payments/user-registration-payments.php' ) ) {
									if ( version_compare( URP_VERSION, '1.5.3', '<' ) ) {
										$is_payment_compatible = false;
									}
								}
								if ( UR_PRO_ACTIVE && ( version_compare( UR_VERSION, '4.1.1', '<=' ) || ! $is_payment_compatible ) ) {
									User_Registration_Payments_Process::send_success_email( $user_id );
									User_Registration_Payments_Process::send_success_admin_email( $user_id );
								} else {
									User_Registration_Pro_Frontend::send_success_email( $user_id );
									User_Registration_Pro_Frontend::send_success_admin_email( $user_id );
								}
							}
						}
					}

					/**
					 * Invoice code started.
					 */

					$payment_invoice = $this->flatten_payment_invoices( get_user_meta( $user_id, 'ur_payment_invoices', true ) );

					$invoice['invoice_date'] = date_i18n( 'F j, Y H:i:s' );
					$invoice['invoice_no']   = '';

					$is_recurring_payment = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe_recurring', false ) );
					// Not set in the webhook, so read what was saved at checkout; only an iDEAL payment is a one-off.
					$payment_method = 'ideal' === get_user_meta( $user_id, 'ur_payment_method', true ) ? 'ideal' : 'card';

					$invoice_item = '';

					if ( ! $is_recurring_payment || 'ideal' == $payment_method ) {
						$invoice_item = get_user_meta( $user_id, 'ur_cart_items' );
					} else {
						$invoice_item = get_user_meta( $user_id, 'ur_payment_subscription_plan_name' );
					}
					$invoice['invoice_item']     = $invoice_item;
					$invoice['invoice_amount']   = get_user_meta( $user_id, 'ur_payment_total_amount', true );
					$invoice['invoice_currency'] = get_user_meta( $user_id, 'ur_payment_currency', true );
					$invoice['invoice_status']   = get_user_meta( $user_id, 'ur_payment_subscription_status' );

					array_push( $payment_invoice, $invoice );

					update_user_meta( $user_id, 'ur_payment_invoices', $payment_invoice );

					/**
					 * Invoice code ended.
					 */
					break;
				case 'invoice.payment_failed':
					$subscription_id = $this->get_invoice_subscription_id( $event->data->object );
					$subscription    = $subscription_id ? $this->retrieve_webhook_subscription( $subscription_id ) : null;
					if ( $subscription ) {
						if ( 1 == $event->data->object->attempt_count ) {
							update_user_meta( $user_id, 'ur_payment_subscription_status', $subscription->status );
							if ( is_plugin_active( 'user-registration-pro/user-registration.php' ) ) {
								$is_payment_compatible = true;
								if ( is_plugin_active( 'user-registration-payments/user-registration-payments.php' ) ) {
									if ( version_compare( URP_VERSION, '1.5.3', '<' ) ) {
										$is_payment_compatible = false;
									}
								}
								if ( UR_PRO_ACTIVE && ( version_compare( UR_VERSION, '4.1.1', '<=' ) || ! $is_payment_compatible ) ) {
									User_Registration_Payments_Process::send_pending_email( $user_id );
								} else {
									User_Registration_Pro_Frontend::send_pending_email( $user_id );
								}
							}
						}
					}
					break;
				default:
			}
		}
		wp_send_json_success(
			__FUNCTION__
		);
	}

	/**
	 * Flatten the stored invoice list into a plain list of invoices.
	 *
	 * Reading the meta without the single flag used to wrap the stored list in another array, so every
	 * renewal saved the previous invoices one level deeper. Members already nested are repaired here.
	 *
	 * @param mixed $entries Stored invoices, possibly nested.
	 * @return array
	 */
	private function flatten_payment_invoices( $entries ) {
		$invoices = array();

		foreach ( (array) $entries as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}

			if ( isset( $entry['invoice_date'] ) || isset( $entry['invoice_no'] ) ) {
				$invoices[] = $entry;
			} else {
				$invoices = array_merge( $invoices, $this->flatten_payment_invoices( $entry ) );
			}
		}

		return $invoices;
	}

	/**
	 * Get the subscription ID of an invoice.
	 *
	 * Since Stripe API 2025-03-31.basil it is at `parent.subscription_details.subscription` (and on each line);
	 * older versions send it as `subscription`. Webhook payloads follow the account's API version, so both are read.
	 *
	 * @param \Stripe\Invoice $invoice Invoice from a webhook event.
	 * @return string Empty when the invoice does not belong to a subscription.
	 */
	private function get_invoice_subscription_id( $invoice ) {
		$candidates = array(
			$invoice->parent->subscription_details->subscription ?? null,
			$invoice->subscription ?? null,
			$invoice->lines->data[0]->parent->subscription_item_details->subscription ?? null,
		);

		foreach ( $candidates as $candidate ) {
			// An expanded subscription is an object carrying the ID.
			$candidate = is_object( $candidate ) ? ( $candidate->id ?? '' ) : $candidate;

			if ( is_string( $candidate ) && '' !== $candidate ) {
				return $candidate;
			}
		}

		return '';
	}

	/**
	 * Get the end of the current billing period of a subscription as a timestamp.
	 *
	 * Since Stripe API 2025-03-31.basil `current_period_end` is on the subscription items; older versions
	 * have it on the subscription. Webhook payloads follow the account's API version and requests made by the
	 * bundled library use the version it is pinned to, so both shapes are read.
	 *
	 * @param \Stripe\Subscription $subscription Stripe subscription.
	 * @return int Zero when Stripe sent no period end.
	 */
	private function get_subscription_period_end( $subscription ) {
		$ends = array();

		if ( isset( $subscription->current_period_end ) ) {
			$ends[] = (int) $subscription->current_period_end;
		}

		if ( isset( $subscription->items->data ) && is_iterable( $subscription->items->data ) ) {
			foreach ( $subscription->items->data as $item ) {
				if ( isset( $item->current_period_end ) ) {
					$ends[] = (int) $item->current_period_end;
				}
			}
		}

		return $ends ? max( $ends ) : 0;
	}

	/**
	 * Get the saved expiry date of a subscription.
	 *
	 * @param \Stripe\Subscription $subscription Stripe subscription.
	 * @return string Formatted date, empty when Stripe sent no period end.
	 */
	private function get_subscription_expiry( $subscription ) {
		$period_end = $this->get_subscription_period_end( $subscription );

		return $period_end ? date_i18n( 'F j, Y H:i:s', $period_end ) : '';
	}

	/**
	 * Retrieve a subscription named by a webhook event.
	 *
	 * A subscription that no longer exists is logged and skipped so the event is acknowledged;
	 * any other API error answers 500 so Stripe retries the delivery.
	 *
	 * @param string $subscription_id Stripe subscription ID.
	 * @return \Stripe\Subscription|null
	 */
	private function retrieve_webhook_subscription( $subscription_id ) {
		try {
			return \Stripe\Subscription::retrieve( $subscription_id );
		} catch ( \Stripe\Exception\ApiErrorException $e ) {
			ur_get_logger()->warning( 'Stripe form payment webhook could not load subscription ' . $subscription_id . ': ' . $e->getMessage(), array( 'source' => 'ur-stripe' ) );

			if ( 'resource_missing' !== $e->getStripeCode() ) {
				wp_send_json_error( __FUNCTION__, 500 );
			}

			return null;
		}
	}

	/**
	 * Operate stripe action such as cancel, renew, and reactivation.
	 */
	public function check_my_account_stripe_action() {

		$user_id = get_current_user_id();
		$form_id = ur_get_form_id_by_userid( $user_id );

		// Read the subscription from the current user's own profile; a request-supplied id would let
		// any logged-in user act on somebody else's subscription.
		$subscription_id = get_user_meta( $user_id, 'ur_payment_subscription', true );

		if ( isset( $_GET['stripe_action'] ) ) {

			if ( empty( $_REQUEST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ) ), 'ur_stripe_action' ) ) {
				wp_die( esc_html__( 'Action failed. Please refresh the page and retry.', 'user-registration' ) );
			}

			if ( empty( $subscription_id ) ) {
				wp_die( esc_html__( 'No subscription found for this account.', 'user-registration' ) );
			}

			switch ( $_GET['stripe_action'] ) {
				case 'reactivation':
					\Stripe\Subscription::update(
						$subscription_id,
						array(
							'cancel_at_period_end' => false,
						)
					);
					update_user_meta( $user_id, 'ur_payment_subscription_status', 'active' );
					ur_add_notice( __( 'Subscriptions is active.', 'user-registration' ), 'success' );

					break;
				case 'cancellation':
					$cancellation_action = ur_get_single_post_meta( $form_id, 'user_registration_stripe_cancellation_action', 'end_of_cycle' );

					if ( 'end_of_cycle' === $cancellation_action ) {
						\Stripe\Subscription::update(
							$subscription_id,
							array(
								'cancel_at_period_end' => true,
							)
						);
						update_user_meta( $user_id, 'ur_payment_subscription_status', 'cancel_at_end_of_cycle' );
						ur_add_notice( __( 'Subscriptions will be cancel at the end of billing cycle.', 'user-registration' ), 'success' );

					} else {
						$subscription_status = get_user_meta( $user_id, 'ur_payment_subscription_status' );
						if ( 'canceled' !== $subscription_status ) {
							$subscription = \Stripe\Subscription::retrieve( $subscription_id );
							$subscription->cancel();
							if ( isset( $subscription->status ) && 'canceled' === $subscription->status ) {
								update_user_meta( $user_id, 'ur_payment_subscription_status', $subscription->status );
								ur_add_notice( __( 'Subscriptions has been cancelled.', 'user-registration' ), 'success' );
							}
						}
					}
					break;
				default:
			}
		}
	}

	/**
	 * Process entry for stripe payment.
	 *
	 * @param array $success_params Success Params.
	 * @param array $valid_form_data Form Data.
	 * @param int   $form_id Form Id.
	 * @param int   $user_id User Id.
	 */
	public function stripe_process( $success_params, $valid_form_data, $form_id, $user_id ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Runs inside the registration submission, which UR verifies before this filter fires.

		// Set login option if not set before.
		$login_option                        = isset( $success_params['form_login_option'] ) ? $success_params['form_login_option'] : ur_get_user_login_option( $user_id );
		$success_params['form_login_option'] = $login_option;
		$success_params['message']           = get_option( 'user_registration_payment_before_registration_pending_message', esc_html( 'User Registered. Payment Processing...' ) );
		$success_params['form_id']           = $form_id;
		// Check if Stripe payment is enabled or not.
		$stripe_is_enabled = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe', false ) );

		if ( isset( $_POST['ur_stripe_payment_method'] ) && $stripe_is_enabled ) {

			// Get data from form settings.
			$currency = get_option( 'user_registration_payment_currency', 'USD' );
			$amount   = user_registration_sanitize_amount( 0, $currency );
			$items    = array();

			$quantities     = array();
			$coupon_details = array();
			foreach ( $valid_form_data as $field_data ) {
				if ( isset( $field_data->extra_params['field_key'] ) && ( 'quantity_field' === $field_data->extra_params['field_key'] ) ) {
					$target_name                = $field_data->extra_params['target_field'];
					$quantities[ $target_name ] = $field_data->value;
				}
				if ( isset( $field_data->extra_params['field_key'] ) && ( 'coupon' === $field_data->extra_params['field_key'] ) && ( function_exists( 'ur_check_module_activation' ) && ur_check_module_activation( 'coupon' ) ) ) {
					$coupon_details = ur_get_coupon_details( $field_data->value );
					// validate if coupon is applied for this form or not.
					if ( ! empty( $coupon_details ) && ( 'form' !== $coupon_details['coupon_for'] || ! in_array( $form_id, json_decode( $coupon_details['coupon_form'], true ) ) ) ) {
						$coupon_details = array();
					}
				}
			}

			foreach ( $valid_form_data as $form_data ) {

				$payment_slider = check_is_range_payment_slider( $form_data->field_name, $form_id );

				$urcl_hide_fields = isset( $_POST['urcl_hide_fields'] ) ? (array) json_decode( sanitize_textarea_field( wp_unslash( $_POST['urcl_hide_fields'] ) ), true ) : array();

				if ( ! in_array( $form_data->field_name, $urcl_hide_fields, true ) ) {
					if ( isset( $form_data->extra_params['field_key'] ) && ( 'single_item' === $form_data->extra_params['field_key'] || ( 'range' === $form_data->extra_params['field_key'] && $payment_slider ) || 'multiple_choice' === $form_data->extra_params['field_key'] || 'subscription_plan' === $form_data->extra_params['field_key'] ) ) {
						$item_amount = json_decode( $form_data->value );

						if ( 'subscription_plan' === $form_data->extra_params['field_key'] ) {
							$subscription_data = ! is_array( $item_amount ) ? explode( ':', $item_amount ) : $item_amount;
							if ( isset( $subscription_data[1] ) ) {
								$selected_options                        = array();
								$subscription_label                      = isset( $subscription_data[0] ) ? $subscription_data[0] : '';
								$subscription_amount                     = isset( $subscription_data[1] ) ? $subscription_data[1] : 0;
								$selected_options[ $subscription_label ] = $subscription_amount;
								$form_data->value                        = $selected_options;
								$item_amount                             = $subscription_amount;
							}
						}

						if ( is_array( $item_amount ) ) {
							$multiple_choice_amount = 0;
							$selected_options       = array();
							$multiple_choice_data   = ur_get_field_data_by_field_name( $form_id, $form_data->field_name );
							$multiple_choice_option = $multiple_choice_data['general_setting']->options;

							foreach ( $item_amount as $key => $option_choice ) {
								$options_data                      = explode( ':', $option_choice );
								$option_label                      = isset( $options_data[0] ) ? $options_data[0] : '';
								$option_amount                     = isset( $options_data[1] ) ? $options_data[1] : $option_choice;
								$multiple_choice_amount            = $multiple_choice_amount + $option_amount;
								$selected_options[ $option_label ] = $option_amount;
							}
							$form_data->value = $selected_options;
							$item_amount      = $multiple_choice_amount;
						}
						$quantity = 0;
						if ( array_key_exists( $form_data->field_name, $quantities ) ) {
							if ( absint( $quantities[ $form_data->field_name ] ) > -1 ) {
								$quantity = absint( $quantities[ $form_data->field_name ] );
							}

							$form_data->quantity = $quantity;
							$item_amount         = $item_amount * $quantity;
						}
						if ( 0 < $quantity ) {
							$form_data->extra_params['quantity'] = $quantity;
						}

						if ( 0 < $quantity ) {
							$form_data->extra_params['quantity'] = $quantity;
						}
						$form_data->amount = $item_amount;
						$items[]           = $form_data;
						$amount            = $amount + user_registration_sanitize_amount( $item_amount, $currency );
						$has_payment_field = true;
					}
				}
			}
			$product_amount = $amount;
			if ( ! empty( $coupon_details ) ) {
				$amount = $this->calculate_coupon_discount( $coupon_details, $amount );
			}

			if ( $amount <= 0 ) {
				wp_delete_user( absint( $user_id ) );
				wp_send_json_error(
					array(
						'message' => __( 'Stripe Payment stopped, Total amount after discount cannot be less than or equals to Zero.', 'user-registration' ),
					)
				);
			}

			// Return if form doesnot contain any payment fields.
			if ( ! isset( $has_payment_field ) ) {
				wp_delete_user( absint( $user_id ) );
				wp_send_json_error(
					array(
						'message' => __( 'Stripe Payment stopped, missing payment fields', 'user-registration' ),
					)
				);
			}

			// Return if invalid amount.
			if ( ( empty( $amount ) || user_registration_sanitize_amount( 0, $currency ) == $amount ) ) {
				wp_delete_user( absint( $user_id ) );
				wp_send_json_error(
					array(
						'message' => __( 'Stripe Payment stopped, Invalid/Empty amount', 'user-registration' ),
					)
				);
			}

			$payment_method = sanitize_text_field( wp_unslash( $_POST['ur_stripe_payment_method'] ) );

			if ( ! ur_string_to_bool( get_option( 'user_registration_stripe_test_mode' ) ) ) {
				$payment_mode = __( 'live', 'user-registration' );
			} else {
				$payment_mode = __( 'test', 'user-registration' );
			}

			$payment_status = 'pending';

			// Update entry to include payment details.
			$metas = array(
				'ur_payment_status'         => $payment_status,
				'ur_payment_total_amount'   => $amount,
				'ur_payment_product_amount' => $product_amount,
				'ur_payment_currency'       => $currency,
				'ur_payment_method'         => $payment_method,
				'ur_payment_mode'           => $payment_mode,
				'ur_cart_items'             => wp_json_encode( $items ),
			);
			if ( ! empty( $coupon_details ) ) {
				$coupon_meta = array(
					'ur_coupon_discount_type' => $coupon_details['coupon_discount_type'],
					'ur_coupon_discount'      => $coupon_details['coupon_discount'],
					'ur_coupon_code'          => $coupon_details['coupon_code'],
				);
				$metas       = array_merge( $metas, $coupon_meta );
			}

			// Update Payment Details.
			foreach ( $metas as $key => $value ) {
				update_user_meta( $user_id, $key, $value );
			}

			$success_params['user_id']         = $user_id;
			$success_params['form_id']         = $form_id;
			$success_params['payment_process'] = true;
			$success_params['stripe_process']  = true;
			// Check if Stripe Recurring payment is enabled or not.
			$is_recurring_payment = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe_recurring', false ) );
			$payment_method       = 'credit_card' === $payment_method ? 'card' : 'ideal';

			if ( $is_recurring_payment ) {
				$form_id = $success_params['form_id'] ?? 0;
				$user_id = $success_params['user_id'] ?? 0;

				$uuid                   = wp_generate_uuid4();
				$raw_stripe_token       = sprintf( '%d|%d|%s', $user_id, $form_id, $uuid );
				$processed_stripe_token = hash( 'sha256', $raw_stripe_token );

				set_transient( 'ur_stripe_user_uuid_' . $user_id, $uuid, 15 * MINUTE_IN_SECONDS );
				set_transient( 'ur_stripe_user_generated_hash_' . $user_id, $processed_stripe_token, 15 * MINUTE_IN_SECONDS );
			}

			if ( ! $is_recurring_payment || 'ideal' == $payment_method ) {
				/**
				 * Create Payment Intent.
				 */
				try {

					$user       = get_user_by( 'id', $user_id );
					$user_email = $user ? $user->user_email : '';
					if ( ! empty( $user_email ) ) {
						$customer = \Stripe\Customer::create(
							array(
								'email' => $user_email,
							)
						);

						if ( 'JPY' === $currency ) {
							$amount = abs( $amount );
						} else {
							$amount = abs( $amount ) * 100;
						}

						$intent = \Stripe\PaymentIntent::create(
							array(
								'amount'               => $amount,
								'currency'             => $currency,
								'payment_method_types' => array( $payment_method ),
								'customer'             => $customer->id,
							)
						);

						$success_params['clientSecret'] = $intent->client_secret;
					}
				} catch ( Exception $e ) {
					wp_delete_user( absint( $user_id ) );
					wp_send_json_error(
						array(
							'message' => $e->getMessage(),
						)
					);
				}
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return $success_params;
	}

	/**
	 * Apply a coupon discount to an amount.
	 *
	 * @param array $coupon_details Details regarding the applied coupon.
	 * @param mixed $amount         Amount to be calculated with.
	 *
	 * @return float|int|mixed
	 */
	public function calculate_coupon_discount( $coupon_details, $amount ) {
		if ( 'fixed' === $coupon_details['coupon_discount_type'] ) {
			$amount = $amount - $coupon_details['coupon_discount'];
		} elseif ( 'percent' === $coupon_details['coupon_discount_type'] ) {
			$amount = $amount - ( $amount * $coupon_details['coupon_discount'] / 100 );
		}
		return $amount;
	}

	/**
	 * Render the payment fields on frontend
	 *
	 * @param string $field Field.
	 * @param string $key Field name.
	 * @param array  $args Arguments.
	 * @param mixed  $value Default value.
	 * @return void
	 */
	public function user_registration_stripe_form_field_render( $field, $key, $args, $value ) {
		/* Conditional Logic codes */
		$rules                      = array();
		$form_id                    = isset( $args['form_id'] ) ? $args['form_id'] : '';
		$rules['conditional_rules'] = isset( $args['conditional_rules'] ) ? $args['conditional_rules'] : '';
		$rules['logic_gate']        = isset( $args['logic_gate'] ) ? $args['logic_gate'] : '';
		$rules['rules']             = isset( $args['rules'] ) ? $args['rules'] : array();
		$rules['required']          = isset( $args['required'] ) ? $args['required'] : '';

		foreach ( $rules['rules'] as $rules_key => $rule ) {
			if ( empty( $rule['field'] ) ) {
				unset( $rules['rules'][ $rules_key ] );
			}
		}

		if ( true === $args['required'] ) {
			$args['class'][] = 'validate-required';
			$required        = ' <abbr class="required" title="' . esc_attr__( 'required', 'user-registration' ) . '">*</abbr>';
		} else {
			$required = '';
		}

		$rules['rules'] = array_values( $rules['rules'] );

		$rules = ( ! empty( $rules['rules'] ) && isset( $args['enable_conditional_logic'] ) ) ? wp_json_encode( $rules ) : '';
		/*Conditonal Logic codes end*/
		$stripe_gateways = stripe_gateway_info();

		// Check if PayPal payment is enabled or not.
		$paypal_is_enabled = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_paypal_standard', false ) );
		// Check if Stripe payment is enabled or not.
		$stripe_is_enabled = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe', false ) );
		// check paypal payment condition logic.
		$paypal_integration = get_post_meta( $form_id, 'user_registration_paypal_conditional_integration', true );
		$stripe_integration = get_post_meta( $form_id, 'user_registration_stripe_conditional_integration', true );

		if ( ( ! $paypal_is_enabled && $stripe_is_enabled && ! empty( $stripe_gateways ) ) || ( ( $paypal_is_enabled && $stripe_is_enabled && ! empty( $stripe_gateways ) ) && ur_string_to_bool( $paypal_integration[0]['enable_conditional_logic'] ) && ur_string_to_bool( $stripe_integration[0]['enable_conditional_logic'] ) ) ) {
			$field_label = '';

			$tooltip_html = '';

			if ( isset( $args['tooltip'] ) && ur_string_to_bool( $args['tooltip'] ) ) {
				$tooltip_html = ur_help_tip( $args['tooltip_message'], false, 'ur-portal-tooltip' );
			}

			if ( $args['label'] ) {
				$field_label .= '<label class="ur-label" for="' . esc_attr( $args['label'] ) . '">' .
					ur_string_translation(
						$form_id,
						'user_registration_' . $args['field_name'] . '_label',
						wp_kses(
							$args['label'],
							array(
								'a'    => array(
									'href'  => array(),
									'title' => array(),
								),
								'span' => array(),
							)
						)
					)
					. $required . $tooltip_html . '</label>';
			}

			$tabs = '';

			if ( is_array( $args['payment_methods'] ) && ! empty( $args['payment_methods'] ) ) {
				$tabs .= '<div class="ur-tab-picker">';
				foreach ( $args['payment_methods'] as $key => $payment_method ) {

					$tabs .= '<button class="ur-tab-button" id="' . $payment_method . '" >';
					$tabs .= ( 'credit_card' === $payment_method ) ? 'Credit Card' : 'iDEAL';
					$tabs .= '</button>';
				}
				$tabs .= '</div>';

				$tabs .= '<div class="ur-tab-content">';
				foreach ( $args['payment_methods'] as $key => $payment_method ) {
					$tabs .= '<div data-id="' . $payment_method . '">';
					$tabs .= '</div>';
				}
				$tabs .= '</div>';
			}

			$field_content = sprintf(
				'%s
				<div id="user_registration_%s_gateway" data-gateway="%s" class="input-text" conditional_rules="%s">
				 %s
				</div>',
				$field_label,
				esc_attr( $stripe_gateways ),
				esc_attr( $stripe_gateways ),
				esc_attr( $rules ),
				$tabs
			);

			$cl_outer_attrs = '';
			if ( is_array( $stripe_integration ) && isset( $stripe_integration[0]['enable_conditional_logic'] ) && ur_string_to_bool( $stripe_integration[0]['enable_conditional_logic'] ) ) {
				$cl_data = isset( $stripe_integration[0]['conditional_logic_data'] ) ? $stripe_integration[0]['conditional_logic_data'] : array();
				if ( ! empty( $cl_data['conditional_field'] ) ) {
					$cl_map         = array(
						'action'    => 'show',
						'logic_map' => array(
							'type'       => 'group',
							'logic_gate' => 'OR',
							'conditions' => array(
								array(
									'type'         => 'field',
									'triggerer_id' => $cl_data['conditional_field'],
									'operator'     => isset( $cl_data['conditional_operator'] ) ? $cl_data['conditional_operator'] : 'is',
									'value'        => isset( $cl_data['conditional_value'] ) ? $cl_data['conditional_value'] : '',
								),
							),
						),
					);
					$cl_outer_attrs = sprintf(
						'data-field-id="stripe_gateway" data-conditional-logic-enabled="1" data-conditional-logic-map="%s"',
						esc_attr( wp_json_encode( $cl_map ) )
					);
				}
			}

			// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Attributes built above with esc_attr(); field markup already rendered by the field class.
			printf(
				"<div class='form-row%s' id='%s_field' %s>%s</div>",
				$cl_outer_attrs ? ' ur-field-item' : '',
				esc_attr( $args['type'] ),
				$cl_outer_attrs,
				$field_content
			);
			// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	/**
	 * Add arguments to the stripe fields for frontend filter
	 *
	 * @param array $filter_data Filter Data.
	 * @return array
	 */
	public function user_registration_stripe_form_field_filter( $filter_data ) {
		if ( isset( $filter_data['form_data']['form_id'] ) ) {
			$form_id = $filter_data['form_data']['form_id'];
			// Check if PayPal payment is enabled or not.
			$paypal_is_enabled = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_paypal_standard', false ) );

			// Check if Stripe payment is enabled or not.
			$stripe_is_enabled = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe', false ) );

			$stripe_integration = get_post_meta( $form_id, 'user_registration_stripe_conditional_integration', true );
			$paypal_integration = get_post_meta( $form_id, 'user_registration_paypal_conditional_integration', true );

			if ( ! $paypal_is_enabled && $stripe_is_enabled ) {
				$filter_data['form_data']['payment_methods'] = isset( $filter_data['data']['advance_setting']->payment_methods ) ? $filter_data['data']['advance_setting']->payment_methods : array();
			} elseif ( $paypal_is_enabled && $stripe_is_enabled && ur_string_to_bool( $paypal_integration[0]['enable_conditional_logic'] ) && ur_string_to_bool( $stripe_integration[0]['enable_conditional_logic'] ) ) {
				$filter_data['form_data']['payment_methods'] = isset( $filter_data['data']['advance_setting']->payment_methods ) ? $filter_data['data']['advance_setting']->payment_methods : array();
			}
		}
		return $filter_data;
	}

	/**
	 * Process stripe payment on sucessful authorizaion.
	 *
	 * @param string $payment_id Stripe Intent ID.
	 * @param array  $total_amount Total Amount.
	 *
	 * @return mixed $charge Charge Info.
	 */
	public function process_payment( $payment_id, $total_amount ) {

		// Creates the charge based on authorization info.
		$intent = \Stripe\PaymentIntent::retrieve( $payment_id );

		return $intent;
	}

	/**
	 * Process stripe recurring payment on sucessful authorizaion.
	 *
	 * @param string $subscription_id Stripe Subscription Id.
	 *
	 * @return array $charge Charge Info.
	 */
	public function process_recurring_payment( $subscription_id ) {

		$subscription = \Stripe\Subscription::retrieve( $subscription_id );
		return $subscription;
	}

	/**
	 * Create customer via ajax.
	 *
	 * @return void
	 */
	public function create_customer() {
		check_ajax_referer( 'ur_stripe_payment_nonce', 'security' );
		$form_id = isset( $_POST['form_id'] ) ? absint( wp_unslash( $_POST['form_id'] ) ) : 0;

		$customer_data = isset( $_POST['customer_data'] ) ? ur_clean( wp_unslash( $_POST['customer_data'] ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified at the top of this handler; ur_clean() sanitizes recursively.
		$user_id       = isset( $_POST['user_id'] ) ? absint( wp_unslash( $_POST['user_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$user          = get_user_by( 'id', $user_id );

		$enable_sync_fields_with_stripe = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_sync_fields_with_stripe', false ) );
		$customer_details               = array();

		$user_stripe_uuid = get_transient( 'ur_stripe_user_uuid_' . $user_id );
		$stored_hash      = get_transient( 'ur_stripe_user_generated_hash_' . $user_id );

		if ( ! $user_stripe_uuid ) {
			wp_send_json_error(
				array(
					'message' => 'Invalid request',
				),
				403
			);
		}

		$expected_raw_token = sprintf(
			'%d|%d|%s',
			$user_id,
			$form_id,
			$user_stripe_uuid
		);

		$expected_hash = hash( 'sha256', $expected_raw_token );

		if ( ! hash_equals( $expected_hash, $stored_hash ) ) {
			wp_send_json_error(
				array(
					'message' => 'Invalid request',
				),
				403
			);
		}

		if ( $enable_sync_fields_with_stripe && ! empty( $customer_data ) ) {
			$customer_details = array(
				'email'       => $user->data->user_email,
				'name'        => $customer_data['full_name'],
				'description' => $customer_data['description'],
				'phone'       => $customer_data['phone'],
				'address'     => array(
					'city'        => $customer_data['city'],
					'country'     => $customer_data['country'],
					'line1'       => $customer_data['line1'],
					'line2'       => $customer_data['line2'],
					'postal_code' => $customer_data['postal_code'],
					'state'       => $customer_data['state'],
				),
				'shipping'    => array(
					'address' => array(
						'city'        => $customer_data['shipping_city'],
						'country'     => $customer_data['shipping_country'],
						'line1'       => $customer_data['shipping_line1'],
						'line2'       => $customer_data['shipping_line2'],
						'postal_code' => $customer_data['shipping_postal_code'],
						'state'       => $customer_data['shipping_state'],
					),
					'name'    => $customer_data['shipping_full_name'],
					'phone'   => $customer_data['shipping_phone'],
				),
			);
		} else {
			$customer_details = array(
				'email' => $user->data->user_email,
			);
		}

		$customer_details = apply_filters( 'urm_stripe_customer_details', $customer_details, $user_id );

		$customer = \Stripe\Customer::create(
			$customer_details
		);

		// Persist so create_subscription() can read it from meta (never from the request).
		if ( $user_id && ! empty( $customer->id ) ) {
			update_user_meta( $user_id, 'ur_payment_customer', sanitize_text_field( $customer->id ) );
		}

		wp_send_json_success( array( 'customer' => $customer ) );
	}

	/**
	 * Create a new Subscription.
	 */
	public function create_subscription() {

		check_ajax_referer( 'ur_stripe_payment_nonce', 'security' );

		$payment_method_id = isset( $_POST['payment_method_id'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_method_id'] ) ) : '';
		$form_id           = isset( $_POST['form_id'] ) ? absint( wp_unslash( $_POST['form_id'] ) ) : 0;
		$user_id           = isset( $_POST['user_id'] ) ? absint( wp_unslash( $_POST['user_id'] ) ) : 0;

		// Read the customer from the profile create_customer() wrote, never from the request.
		$customer_id = $user_id ? get_user_meta( $user_id, 'ur_payment_customer', true ) : '';

		if ( empty( $customer_id ) ) {
			wp_send_json_error( array( 'message' => __( 'No payment profile found for this account.', 'user-registration' ) ) );
		}

		$existing_subscription_products = ur_get_single_post_meta( $form_id, 'user_registration_subscription_products', array() );
		$total_amount                   = get_user_meta( $user_id, 'ur_payment_total_amount', true );
		$currency                       = get_option( 'user_registration_payment_currency', 'USD' );

		$logger = ur_get_logger();
		$logger->debug(
			sprintf( '[User #%d] create_subscription amount debug.', $user_id ) . "\n" . wp_json_encode(
				array(
					'total_amount_raw' => $total_amount,
					'unit_amount_calc' => (int) round( floatval( $total_amount ) * 100 ),
					'currency'         => $currency,
					'form_id'          => $form_id,
				),
				JSON_PRETTY_PRINT
			),
			array( 'source' => 'urm-pg-stripe' )
		);

		$ur_cart_items = json_decode( get_user_meta( $user_id, 'ur_cart_items', true ) );
		$plan_name     = '';

		if ( ! empty( $ur_cart_items ) ) {
			foreach ( $ur_cart_items as $key => $payment_items ) {
				if ( 'subscription_plan' === $payment_items->extra_params->field_key ) {
					foreach ( $payment_items->value as $plan_name => $value ) {
						$plan_name = $plan_name;
					}
				}
			}
		}

		if ( is_array( $existing_subscription_products ) && ! empty( $existing_subscription_products ) ) {
			foreach ( $existing_subscription_products as $key => $subscription_products ) {
				if ( ! empty( $plan_name ) && $plan_name !== $subscription_products['plan_name'] ) {
					continue;
				}
				try {
					$price_list = \Stripe\Price::all(
						array(
							'product' => $subscription_products['product_id'],
						)
					);

					$is_price_already_exits = false;
					$price_id               = 0;

					// Keep dollars in $total_amount; cents belong in a local so a later
					// product in this loop cannot *100 the already-converted value again
					// (101 → 10_100 → 1_010_000).
					if ( 'JPY' === $currency ) {
						$unit_amount = (int) round( floatval( $total_amount ) );
					} else {
						$unit_amount = (int) round( floatval( $total_amount ) * 100 );
					}

					if ( isset( $price_list->data ) && is_array( $price_list->data ) ) {
						$price_data = $price_list->data;

						$logger->debug(
							sprintf( '[User #%d] Price matching.', $user_id ) . "\n" . wp_json_encode(
								array(
									'looking_for_unit_amount' => $unit_amount,
									'currency'         => $currency,
									'available_prices' => array_map(
										function ( $p ) {
											return array(
												'id'       => $p->id,
												'unit_amount' => $p->unit_amount,
												'currency' => $p->currency,
											);
										},
										$price_data
									),
								),
								JSON_PRETTY_PRINT
							),
							array( 'source' => 'urm-pg-stripe' )
						);

						foreach ( $price_data as $key => $price ) {
							if ( $price->unit_amount == $unit_amount && 'recurring' === $price->type ) {
								$is_price_already_exits = true;
								$price_id               = $price->id;
								break;
							}
						}
					}

					if ( ! $is_price_already_exits && 0 === $price_id ) {
						$create_period         = $subscription_products['period'];
						$create_interval_count = (int) $subscription_products['interval_count'];
						if ( 'year' === $create_period && $create_interval_count > 3 ) {
							$create_interval_count = $create_interval_count * 12;
							$create_period         = 'month';
						}
						$price    = \Stripe\Price::create(
							array(
								'product'     => $subscription_products['product_id'],
								'unit_amount' => $unit_amount,
								'currency'    => $currency,
								'recurring'   => array(
									'interval'       => $create_period,
									'interval_count' => $create_interval_count,
								),
							)
						);
						$price_id = $price->id;
					}

					$customer       = \Stripe\Customer::retrieve( $customer_id );
					$payment_method = \Stripe\PaymentMethod::retrieve( $payment_method_id );
					$payment_method->attach(
						array(
							'customer' => $customer->id,
						)
					);

					\Stripe\Customer::update(
						$customer->id,
						array(
							'invoice_settings' => array(
								'default_payment_method' => $payment_method->id,
							),
						)
					);
					$logger = ur_get_logger();
					$logger->debug(
						sprintf( '[User #%d] Creating Stripe subscription.', $user_id ) . "\n" . wp_json_encode(
							array(
								'user_id'     => $user_id,
								'price_id'    => $price_id,
								'customer_id' => $customer->id,
							),
							JSON_PRETTY_PRINT
						),
						array( 'source' => 'urm-pg-stripe' )
					);

					$subscription_args = array(
						'customer' => $customer->id,
						'items'    => array(
							array(
								'price' => $price_id,
							),
						),
						'expand'   => array( 'latest_invoice.payment_intent', 'latest_invoice.payments' ),
					);

					if ( isset( $subscription_products['trail_period'] ) ) {
						$interval                       = $subscription_products['trail_interval_count'];
						$period                         = $subscription_products['trail_period'];
						$trail_period                   = strtotime( gmdate( 'Y-m-d H:i:s', strtotime( "+$interval $period" ) ) );
						$subscription_args['trial_end'] = $trail_period;

						if ( isset( $subscription_products['exact_expiry_date_enable'] ) && 'on' === $subscription_products['exact_expiry_date_enable'] && isset( $subscription_products['exact_expiry_date'] ) ) {
							$exact_expiry_date              = strtotime( $subscription_products['exact_expiry_date'] );
							$subscription_args['cancel_at'] = $exact_expiry_date;
						}
					} elseif ( isset( $subscription_products['exact_expiry_date_enable'] ) && 'on' === $subscription_products['exact_expiry_date_enable'] && isset( $subscription_products['exact_expiry_date'] ) ) {
						$exact_expiry_date                       = strtotime( $subscription_products['exact_expiry_date'] );
						$metas['ur_payment_subscription_expiry'] = gmdate( 'F j, Y H:i:s', strtotime( $exact_expiry_date ) );
						$subscription_args['cancel_at']          = $exact_expiry_date;
					}

					$subscription = \Stripe\Subscription::create( $subscription_args );

					$logger->info(
						sprintf( '[User #%d] Stripe subscription created.', $user_id ) . "\n" . wp_json_encode(
							array(
								'user_id'         => $user_id,
								'subscription_id' => $subscription->id ?? null,
								'status'          => $subscription->status ?? null,
							),
							JSON_PRETTY_PRINT
						),
						array( 'source' => 'urm-pg-stripe' )
					);
					$subscription_status = isset( $subscription->status ) ? $subscription->status : '';
					if ( isset( $subscription->status ) && 'trialing' === $subscription->status ) {
						$subscription_status                          = 'Trial';
						$metas['ur_payment_subscription_trail_start'] = isset( $subscription->trial_start ) ? date_i18n( 'F j, Y H:i:s', $subscription->trial_start ) : '';
						$metas['ur_payment_subscription_trail_end']   = isset( $subscription->trial_end ) ? date_i18n( 'F j, Y H:i:s', $subscription->trial_end ) : '';
					}

					$metas['ur_payment_subscription']           = isset( $subscription->id ) ? $subscription->id : '';
					$metas['ur_payment_customer']               = isset( $subscription->customer ) ? $subscription->customer : '';
					$metas['ur_payment_interval']               = $subscription_products['interval_count'] . ' ' . $subscription_products['period'];
					$metas['ur_payment_subscription_status']    = $subscription_status;
					$metas['ur_payment_subscription_plan_name'] = $subscription_products['plan_name'];
					$metas['ur_payment_subscription_expiry']    = $this->get_subscription_expiry( $subscription );

					// UTC period end, so a replayed renewal event is not applied twice.
					$metas['ur_payment_subscription_period_end'] = $this->get_subscription_period_end( $subscription );
					if ( isset( $subscription->status ) && 'trialing' === $subscription->status ) {
						$metas['ur_payment_subscription_expiry'] = gmdate( 'F j, Y H:i:s', strtotime( '+' . $subscription_products['interval_count'] . $subscription_products['period'], $subscription->trial_end ) );
					}
					if ( isset( $subscription_products['exact_expiry_date'] ) && '' !== $subscription_products['exact_expiry_date'] ) {
						$exact_expiry_date                       = trim( strtotime( $subscription_products['exact_expiry_date'] ) );
						$metas['ur_payment_subscription_expiry'] = gmdate( 'F j, Y H:i:s', ( $exact_expiry_date ) );
					}

					// One registration → one subscription. Extra products in the form
					// setting must not run another Price/Subscription create.
					break;
				} catch ( Exception $e ) {
					wp_delete_user( absint( $user_id ) );
					$customer = \Stripe\Customer::retrieve( $customer_id );
					$customer->delete();
					wp_send_json_error( $e->getMessage(), 400 );
				}
			}
			$payment_status             = 'completed';
			$metas['ur_payment_status'] = $payment_status;

			// Try classic path first, then fall back to newer Stripe Billing path.
			$_pi    = isset( $subscription->latest_invoice->payment_intent ) ? $subscription->latest_invoice->payment_intent : null;
			$_pi_id = is_object( $_pi ) ? ( isset( $_pi->id ) ? $_pi->id : '' ) : ( is_string( $_pi ) ? $_pi : '' );

			if ( empty( $_pi_id ) ) {
				$_payments_data = isset( $subscription->latest_invoice->payments->data ) ? $subscription->latest_invoice->payments->data : array();
				if ( ! empty( $_payments_data ) ) {
					$_pi_new = isset( $_payments_data[0]->payment->payment_intent ) ? $_payments_data[0]->payment->payment_intent : null;
					$_pi_id  = is_object( $_pi_new ) ? ( isset( $_pi_new->id ) ? $_pi_new->id : '' ) : ( is_string( $_pi_new ) ? $_pi_new : '' );
				}
			}

			$metas['ur_payment_transaction'] = ! empty( $_pi_id ) ? $_pi_id : ( isset( $subscription->id ) ? $subscription->id : '' );

			// Sync ur_payment_total_amount to the actual Stripe charge (handles proration, local currency, etc.).
			if ( ! empty( $_pi_id ) && 'trialing' !== ( $subscription->status ?? '' ) ) {
				try {
					$_pi_obj = \Stripe\PaymentIntent::retrieve( $_pi_id );
					if ( isset( $_pi_obj->amount ) && $_pi_obj->amount > 0 ) {
						update_user_meta( $user_id, 'ur_payment_total_amount', number_format( $_pi_obj->amount / 100, 2, '.', '' ) );
					}
				} catch ( \Exception $e ) {
					// Non-critical, the stored amount stays as the plan price.
					ur_get_logger()->debug( 'Stripe payment intent lookup failed: ' . $e->getMessage(), array( 'source' => 'urm-pg-stripe' ) );
				}
			}

			/**
			 * Invoice code started.
			 */
			if ( 'active' === $subscription->status ) {
				$payment_invoice = array();

				$invoice['invoice_date'] = gmdate( 'Y-m-d H:i:s' );
				$invoice['invoice_no']   = ! empty( $_pi_id ) ? $_pi_id : ( isset( $subscription->id ) ? $subscription->id : '' );

				$invoice_item = get_user_meta( $user_id, 'ur_cart_items' );

				$invoice['invoice_plan']     = $metas['ur_payment_subscription_plan_name'];
				$invoice['invoice_item']     = $invoice_item;
				$invoice['invoice_currency'] = get_user_meta( $user_id, 'ur_payment_currency', true );
				$invoice['invoice_amount']   = get_user_meta( $user_id, 'ur_payment_total_amount', true );
				$invoice['invoice_status']   = $payment_status;

				array_push( $payment_invoice, $invoice );
				$metas['ur_payment_invoices'] = $payment_invoice;
			}
			/**
			 * Invoice code ended.
			 */

			foreach ( $metas as $key => $value ) {
				update_user_meta( $user_id, $key, $value );
			}

			wp_send_json_success( array( 'subscription' => $subscription ) );
		} else {
			wp_delete_user( absint( $user_id ) );
			wp_send_json_error(
				esc_html__( 'Plan is not created. Please contact to your administrator.', 'user-registration' ),
				400
			);
		}
	}

	/**
	 * Verify payment with Stripe API to ensure it's legitimate.
	 *
	 * @param string $transaction_id The Stripe payment intent ID.
	 * @param string $payment_method The payment method (card or ideal).
	 * @param int    $user_id The user ID to verify against.
	 * @param string $expected_status The expected payment status.
	 *
	 * @return array Array with 'success' boolean and 'message' string.
	 */
	private function verify_stripe_payment( $transaction_id, $payment_method, $user_id, $expected_status ) {
		$logger = ur_get_logger();

		$logger->debug(
			sprintf( '[User #%d] Starting Stripe payment verification.', $user_id ) . "\n" . wp_json_encode(
				array(
					'transaction_id'  => $transaction_id,
					'payment_method'  => $payment_method,
					'user_id'         => $user_id,
					'expected_status' => $expected_status,
				),
				JSON_PRETTY_PRINT
			),
			array(
				'source' => 'urm-pg-stripe',
			)
		);

		try {
			// Retrieve the payment intent from Stripe.
			$logger->info(
				sprintf( '[User #%d] Retrieving payment intent from Stripe API', $user_id ) . "\n" . wp_json_encode(
					array(
						'transaction_id'  => $transaction_id,
						'payment_method'  => $payment_method,
						'user_id'         => $user_id,
						'expected_status' => $expected_status,
					),
					JSON_PRETTY_PRINT
				),
				array(
					'source' => 'urm-pg-stripe',
				)
			);

			$payment_intent = \Stripe\PaymentIntent::retrieve( $transaction_id );

			$logger->info(
				sprintf( '[User #%d] Payment intent retrieved successfully.', $user_id ) . "\n" . wp_json_encode(
					array(
						'transaction_id'  => $transaction_id,
						'stripe_status'   => $payment_intent->status,
						'stripe_amount'   => $payment_intent->amount,
						'stripe_currency' => $payment_intent->currency,
					),
					JSON_PRETTY_PRINT
				),
				array(
					'source' => 'urm-pg-stripe',
				)
			);

			// Verify the payment status matches what client claims.
			if ( $payment_intent->status !== $expected_status ) {

				$logger->warning(
					sprintf( '[User #%d] Payment status mismatch detected.', $user_id ) . "\n" . wp_json_encode(
						array(
							'transaction_id'  => $transaction_id,
							'expected_status' => $expected_status,
							'actual_status'   => $payment_intent->status,
							'user_id'         => $user_id,
						),
						JSON_PRETTY_PRINT
					),
					array(
						'source' => 'urm-pg-stripe',
					)
				);

				return array(
					'success' => false,
					'message' => __( 'Payment status mismatch. Payment verification failed.', 'user-registration' ),
				);
			}

			// For successful payments, verify amount matches user's registration amount.
			if ( 'succeeded' === $expected_status ) {
				$user_amount     = get_user_meta( $user_id, 'ur_payment_total_amount', true );
				$stripe_amount   = $payment_intent->amount; // Amount in cents.
				$expected_amount = (int) round( floatval( $user_amount ) * 100 ); // Convert to cents.

				$logger->info(
					sprintf( '[User #%d] Verifying payment amount.', $user_id ) . "\n" . wp_json_encode(
						array(
							'transaction_id'        => $transaction_id,
							'user_amount'           => $user_amount,
							'expected_amount_cents' => $expected_amount,
							'stripe_amount_cents'   => $stripe_amount,
							'user_id'               => $user_id,
						),
						JSON_PRETTY_PRINT
					),
					array(
						'source' => 'urm-pg-stripe',
					)
				);

				if ( $stripe_amount !== $expected_amount ) {
					$logger->warning(
						sprintf( '[User #%d] Payment amount mismatch detected.', $user_id ) . "\n" . wp_json_encode(
							array(
								'transaction_id'        => $transaction_id,
								'expected_amount_cents' => $expected_amount,
								'actual_amount_cents'   => $stripe_amount,
								'user_id'               => $user_id,
							),
							JSON_PRETTY_PRINT
						),
						array(
							'source' => 'urm-pg-stripe',
						)
					);

					return array(
						'success' => false,
						'message' => __( 'Payment amount mismatch. Payment verification failed.', 'user-registration' ),
					);
				}

				// Verify payment metadata contains correct user_id if available.
				if ( isset( $payment_intent->metadata->ur_user_id ) ) {
					$stripe_user_id = absint( $payment_intent->metadata->ur_user_id );

					$logger->info(
						sprintf( '[User #%d] Verifying payment metadata user_id.', $user_id ) . "\n" . wp_json_encode(
							array(
								'transaction_id'   => $transaction_id,
								'expected_user_id' => $user_id,
								'stripe_user_id'   => $stripe_user_id,
							),
							JSON_PRETTY_PRINT
						),
						array(
							'source' => 'urm-pg-stripe',
						)
					);

					if ( $stripe_user_id !== $user_id ) {

						$logger->warning(
							sprintf( '[User #%d] Payment user mismatch detected.', $user_id ) . "\n" . wp_json_encode(
								array(
									'transaction_id'   => $transaction_id,
									'expected_user_id' => $user_id,
									'actual_user_id'   => $stripe_user_id,
								),
								JSON_PRETTY_PRINT
							),
							array(
								'source' => 'urm-pg-stripe',
							)
						);

						return array(
							'success' => false,
							'message' => __( 'Payment user mismatch. Payment verification failed.', 'user-registration' ),
						);
					}
				} else {

					$logger->info(
						sprintf( '[User #%d] Payment metadata does not contain user_id - skipping user verification.', $user_id ) . "\n" . wp_json_encode(
							array(
								'transaction_id' => $transaction_id,
								'user_id'        => $user_id,
							),
							JSON_PRETTY_PRINT
						),
						array(
							'source' => 'urm-pg-stripe',
						)
					);
				}
			}

			$logger->info(
				sprintf( '[User #%d] Payment verification completed successfully.', $user_id ) . "\n" . wp_json_encode(
					array(
						'transaction_id' => $transaction_id,
						'payment_method' => $payment_method,
						'user_id'        => $user_id,
						'status'         => $expected_status,
					),
					JSON_PRETTY_PRINT
				),
				array(
					'source' => 'urm-pg-stripe',
				)
			);

			return array(
				'success'        => true,
				'message'        => __( 'Payment verification successful.', 'user-registration' ),
				'payment_intent' => $payment_intent,
			);

		} catch ( \Exception $e ) {

			$logger->error(
				sprintf( '[User #%d] Stripe payment verification failed with exception.', $user_id ) . "\n" . wp_json_encode(
					array(
						'transaction_id' => $transaction_id,
						'payment_method' => $payment_method,
						'user_id'        => $user_id,
						'error_message'  => $e->getMessage(),
						'error_code'     => $e->getCode(),
						'error_file'     => $e->getFile(),
						'error_line'     => $e->getLine(),
					),
					JSON_PRETTY_PRINT
				),
				array(
					'source' => 'urm-pg-stripe',
				)
			);

			return array(
				'success' => false,
				'message' => __( 'Payment verification failed: ', 'user-registration' ) . $e->getMessage(),
			);
		}
	}

	/**
	 * Update user payment status while registration.
	 */
	public function update_user_payment_status() {
		$logger = ur_get_logger();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- The request is logged before verification on purpose, so rejected attempts are recorded too. Nonce is verified immediately below.
		$user_id = isset( $_POST['user_id'] ) ? absint( wp_unslash( $_POST['user_id'] ) ) : 'not_set';

		$logger->info(
			sprintf( '[User #%s] Stripe payment status update request received.', $user_id ) . "\n" . wp_json_encode(
				array(
					'user_id'        => $user_id,
					'payment_method' => isset( $_POST['payment_method'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_method'] ) ) : 'not_set',
					'payment_status' => isset( $_POST['payment_status'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_status'] ) ) : 'not_set',
					'has_nonce'      => isset( $_POST['_wpnonce'] ),
					'ip_address'     => ur_get_ip_address(),
				),
				JSON_PRETTY_PRINT
			),
			array(
				'source' => 'urm-pg-stripe',
			)
		);
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'ur_stripe_payment_nonce' ) ) {

			$logger->warning(
				sprintf( '[User #%s] Stripe payment status update failed - invalid or missing nonce.', $user_id ) . "\n" . wp_json_encode(
					array(
						'user_id'        => isset( $_POST['user_id'] ) ? absint( wp_unslash( $_POST['user_id'] ) ) : 'not_set',
						'ip_address'     => ur_get_ip_address(),
						'nonce_provided' => isset( $_POST['_wpnonce'] ) ? 'yes' : 'no',
					),
					JSON_PRETTY_PRINT
				),
				array(
					'source' => 'urm-pg-stripe',
				)
			);

			wp_send_json_error(
				array(
					'message' => __( 'Security check failed. Please refresh the page and try again.', 'user-registration' ),
				)
			);
		}

		// Validate required parameters.
		if ( ! isset( $_POST['payment_method'] ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Payment method is required.', 'user-registration' ),
				)
			);
		}

		$payment_method = sanitize_text_field( wp_unslash( $_POST['payment_method'] ) );
		$payment_status = sanitize_text_field( wp_unslash( $_POST['payment_status'] ) );
		$user_id        = absint( wp_unslash( $_POST['user_id'] ) );

		// Validate user exists and check if user was just created.
		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			wp_send_json_error(
				array(
					'message' => __( 'Invalid user.', 'user-registration' ),
				)
			);
		}

		// Check if user was just created (following membership pattern).
		$is_just_created = get_user_meta( $user_id, 'urm_user_just_created', true );
		if ( $is_just_created ) {
			$logger->warning(
				sprintf( '[User #%s] Stripe payment status update failed - user already exists or not just created.', $user_id ) . "\n" . wp_json_encode(
					array(
						'user_id'         => $user_id,
						'is_just_created' => $is_just_created,
						'ip_address'      => ur_get_ip_address(),
					),
					JSON_PRETTY_PRINT
				),
				array(
					'source' => 'urm-pg-stripe',
				)
			);

			wp_send_json_error(
				array(
					'message' => __( 'Invalid request. User already exists.', 'user-registration' ),
				)
			);
		}

		// Get transaction ID based on payment method.
		$transaction_id = '';
		if ( 'ideal' === $payment_method ) {
			if ( ! isset( $_POST['payment_intent'] ) || ! isset( $_POST['payment_status'] ) || ! isset( $_POST['user_id'] ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'Required payment parameters missing.', 'user-registration' ),
					)
				);
			}
			$transaction_id = sanitize_text_field( wp_unslash( $_POST['payment_intent'] ) );
		} elseif ( 'card' === $payment_method ) {
			if ( ! isset( $_POST['payment_result'] ) || ! isset( $_POST['payment_status'] ) || ! isset( $_POST['user_id'] ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'Required payment parameters missing.', 'user-registration' ),
					)
				);
			}
			// v19: payment_intent is at data.payment_intent.id; legacy Stripe.js confirmCardPayment returns paymentIntent.id directly.
			if ( isset( $_POST['payment_result']['data']['payment_intent']['id'] ) ) {
				$transaction_id = sanitize_text_field( wp_unslash( $_POST['payment_result']['data']['payment_intent']['id'] ) );
			} elseif ( isset( $_POST['payment_result']['paymentIntent']['id'] ) ) {
				$transaction_id = sanitize_text_field( wp_unslash( $_POST['payment_result']['paymentIntent']['id'] ) );
			}
		}

		// Verify payment with Stripe API.
		if ( ! empty( $transaction_id ) ) {
			$verification_result = $this->verify_stripe_payment( $transaction_id, $payment_method, $user_id, $payment_status );
			if ( ! $verification_result['success'] ) {
				wp_send_json_error(
					array(
						'message' => $verification_result['message'],
					)
				);
			}
		}

		if ( 'failed' === $payment_status ) {
			$error_msg = __( 'Stripe Payment failed.', 'user-registration' );
			$error_msg = isset( $_POST['payment_result']['error']['message'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_result']['error']['message'] ) ) : $error_msg;
			wp_delete_user( absint( wp_unslash( $_POST['user_id'] ) ) );
			wp_send_json_error(
				array(
					'message' => $error_msg,
				)
			);
		} elseif ( 'succeeded' === $payment_status ) {
			$form_id   = ur_get_form_id_by_userid( $user_id );
			$user_data = get_user_meta( $user_id );
			$profile   = user_registration_form_data( $user_id, $form_id );
			$user      = get_user_by( 'id', $user_id );

			$user_data['user_registration_first_name'] = isset( $user_data['first_name'] ) ? $user_data['first_name'] : array();
			$user_data['user_registration_last_name']  = isset( $user_data['last_name'] ) ? $user_data['last_name'] : array();
			$user_data['user_registration_user_login'] = isset( $user->user_login ) ? array( $user->user_login ) : array();
			$user_data['user_registration_user_email'] = isset( $user->user_email ) ? array( $user->user_email ) : array();

			$valid_form_data = array();

			foreach ( $user_data as $post_key => $post_data ) {
				$pos_billing = strpos( $post_key, 'billing_' );
				if ( false !== $pos_billing ) {
					$post_key = 'user_registration_' . $post_key;
				}
				$pos_shipping = strpos( $post_key, 'shipping_' );
				if ( false !== $pos_shipping ) {
					$post_key = 'user_registration_' . $post_key;
				}
				$pos = strpos( $post_key, 'user_registration_' );

				if ( false !== $pos ) {
					$new_string = substr_replace( $post_key, '', $pos, strlen( 'user_registration_' ) );

					if ( ! empty( $new_string ) && 'geolocation' !== $new_string ) {
						$tmp_array       = ur_get_valid_form_data_format( $new_string, $post_key, $profile, $post_data[0] );
						$valid_form_data = array_merge( $valid_form_data, $tmp_array );
					}
				}
			}

			if ( ! empty( $transaction_id ) ) {
				$payment_status                  = 'completed';
				$metas['ur_payment_status']      = $payment_status;
				$metas['ur_payment_transaction'] = $transaction_id;

				/**
				 * Invoice code started.
				 */

				$payment_invoice = array();

				$invoice['invoice_date'] = gmdate( 'Y-m-d H:i:s' );
				$invoice['invoice_no']   = $transaction_id;

				$is_recurring_payment = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe_recurring', false ) );
				$payment_method       = sanitize_text_field( wp_unslash( $_POST['payment_method'] ) );

				$invoice_item = get_user_meta( $user_id, 'ur_cart_items' );

				$invoice['invoice_item']     = $invoice_item;
				$invoice['invoice_currency'] = get_user_meta( $user_id, 'ur_payment_currency', true );
				$invoice['invoice_amount']   = get_user_meta( $user_id, 'ur_payment_total_amount', true );
				$invoice['invoice_status']   = $payment_status;

				array_push( $payment_invoice, $invoice );
				$metas['ur_payment_invoices'] = $payment_invoice;

				/**
				 * Invoice code ended.
				 */

				foreach ( $metas as $key => $value ) {
					update_user_meta( $user_id, $key, $value );
				}
			}

			// Delete the user_just_created meta after successful payment.
			delete_user_meta( $user_id, 'urm_user_just_created' );

			$logger->info(
				sprintf( '[User #%s] Stripe payment processed successfully - user meta cleaned up.', $user_id ) . "\n" . wp_json_encode(
					array(
						'user_id'        => $user_id,
						'transaction_id' => $transaction_id,
						'payment_method' => $payment_method,
						'ip_address'     => ur_get_ip_address(),
					),
					JSON_PRETTY_PRINT
				),
				array(
					'source' => 'urm-pg-stripe',
				)
			);

			// Auto-login only after successful payment verification.
			$login_option = ur_get_user_login_option( $user_id );
			if ( 'auto_login' === $login_option ) {
				wp_clear_auth_cookie();
				wp_set_auth_cookie( $user_id );
			}

			if ( is_plugin_active( 'user-registration-pro/user-registration.php' ) ) {
				if ( empty( get_user_meta( $user_id, 'ur_payment_email_sent', true ) ) ) {
					$is_payment_compatible = true;
					if ( is_plugin_active( 'user-registration-payments/user-registration-payments.php' ) ) {
						if ( version_compare( URP_VERSION, '1.5.3', '<' ) ) {
							$is_payment_compatible = false;
						}
					}
					if ( UR_PRO_ACTIVE && ( version_compare( UR_VERSION, '4.1.1', '<=' ) || ! $is_payment_compatible ) ) {
						User_Registration_Payments_Process::send_success_email( $user_id );
						User_Registration_Payments_Process::send_success_admin_email( $user_id );
					} else {
						User_Registration_Pro_Frontend::send_success_email( $user_id );
						User_Registration_Pro_Frontend::send_success_admin_email( $user_id );
					}
					update_user_meta( $user_id, 'ur_payment_email_sent', true );
				}
			}
			if ( empty( get_user_meta( $user_id, 'ur_welcome_email_sent', true ) ) ) {
				do_action( 'user_registration_after_register_user_action', $valid_form_data, $form_id, $user_id );
				update_user_meta( $user_id, 'ur_welcome_email_sent', true );
			}
			wp_send_json_success(
				array(
					'message' => __( 'Payment has been successfull.', 'user-registration' ),
				)
			);
		}
	}
}

new UR_Pro_Stripe_Process();
