<?php
/**
 * UserRegistrationSMSIntegration SMSOTP
 *
 * @class    SMSOTP
 * @package  UserRegistrationSMSIntegration/SMSOTP
 * @category SMSOTP
 * @author   WPEverest
 * @since  1.0.0
 */

namespace WPEverest\URSMSIntegration;

use lfkeitel\phptotp\{Base32,Totp};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SMSOTP Class
 */
class SMSOTP {

	/**
	 * User meta holding the number of incorrect OTP submissions still allowed.
	 */
	const INCORRECT_ATTEMPTS_META = 'user_registration_sms_verification_incorrect_attempts_left';

	/**
	 * User meta holding the number of OTP resends still allowed.
	 */
	const RESEND_ATTEMPTS_META = 'user_registration_sms_verification_resend_attempts_left';

	/**
	 * User meta holding the timestamp the verification was put on HOLD.
	 */
	const HOLD_STARTED_META = 'user_registration_sms_verification_hold_started_on';

	/**
	 * User meta binding an OTP submission to the session the OTP was issued to.
	 */
	const SESSION_TOKEN_META = 'user_registration_sms_verification_session_token';

	/**
	 * Generate SMS OTP of provided length and validity using SMSOTP algorithm.
	 *
	 * @param [int] $user_id User Id.
	 * @param [int] $length OTP Length.
	 * @param [int] $validity OTP Validity ( in minutes ).
	 * @return string
	 */
	public static function generate_otp( $user_id, $length, $validity ) {

		$secret = Totp::GenerateSecret( 32 );

		$totp = new Totp( 'sha1', 0, $validity );

		$key = $totp->GenerateToken( $secret, null, $length );

		update_user_meta( $user_id, 'user_registration_sms_verification_otp_key', $key );

		return $key;
	}

	/**
	 * Check whether the submitted OTP matches the stored OTP key.
	 *
	 * Timing-safe: `===` on a short numeric code leaks how many leading characters matched.
	 *
	 * @param [int]    $user_id User Id.
	 * @param [string] $user_key OTP Code.
	 * @return bool
	 */
	public static function verify_otp( $user_id, $user_key ) {
		if ( 'PENDING' === get_user_meta( $user_id, 'user_registration_sms_verification_status', true ) ) {
			$true_key = get_user_meta( $user_id, 'user_registration_sms_verification_otp_key', true );

			if ( '' !== $true_key ) {
				return hash_equals( (string) $true_key, (string) $user_key );
			}
		}

		return false;
	}

	/**
	 * Configured number of incorrect OTP submissions allowed per verification session.
	 *
	 * @return int
	 */
	public static function get_incorrect_otp_limit() {
		$limit = (int) get_option( 'user_registration_sms_verification_incorrect_otp_limit', 5 );

		return max( 1, (int) apply_filters( 'user_registration_sms_verification_incorrect_otp_limit', $limit ) );
	}

	/**
	 * Configured number of OTP resends allowed per verification session.
	 *
	 * @return int
	 */
	public static function get_otp_resend_limit() {
		$limit = (int) get_option( 'user_registration_sms_verification_otp_resend_limit', 3 );

		return max( 1, (int) apply_filters( 'user_registration_sms_verification_otp_resend_limit', $limit ) );
	}

	/**
	 * Configured login hold period, in seconds, applied once the incorrect OTP limit is hit.
	 *
	 * @return int
	 */
	public static function get_login_hold_period() {
		$period = (int) get_option( 'user_registration_sms_verification_login_hold_period', 60 );

		return max( 1, (int) apply_filters( 'user_registration_sms_verification_login_hold_period', $period ) ) * MINUTE_IN_SECONDS;
	}

	/**
	 * Configured resend hold period, in seconds, applied once the resend limit is hit.
	 *
	 * @return int
	 */
	public static function get_resend_hold_period() {
		$period = (int) get_option( 'user_registration_sms_verification_resend_otp_hold_period', 60 );

		return max( 1, (int) apply_filters( 'user_registration_sms_verification_resend_otp_hold_period', $period ) ) * MINUTE_IN_SECONDS;
	}

	/**
	 * Mint a fresh session token for a verification session.
	 *
	 * The submission nonce is anonymous, so it proves nothing; this token is issued only to a client that passed the user-bound nonce gate.
	 *
	 * @param [int] $user_id User Id.
	 * @return string
	 */
	public static function start_session_token( $user_id ) {
		$token = wp_generate_password( 32, false );

		update_user_meta( $user_id, self::SESSION_TOKEN_META, $token );

		return $token;
	}

	/**
	 * Current session token, or '' when none has been issued.
	 *
	 * @param [int] $user_id User Id.
	 * @return string
	 */
	public static function get_session_token( $user_id ) {
		return (string) get_user_meta( $user_id, self::SESSION_TOKEN_META, true );
	}

	/**
	 * Check a submitted session token against the stored one.
	 *
	 * Fails closed: a session with no token stored is rejected, and reloading the OTP screen issues one.
	 *
	 * @param [int]    $user_id   User Id.
	 * @param [string] $submitted Token supplied with the request.
	 * @return bool
	 */
	public static function verify_session_token( $user_id, $submitted ) {
		$stored = self::get_session_token( $user_id );

		return '' !== $stored && hash_equals( $stored, (string) $submitted );
	}

	/**
	 * Drop the session token once verification is finished.
	 *
	 * @param [int] $user_id User Id.
	 * @return void
	 */
	public static function clear_session_token( $user_id ) {
		delete_user_meta( $user_id, self::SESSION_TOKEN_META );
	}

	/**
	 * Seed the per-session attempt counters.
	 *
	 * Called on each fresh session so every session gets its own budget.
	 *
	 * @param [int] $user_id User Id.
	 * @return void
	 */
	public static function init_attempts( $user_id ) {
		update_user_meta( $user_id, self::INCORRECT_ATTEMPTS_META, self::get_incorrect_otp_limit() );
		update_user_meta( $user_id, self::RESEND_ATTEMPTS_META, self::get_otp_resend_limit() );
		delete_user_meta( $user_id, self::HOLD_STARTED_META );
	}

	/**
	 * Remaining incorrect OTP submissions allowed for this user.
	 *
	 * An unseeded counter falls back to the limit; reading it as 0 would lock out users mid-verification
	 * on upgrade. The fallback is not persisted, so this stays safe to call from a render path.
	 *
	 * @param [int] $user_id User Id.
	 * @return int
	 */
	public static function get_incorrect_attempts_left( $user_id ) {
		$attempts_left = get_user_meta( $user_id, self::INCORRECT_ATTEMPTS_META, true );

		if ( '' === $attempts_left || null === $attempts_left ) {
			return self::get_incorrect_otp_limit();
		}

		return max( 0, (int) $attempts_left );
	}

	/**
	 * Remaining OTP resends allowed for this user.
	 *
	 * @param [int] $user_id User Id.
	 * @return int
	 */
	public static function get_resend_attempts_left( $user_id ) {
		$attempts_left = get_user_meta( $user_id, self::RESEND_ATTEMPTS_META, true );

		if ( '' === $attempts_left || null === $attempts_left ) {
			return self::get_otp_resend_limit();
		}

		return max( 0, (int) $attempts_left );
	}

	/**
	 * Record an incorrect OTP submission, putting the user on HOLD when the budget runs out.
	 *
	 * @param [int] $user_id User Id.
	 * @return int Remaining attempts after this one.
	 */
	public static function register_failed_attempt( $user_id ) {
		$attempts_left = max( 0, self::get_incorrect_attempts_left( $user_id ) - 1 );

		update_user_meta( $user_id, self::INCORRECT_ATTEMPTS_META, $attempts_left );

		if ( 0 === $attempts_left ) {
			update_user_meta( $user_id, 'user_registration_sms_verification_status', 'HOLD' );
			update_user_meta( $user_id, self::HOLD_STARTED_META, time() );
		}

		return $attempts_left;
	}

	/**
	 * Record an OTP resend, starting the resend hold period when the budget runs out.
	 *
	 * @param [int] $user_id User Id.
	 * @return int Remaining resends after this one.
	 */
	public static function register_resend( $user_id ) {
		$attempts_left = max( 0, self::get_resend_attempts_left( $user_id ) - 1 );

		update_user_meta( $user_id, self::RESEND_ATTEMPTS_META, $attempts_left );
		update_user_meta( $user_id, 'user_registration_sms_verification_last_resend_otp_submitted_on', time() );

		return $attempts_left;
	}

	/**
	 * The "incorrect OTP limit reached" message, with its placeholders resolved.
	 *
	 * Shared by the AJAX responses and the OTP screen so both cannot drift apart.
	 *
	 * @param [int] $user_id User Id.
	 * @return string
	 */
	public static function get_limit_reached_message( $user_id ) {
		$limit = self::get_incorrect_otp_limit();

		$message = get_option(
			'user_registration_sms_verification_invalid_otp_limit_message',
			/* translators: {{otp_attempt_limit}}: attempts allowed, {{login_hold_time}}: time until retry */
			__( 'Incorrect OTP limit reached ({{otp_attempt_limit}}/{{otp_attempt_limit}}). Please try again after {{login_hold_time}}.', 'user-registration' )
		);

		return self::render_message(
			apply_filters( 'user_registration_process_smart_tags', $message, array() ),
			array(
				'otp_attempt_limit' => $limit,
				'otp_attempts_used' => $limit,
				'login_hold_time'   => self::format_hold_period( self::get_remaining_hold_period( $user_id ) ),
			)
		);
	}

	/**
	 * Substitute {{tag}} placeholders in an OTP screen message.
	 *
	 * UR_Smart_Tags::process() returns early unless an `email` value is supplied, so
	 * these placeholders are replaced here to guarantee they never reach the user raw.
	 *
	 * @param [string] $message Message possibly containing {{tags}}.
	 * @param [array]  $tags    Tag name => replacement value.
	 * @return string
	 */
	public static function render_message( $message, $tags ) {
		foreach ( (array) $tags as $tag => $value ) {
			$message = str_replace( '{{' . $tag . '}}', (string) $value, $message );
		}

		return $message;
	}

	/**
	 * Format a hold period, in seconds, as human readable time.
	 *
	 * Local to this addon; the equivalent helper lives in the 2FA plugin, which may not be active.
	 *
	 * @param [int] $seconds Time in seconds.
	 * @return string
	 */
	public static function format_hold_period( $seconds ) {
		$seconds = max( 0, (int) $seconds );

		$hours    = (int) floor( $seconds / HOUR_IN_SECONDS );
		$minutes  = (int) floor( ( $seconds % HOUR_IN_SECONDS ) / MINUTE_IN_SECONDS );
		$remained = $seconds % MINUTE_IN_SECONDS;

		$parts = array();

		if ( $hours ) {
			/* translators: %s: number of hours */
			$parts[] = sprintf( _n( '%s hour', '%s hours', $hours, 'user-registration' ), number_format_i18n( $hours ) );
		}

		if ( $minutes ) {
			/* translators: %s: number of minutes */
			$parts[] = sprintf( _n( '%s minute', '%s minutes', $minutes, 'user-registration' ), number_format_i18n( $minutes ) );
		}

		// Only fall back to seconds when there is nothing coarser to show.
		if ( empty( $parts ) && $remained ) {
			/* translators: %s: number of seconds */
			$parts[] = sprintf( _n( '%s second', '%s seconds', $remained, 'user-registration' ), number_format_i18n( $remained ) );
		}

		return empty( $parts ) ? __( 'a moment', 'user-registration' ) : implode( ' ', $parts );
	}

	/**
	 * Seconds left on the login hold, or 0 when the user is not held.
	 *
	 * @param [int] $user_id User Id.
	 * @return int
	 */
	public static function get_remaining_hold_period( $user_id ) {
		if ( 'HOLD' !== get_user_meta( $user_id, 'user_registration_sms_verification_status', true ) ) {
			return 0;
		}

		$hold_started_on = (int) get_user_meta( $user_id, self::HOLD_STARTED_META, true );

		if ( ! $hold_started_on ) {
			// HOLD with no start time: treat as elapsed rather than locking out forever.
			return 0;
		}

		return max( 0, $hold_started_on + self::get_login_hold_period() - time() );
	}

	/**
	 * Whether the user is currently locked out of OTP verification.
	 *
	 * @param [int] $user_id User Id.
	 * @return bool
	 */
	public static function is_user_on_hold( $user_id ) {
		return self::get_remaining_hold_period( $user_id ) > 0;
	}

	/**
	 * Seconds left on the resend hold, or 0 when resending is allowed.
	 *
	 * @param [int] $user_id User Id.
	 * @return int
	 */
	public static function get_remaining_resend_hold_period( $user_id ) {
		if ( self::get_resend_attempts_left( $user_id ) > 0 ) {
			return 0;
		}

		$last_resend_on = (int) get_user_meta( $user_id, 'user_registration_sms_verification_last_resend_otp_submitted_on', true );

		if ( ! $last_resend_on ) {
			return 0;
		}

		return max( 0, $last_resend_on + self::get_resend_hold_period() - time() );
	}
}

new SMSOTP();
