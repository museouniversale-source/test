<?php
/**
 * User_Registration_Pro_PayPal_Standard
 *
 * @package  User_Registration_Pro_PayPal_Standard
 * @since  4.1.5
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class User_Registration_Pro_PayPal_Standard
 */
class User_Registration_Pro_PayPal_Standard {

	/**
	 * User_Registration_Pro_PayPal_Standard Constructor
	 */
	public function __construct() {
		if ( is_admin() ) {
			add_action( 'user_registration_after_form_settings', array( $this, 'render_paypal_section' ) );
			add_filter( 'user_registration_form_settings_save', array( $this, 'save_paypal_settings' ), 10, 2 );
			add_filter( 'user_registration_form_settings_save', array( $this, 'save_paypal_conditional_settings' ), 10, 2 );
		}

		add_filter(
			'user_registration_success_params_paypal_payment_process',
			array( $this, 'paypal_payment_process' ),
			10,
			4
		);

		add_action( 'init', array( $this, 'paypal_process_ipn' ) );
		add_action( 'init', array( $this, 'handle_paypal_response_after_registration' ) );
		add_action( 'delete_user', array( $this, 'unsubscribe_payment_gateway_on_user_delete' ), 10, 3 );
		add_filter( 'user_registration_paypal_webhook_event_fallback', array( $this, 'handle_rest_webhook_for_registration' ), 10, 2 );
	}

	/**
	 * Settings for PayPal.
	 *
	 * @param int $form_id Form ID.
	 * @return array
	 */
	public function get_paypal_settings( $form_id ) {
		$global_settings_url = get_admin_url() . 'admin.php?page=user-registration-settings&tab=payment#user_registration_global_paypal_mode';
		$arguments           = array(
			'form_id'      => $form_id,
			'setting_data' => array_merge(
				array(
					array(
						'type'              => 'toggle',
						'label'             => __( 'Enable PayPal Payment', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_enable_paypal_standard',
						'class'             => array(),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_enable_paypal_standard', false ),
						'tip'               => __( 'Enable payment for this form with PayPal.', 'user-registration' ),
					),
					array(
						'type'              => 'toggle',
						'label'             => __( 'Override Global Settings', 'user-registration' ),
						'description'       => sprintf( 'Enabling this will override global PayPal settings configured %s', "<a href='" . $global_settings_url . "'>here.</a>" ),
						'required'          => false,
						'id'                => 'user_registration_override_paypal_global_settings',
						'class'             => array(),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_override_paypal_global_settings', false ),
					),
					array(
						'type'              => 'select',
						'label'             => __( 'Mode', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_paypal_mode',
						'options'           => array(
							'production' => __( 'Production', 'user-registration' ),
							'test'       => __( 'Test/Sandbox', 'user-registration' ),
						),
						'class'             => array( 'ur-enhanced-select', 'paypal-setting-group' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_paypal_mode', 'test' ),
						'tip'               => __( 'Select a mode to run this form.', 'user-registration' ),
					),
				),
				ur_string_to_bool( get_option( 'urm_is_new_installation' ) ) ? array() : array(
					array(
						'type'              => 'text',
						'label'             => __( 'PayPal Email Address', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_paypal_email_address',
						'class'             => array( 'ur-input-field', 'paypal-setting-group' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_paypal_email_address', get_option( 'admin_email' ) ),
						'tip'               => __( 'Enter your PayPal email address.', 'user-registration' ),
					),

					array(
						'type'              => 'text',
						'label'             => __( 'Cancel URL', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_paypal_cancel_url',
						'class'             => array( 'ur-input-field', 'paypal-setting-group' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_paypal_cancel_url', home_url() ),
						'tip'               => __( 'Redirect URL if the user cancels after redirecting to PayPal.', 'user-registration' ),
					),
					array(
						'type'              => 'text',
						'label'             => __( 'Return URL', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_paypal_return_url',
						'class'             => array( 'ur-input-field', 'paypal-setting-group' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_paypal_return_url', wp_login_url() ),
						'tip'               => __( 'Redirect URL after the payment process.', 'user-registration' ),
					),
				),
				array(
					array(
						'type'              => 'text',
						'label'             => __( 'Client ID', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_paypal_client_id',
						'class'             => array( 'ur-input-field', 'paypal-setting-group' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_paypal_client_id', '' ),
						'tip'               => __( 'Enter your PayPal client ID.', 'user-registration' ),
					),
					array(
						'type'              => 'text',
						'label'             => __( 'Client Secret', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_paypal_client_secret',
						'class'             => array( 'ur-input-field', 'paypal-setting-group' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_paypal_client_secret', '' ),
						'tip'               => __( 'Enter your PayPal client secret.', 'user-registration' ),
					),
				),
				ur_string_to_bool( get_option( 'urm_is_new_installation' ) ) ? array() : array(
					array(
						'type'              => 'select',
						'label'             => __( 'Payment Type', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_paypal_type',
						'options'           => array(
							'products' => __( 'Products and Services', 'user-registration' ),
							'donation' => __( 'Donation', 'user-registration' ),
						),
						'class'             => array( 'ur-enhanced-select', 'paypal-setting-group' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_paypal_type', 'products' ),
						'tip'               => __( 'Select type of payments you want to receive.', 'user-registration' ),
					),
				),
				array(
					array(
						'type'  => 'section',
						'id'    => 'subscribtion_section',
						'title' => __( 'Subscription Settings', 'user-registration' ),
						'class' => array( 'paypal-setting-group', 'ur-form-settings-section' ),
					),
					array(
						'type'              => 'toggle',
						'label'             => __( 'Enable Recurring Subscription Payment', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_enable_paypal_standard_subscription',
						'class'             => array( 'ur-enhanced-select', 'paypal-setting-group' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_enable_paypal_standard_subscription', false ),
						'tip'               => __( 'Enable subscription with periodical or recurring payments.', 'user-registration' ),
					),
					array(
						'type'              => 'text',
						'label'             => __( 'Plan Name', 'user-registration' ),
						'description'       => 'Note: We have introduced a new subscription plan field. If you drag and drop this field, the current plan will no longer be active, giving priority to the new field. We also recommend switching to the subscription plan field, as this plan option will no longer be available after a few updates.',
						'required'          => false,
						'id'                => 'user_registration_paypal_plan_name',
						'class'             => array( 'ur-input-field', 'paypal-setting-group' ),
						'custom_attributes' => array(),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_paypal_plan_name', '' ),
						'tip'               => __( 'Enter a plan name for this form.', 'user-registration' ),
					),
					array(
						'type'              => 'number',
						'label'             => __( 'Recurring Period', 'user-registration' ),
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_paypal_interval_count',
						'custom_attributes' => array(),
						'class'             => array( 'ur-input-field', 'paypal-setting-group' ),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_paypal_interval_count', '' ),
						'tip'               => __( 'Interval between recurring payments.', 'user-registration' ),
					),
					array(
						'type'              => 'select',
						'description'       => '',
						'required'          => false,
						'id'                => 'user_registration_paypal_recurring_period',
						'options'           => array(
							'DAY'   => __( 'Day(s)', 'user-registration' ),
							'WEEK'  => __( 'Week(s)', 'user-registration' ),
							'MONTH' => __( 'Month(s)', 'user-registration' ),
							'YEAR'  => __( 'Year(s)', 'user-registration' ),
						),
						'class'             => array( 'ur-enhanced-select', 'paypal-setting-group' ),
						'custom_attributes' => array( 'style' => 'width: 60%; align-self: flex-end;' ),
						'default'           => ur_get_single_post_meta( $form_id, 'user_registration_paypal_recurring_period', 'year' ),
					),
				),
			),
		);

		$arguments                 = apply_filters( 'user_registration_get_paypal_settings', $arguments );
		$arguments['setting_data'] = apply_filters( 'user_registration_settings_text_format', $arguments['setting_data'] );

		return $this->filter_legacy_settings( $arguments['setting_data'], $form_id );
	}

	/**
	 * Drop the form payment settings that new sites may no longer use.
	 *
	 * @param array $settings Setting data.
	 * @return array
	 */
	private function filter_legacy_settings( $settings, $form_id = 0 ) {
		if ( ! function_exists( 'ur_legacy_payment_fields_enabled' ) || ur_legacy_payment_fields_enabled( $form_id ) ) {
			return $settings;
		}

		/**
		 * Filters the PayPal form settings withheld from sites that never used payment fields.
		 *
		 * @param array $legacy_only Setting ids to drop.
		 *
		 * @since x.x.x
		 */
		$legacy_only = apply_filters(
			'user_registration_paypal_legacy_only_form_settings',
			array(
				'user_registration_enable_paypal_standard',
				'subscribtion_section',
				'user_registration_enable_paypal_standard_subscription',
				'user_registration_paypal_plan_name',
				'user_registration_paypal_interval_count',
				'user_registration_paypal_recurring_period',
			)
		);

		foreach ( $settings as $index => $setting ) {
			if ( isset( $setting['id'] ) && in_array( $setting['id'], $legacy_only, true ) ) {
				unset( $settings[ $index ] );
			}
		}

		return array_values( $settings );
	}

	/**
	 * Render PayPal settings.
	 *
	 * @param int $form_id Form ID.
	 * @return void
	 */
	public function render_paypal_section( $form_id = 0 ) {
		// Nothing here is form-specific once payment fields are frozen: a new form's PayPal credentials come from Settings > Payment only.
		if ( function_exists( 'ur_legacy_payment_fields_enabled' ) && ! ur_legacy_payment_fields_enabled( $form_id ) ) {
			return;
		}

		$integration_settings = get_post_meta( $form_id, 'user_registration_paypal_conditional_integration', true );

		echo '<div id="paypal-standard-settings" data-field-group="payments" ><h3>' . esc_html__( 'PayPal Standard', 'user-registration' ) . '</h3>';

		$arguments = $this->get_paypal_settings( $form_id );

		foreach ( $arguments as $args ) {
			user_registration_form_settings_field( $args['id'], $args );
		}

		// Conditional logic gates a form payment, so new sites do not get it.
		if ( ! function_exists( 'ur_legacy_payment_fields_enabled' ) || ur_legacy_payment_fields_enabled( $form_id ) ) {
			// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Settings markup rendered by user_registration_pro_render_conditional_logic().
			if ( ! empty( $integration_settings ) && is_array( $integration_settings ) ) {
				foreach ( $integration_settings as $connection ) {
					echo $this->output_paypal_conditional_logic( $form_id, $connection );
				}
			} else {
				echo $this->output_paypal_conditional_logic( $form_id, array() );
			}
			// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		echo '</div>';
	}

	/**
	 * Save PayPal settings.
	 *
	 * @param array $settings Settings.
	 * @param int   $form_id Form ID.
	 * @return array
	 */
	public function save_paypal_settings( $settings, $form_id = 0 ) {
		$payment_setting = $this->get_paypal_settings( $form_id );
		$settings        = array_merge( $settings, $payment_setting );

		return $settings;
	}

	/**
	 * Save PayPal conditional settings.
	 *
	 * @param array $settings Settings.
	 * @param int   $form_id Form ID.
	 * @return array
	 */
	public function save_paypal_conditional_settings( $settings, $form_id = 0 ) {
		$form_id                     = absint( $_POST['data']['form_id'] );
		$paypal_conditional_settings = isset( $_POST['data']['ur_paypal_conditional_integration'] ) ? wp_unslash( $_POST['data']['ur_paypal_conditional_integration'] ) : array();
		update_post_meta( $form_id, 'user_registration_paypal_conditional_integration', $paypal_conditional_settings );

		return $settings;
	}

	/**
	 * Main PayPal payment process.
	 *
	 * @param array $success_params Success params.
	 * @param array $valid_form_data Valid form data.
	 * @param int   $form_id Form ID.
	 * @param int   $user_id User ID.
	 * @return array
	 */
	public function paypal_payment_process( $success_params, $valid_form_data, $form_id, $user_id ) {
		$logger = ur_get_logger();

		$logger->notice(
			sprintf( '[User #%d][Form #%d] =============== ***NEW PAYEMENT SESSION FOR REGISTRATION*** ===============', $user_id, $form_id ),
			array(
				'source'   => 'urm-pg-paypal',
				'form_id'  => $form_id,
				'function' => __FUNCTION__,
			)
		);

		$saved_currency = get_option( 'user_registration_payment_currency', 'USD' );
		if ( ! in_array( $saved_currency, paypal_supported_currencies_list(), true ) ) {
			$logger->error(
				sprintf( '[User #%d][Form #%d] Unsupported currency for PayPal.', $user_id, $form_id ) . "\n" .
				'Currency: ' . $saved_currency,
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $user_id,
					'form_id'  => $form_id,
					'function' => __FUNCTION__,
				)
			);

			wp_delete_user( absint( $user_id ) );
			wp_send_json_error(
				array(
					'message' => __( 'CURRENCY_NOT_SUPPORTED Currency code ' . $saved_currency . ' is not currently supported. Please contact site administrator.', 'user-registration' ),
				)
			);
		}

		$payment_context = $this->prepare_form_payment_context( $valid_form_data, $form_id, $user_id, $saved_currency );
		if ( is_wp_error( $payment_context ) ) {
			wp_delete_user( absint( $user_id ) );
			wp_send_json_error(
				array(
					'message' => $payment_context->get_error_message(),
				)
			);
		}

		if ( ur_string_to_bool( get_option( 'user_registration_enable_payment_pending_email', true ) ) ) {
			User_Registration_Pro_Frontend::send_pending_email( $user_id );
		}

		$use_rest_api = $this->should_use_rest_api( $form_id );
		$logger->info(
			sprintf( '[User #%d][Form #%d] Deciding PayPal flow.', $user_id, $form_id ) . "\n" .
			wp_json_encode(
				array(
					'use_rest_api'      => $use_rest_api,
					'is_new_install'    => ur_string_to_bool( get_option( 'urm_is_new_installation' ) ),
					'is_subscription'   => $payment_context['is_subscription'],
					'has_client_id'     => ! empty( $payment_context['paypal_options']['client_id'] ),
					'has_client_secret' => ! empty( $payment_context['paypal_options']['secret_key'] ),
				),
				JSON_PRETTY_PRINT
			),
			array(
				'source'   => 'urm-pg-paypal',
				'user_id'  => $user_id,
				'form_id'  => $form_id,
				'function' => __FUNCTION__,
			)
		);

		if ( $use_rest_api ) {
			$redirect = $payment_context['is_subscription']
				? $this->build_rest_subscription_redirect( $payment_context )
				: $this->build_rest_order_redirect( $payment_context );
		} else {
			$redirect = $this->build_standard_redirect( $payment_context );
		}

		if ( is_wp_error( $redirect ) ) {
			$logger->error(
				sprintf( '[User #%d][Form #%d] PayPal redirect build failed.', $user_id, $form_id ) . "\n" .
				wp_json_encode(
					array(
						'message' => $redirect->get_error_message(),
						'data'    => $redirect->get_error_data(),
					),
					JSON_PRETTY_PRINT
				),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $user_id,
					'form_id'  => $form_id,
					'function' => __FUNCTION__,
				)
			);

			wp_delete_user( absint( $user_id ) );
			wp_send_json_error(
				array(
					'message' => $redirect->get_error_message(),
				)
			);
		}

		$success_params['paypal_redirect'] = $redirect;
		$success_params['payment_process']  = true;
		$success_params['message']         = get_option( 'user_registration_payment_before_registration_pending_message', esc_html( 'User Registered. Payment Processing...' ) );

		return $success_params;
	}

	/**
	 * Prepare all payment data from form and settings.
	 *
	 * @param array  $valid_form_data Valid form data.
	 * @param int    $form_id Form ID.
	 * @param int    $user_id User ID.
	 * @param string $currency Currency.
	 * @return array|WP_Error
	 */
	private function prepare_form_payment_context( $valid_form_data, $form_id, $user_id, $currency ) {
		$logger = ur_get_logger();

		$override_global_paypal_settings = ur_get_single_post_meta( $form_id, 'user_registration_override_paypal_global_settings', false );
		$payment_mode                    = ! $override_global_paypal_settings ? get_option( 'user_registration_global_paypal_mode', 'test' ) : ur_get_single_post_meta( $form_id, 'user_registration_paypal_mode', 'test' );
		$payment_mode_key                = 'production' === $payment_mode ? 'live' : $payment_mode;
		$receiver_email                  = ! $override_global_paypal_settings
			? get_option( sprintf( 'user_registration_global_paypal_%s_email_address', $payment_mode_key ), get_option( 'user_registration_global_paypal_email_address', get_option( 'admin_email' ) ) )
			: ur_get_single_post_meta( $form_id, 'user_registration_paypal_email_address', get_option( 'admin_email' ) );
		$cancel_url                      = ! $override_global_paypal_settings ? get_option( 'user_registration_global_paypal_cancel_url', home_url() ) : ur_get_single_post_meta( $form_id, 'user_registration_paypal_cancel_url', home_url() );
		$return_url                      = ! $override_global_paypal_settings ? get_option( 'user_registration_global_paypal_return_url', home_url() ) : ur_get_single_post_meta( $form_id, 'user_registration_paypal_return_url', home_url() );

		$paypal_options = array(
			'mode'       => $payment_mode,
			'email'      => $receiver_email,
			'cancel_url' => apply_filters( 'urm_paypal_override_cancel_url', '' === $cancel_url ? home_url() : $cancel_url ),
			'return_url' => apply_filters( 'urm_paypal_override_return_url', '' === $return_url ? home_url() : $return_url ),
			'client_id'  => $this->get_paypal_client_id( $form_id ),
			'secret_key' => $this->get_paypal_client_secret( $form_id ),
		);

		$payment_type        = ur_get_single_post_meta( $form_id, 'user_registration_paypal_type', 'products' );
		$amount              = user_registration_sanitize_amount( 0, $currency );
		$items               = array();
		$subscribed_plan     = '';
		$paypal_subscription = ur_get_single_post_meta( $form_id, 'user_registration_enable_paypal_standard_subscription', 'no' );
		$quantities          = array();
		$coupon_details      = array();

		foreach ( $valid_form_data as $field_data ) {
			if ( isset( $field_data->extra_params['field_key'] ) && 'quantity_field' === $field_data->extra_params['field_key'] ) {
				$target_name                = $field_data->extra_params['target_field'];
				$quantities[ $target_name ] = $field_data->value;
			}

			if ( isset( $field_data->extra_params['field_key'] ) && 'coupon' === $field_data->extra_params['field_key'] && ur_check_module_activation( 'coupon' ) ) {
				$coupon_details = ur_get_coupon_details( $field_data->value );

				// No usage-cap check here: the use was already claimed when the user was inserted.
				if ( ! empty( $coupon_details ) && ( 'form' !== $coupon_details['coupon_for'] || ! in_array( $form_id, (array) json_decode( $coupon_details['coupon_form'], true ), true ) ) ) {
					$coupon_details = array();
				}
			}
		}

		foreach ( $valid_form_data as $form_data ) {
			$payment_slider   = check_is_range_payment_slider( $form_data->field_name, $form_id );
			$urcl_hide_fields = isset( $_POST['urcl_hide_fields'] ) ? (array) json_decode( stripslashes( $_POST['urcl_hide_fields'] ), true ) : array();

			if ( in_array( $form_data->field_name, $urcl_hide_fields, true ) ) {
				continue;
			}

			if ( isset( $form_data->extra_params['field_key'] ) && ( 'single_item' === $form_data->extra_params['field_key'] || ( 'range' === $form_data->extra_params['field_key'] && $payment_slider ) || 'multiple_choice' === $form_data->extra_params['field_key'] || 'subscription_plan' === $form_data->extra_params['field_key'] ) ) {
				$item_amount = json_decode( $form_data->value );

				if ( 'subscription_plan' === $form_data->extra_params['field_key'] ) {
					$subscription_data = ! is_array( $item_amount ) ? explode( ':', $item_amount ) : $item_amount;
					if ( isset( $subscription_data[1] ) ) {
						$selected_options                     = array();
						$subscribed_plan                      = isset( $subscription_data[0] ) ? $subscription_data[0] : '';
						$subscription_amount                  = isset( $subscription_data[1] ) ? $subscription_data[1] : 0;
						$selected_options[ $subscribed_plan ] = $subscription_amount;
						$form_data->value                     = $selected_options;
						$item_amount                          = $subscription_amount;
					}
				}

				if ( is_array( $item_amount ) ) {
					$multiple_choice_amount = 0;
					$selected_options       = array();

					foreach ( $item_amount as $option_choice ) {
						$options_data                      = explode( ':', $option_choice );
						$option_label                      = isset( $options_data[0] ) ? $options_data[0] : '';
						$option_amount                     = isset( $options_data[1] ) ? $options_data[1] : $option_choice;
						$multiple_choice_amount            = $multiple_choice_amount + $option_amount;
						$selected_options[ $option_label ] = $option_amount;
					}

					$form_data->value = $selected_options;
					$item_amount      = $multiple_choice_amount;
				}

				if ( array_key_exists( $form_data->field_name, $quantities ) ) {
					$quantity = 0;
					if ( absint( $quantities[ $form_data->field_name ] ) > -1 ) {
						$quantity = absint( $quantities[ $form_data->field_name ] );
					}
					$form_data->quantity = $quantity;
					$item_amount         = $item_amount * $quantity;
				}

				$form_data->amount = $item_amount;
				$items[]           = $form_data;
				$amount            = $amount + user_registration_sanitize_amount( $item_amount, $currency );
			}
		}

		if ( empty( $items ) ) {
			return new WP_Error(
				'paypal_missing_payment_fields',
				__( 'PayPal payment stopped, missing payment fields.', 'user-registration' )
			);
		}

		if ( empty( $amount ) || user_registration_sanitize_amount( 0, $currency ) == $amount ) {
			return new WP_Error(
				'paypal_invalid_amount',
				__( 'PayPal payment stopped, invalid or empty amount.', 'user-registration' )
			);
		}

		$post_data                = ur_get_post_content( $form_id );
		$subscription_plan_field  = ur_get_form_data_by_key( $post_data, 'subscription_plan' );
		$plan_name                = ur_get_single_post_meta( $form_id, 'user_registration_paypal_plan_name', '' );
		$recurring_period         = ur_get_single_post_meta( $form_id, 'user_registration_paypal_recurring_period' );
		$interval_count           = ur_get_single_post_meta( $form_id, 'user_registration_paypal_interval_count', '1' );
		$subscription_expiry_date = '';

		$subscription_expiry_date    = '';
		$enabled_subscription_expiry = '';
		$trial_period_enable         = '';
		$trial_interval_count        = 1;
		$trial_recurring_period      = '';

		if ( ! empty( $subscription_plan_field ) && isset( $subscription_plan_field['subscription_plan']->general_setting->options ) ) {
			$plan_lists = $subscription_plan_field['subscription_plan']->general_setting->options;
			if ( ! empty( $plan_lists ) ) {
				foreach ( $plan_lists as $plan ) {
					if ( $subscribed_plan === $plan->label ) {
						$interval_count              = ! empty( $plan->interval_count ) ? $plan->interval_count : 1;
						$plan_name                   = $plan->label;
						$recurring_period            = $plan->recurring_period;
						$enabled_subscription_expiry = isset( $plan->subscription_expiry_enable ) ? $plan->subscription_expiry_enable : '';
						$subscription_expiry_date    = isset( $plan->subscription_expiry_date ) ? $plan->subscription_expiry_date : '';

						// Trial data.
						$trial_period_enable    = isset( $plan->trail_period_enable ) ? $plan->trail_period_enable : '';
						$trial_interval_count   = ! empty( $plan->trail_interval_count ) ? $plan->trail_interval_count : 1;
						$trial_recurring_period = isset( $plan->trail_recurring_period ) ? $plan->trail_recurring_period : '';
					}
				}
			}
		}

		update_user_meta( $user_id, 'ur_paypal_trial_enabled', ur_string_to_bool( $trial_period_enable ) ? 'yes' : 'no' );
		update_user_meta( $user_id, 'ur_paypal_trial_interval_count', ! empty( $trial_interval_count ) ? (int) $trial_interval_count : 1 );
		update_user_meta( $user_id, 'ur_paypal_trial_recurring_period', $trial_recurring_period );

		if ( ur_string_to_bool( $enabled_subscription_expiry ) && '' !== $subscription_expiry_date ) {
			$subscription_expiry_date = date( 'F j, Y H:i:s', strtotime( $subscription_expiry_date ) );
		} else {
			$subscription_expiry_date = '';
		}

		if ( ! empty( $coupon_details ) ) {
			update_user_meta( $user_id, 'ur_coupon_discount_type', $coupon_details['coupon_discount_type'] );
			update_user_meta( $user_id, 'ur_coupon_discount', $coupon_details['coupon_discount'] );
			update_user_meta( $user_id, 'ur_coupon_code', $coupon_details['coupon_code'] );
		}

		if ( '' !== $subscription_expiry_date ) {
			$subscription_expiry_date = date( 'F j, Y H:i:s', strtotime( $subscription_expiry_date ) );
		}

		$paypal_verification_token = wp_generate_uuid4();
		update_user_meta( $user_id, 'urm_paypal_verification_token', $paypal_verification_token );

		$query_args = 'form_id=' . absint( $form_id ) . '&user_id=' . absint( $user_id ) . '&hash=' . wp_hash( $form_id . ',' . $user_id . ',' . $paypal_verification_token );
		$return_url = esc_url_raw(
			add_query_arg(
				array(
					'user_registration_return' => base64_encode( $query_args ),
				),
				apply_filters( 'user_registration_paypal_return_url', $paypal_options['return_url'], $valid_form_data )
			)
		);

		$total_amount    = $amount;
		$discount_amount = 0;
		if ( ! empty( $coupon_details ) ) {
			if ( ur_string_to_bool( $paypal_subscription ) ) {
				$discount_amount = $this->calculate_coupon_discount( $coupon_details, $amount );
				$total_amount    = $discount_amount;
			} else {
				// cart-level total handled when building item args for standard.
				$total_amount = $amount;
			}
		}

		if ( $total_amount <= 0 ) {
			return new WP_Error(
				'paypal_invalid_total_amount',
				__( 'PayPal payment stopped. Total amount cannot be less than or equal to zero.', 'user-registration' )
			);
		}

		$customer_email = '';
		foreach ( $valid_form_data as $field_data ) {
			if ( isset( $field_data->field_name ) && 'user_email' === $field_data->field_name ) {
				$customer_email = $field_data->value;
				break;
			}
		}

		$context = array(
			'form_id'                   => $form_id,
			'user_id'                   => $user_id,
			'currency'                  => strtoupper( $currency ),
			'payment_mode'              => $payment_mode,
			'payment_type'              => $payment_type,
			'paypal_options'            => $paypal_options,
			'valid_form_data'           => $valid_form_data,
			'items'                     => $items,
			'coupon_details'            => $coupon_details,
			'product_amount'            => $amount,
			'total_amount'              => $total_amount,
			'return_url'                => $return_url,
			'cancel_url'                => $paypal_options['cancel_url'],
			'customer_email'            => $customer_email,
			'is_subscription'           => ur_string_to_bool( $paypal_subscription ),
			'plan_name'                 => $plan_name,
			'recurring_period'          => $recurring_period,
			'interval_count'            => ! empty( $interval_count ) ? $interval_count : 1,
			'subscription_expiry_date'  => $subscription_expiry_date,
			'paypal_verification_token' => $paypal_verification_token,
			'trial_period_enable'       => ur_string_to_bool( $trial_period_enable ),
			'trial_interval_count'      => ! empty( $trial_interval_count ) ? (int) $trial_interval_count : 1,
			'trial_recurring_period'    => $trial_recurring_period,
		);

		$this->update_initial_payment_meta( $context );

		$logger->debug(
			sprintf( '[User #%d][Form #%d] Prepared PayPal payment context.', $user_id, $form_id ) . "\n" .
			wp_json_encode(
				array(
					'payment_mode'    => $payment_mode,
					'payment_type'    => $payment_type,
					'is_subscription' => $context['is_subscription'],
					'total_amount'    => $total_amount,
					'product_amount'  => $amount,
					'item_count'      => count( $items ),
				),
				JSON_PRETTY_PRINT
			),
			array(
				'source'   => 'urm-pg-paypal',
				'user_id'  => $user_id,
				'form_id'  => $form_id,
				'function' => __FUNCTION__,
			)
		);

		return $context;
	}

	/**
	 * Update initial payment meta.
	 *
	 * @param array $context Context.
	 * @return void
	 */
	private function update_initial_payment_meta( $context ) {
		update_user_meta( $context['user_id'], 'ur_payment_status', 'pending' );
		update_user_meta( $context['user_id'], 'ur_payment_total_amount', $context['total_amount'] );
		update_user_meta( $context['user_id'], 'ur_payment_product_amount', $context['product_amount'] );
		update_user_meta( $context['user_id'], 'ur_payment_recipient', $context['paypal_options']['email'] );
		update_user_meta( $context['user_id'], 'ur_payment_currency', $context['currency'] );
		update_user_meta( $context['user_id'], 'ur_payment_method', $this->should_use_rest_api( $context['form_id'] ) ? 'paypal_rest' : 'paypal_standard' );
		update_user_meta( $context['user_id'], 'ur_payment_type', $context['payment_type'] );
		update_user_meta( $context['user_id'], 'ur_payment_mode', $context['payment_mode'] );
		update_user_meta( $context['user_id'], 'ur_cart_items', wp_json_encode( $context['items'] ) );
		update_user_meta( $context['user_id'], 'ur_paypal_subscription_enabled', $context['is_subscription'] ? 'yes' : 'no' );
		update_user_meta( $context['user_id'], 'ur_paypal_subscription_plan_name', $context['plan_name'] );
		update_user_meta( $context['user_id'], 'ur_paypal_recurring_period', $context['recurring_period'] );
		update_user_meta( $context['user_id'], 'ur_paypal_interval_count', $context['interval_count'] );
		update_user_meta( $context['user_id'], 'ur_paypal_subscription_status', 'active' );
		update_user_meta( $context['user_id'], 'ur_payment_subscription_expiry', $context['subscription_expiry_date'] );
	}

	/**
	 * Decide whether to use REST.
	 *
	 * @param int $form_id Form ID.
	 * @return bool
	 */
	private function should_use_rest_api( $form_id ) {
		$is_new_install = ur_string_to_bool( get_option( 'urm_is_new_installation' ) );
		$client_id      = $this->get_paypal_client_id( $form_id );
		$client_secret  = $this->get_paypal_client_secret( $form_id );

		if ( $is_new_install ) {
			return ! empty( $client_id ) && ! empty( $client_secret );
		}

		if ( ! empty( $client_id ) && ! empty( $client_secret ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Build redirect URL for existing standard flow.
	 *
	 * @param array $context Context.
	 * @return string|WP_Error
	 */
	private function build_standard_redirect( $context ) {
		$logger = ur_get_logger();

		$transaction = '_cart';
		if ( $context['is_subscription'] ) {
			$transaction = '_xclick-subscriptions';
		} elseif ( 'donation' === $context['payment_type'] ) {
			$transaction = '_donations';
		}

		$redirect = ( 'production' === $context['payment_mode'] ) ? 'https://www.paypal.com/cgi-bin/webscr/?' : 'https://www.sandbox.paypal.com/cgi-bin/webscr/?';

		$paypal_args = array(
			'bn'            => 'UserRegistration_SP',
			'business'      => sanitize_email( $context['paypal_options']['email'] ),
			'cancel_return' => $context['cancel_url'],
			'cbt'           => get_bloginfo( 'name' ),
			'charset'       => get_bloginfo( 'charset' ),
			'cmd'           => $transaction,
			'currency_code' => $context['currency'],
			'custom'        => absint( $context['form_id'] ),
			'invoice'       => absint( $context['user_id'] ),
			'notify_url'    => add_query_arg( 'user-registration-listener', 'IPN', home_url( 'index.php' ) ),
			'return'        => $context['return_url'],
			'rm'            => '2',
			'tax'           => 0,
			'upload'        => '1',
			'sra'           => '1',
			'src'           => '1',
			'no_note'       => '1',
			'no_shipping'   => '1',
			'shipping'      => '0',
		);

		if ( '_cart' === $transaction ) {
			$i                  = 1;
			$whole_discount     = 0;
			$discount_amount    = 0;
			$items              = $context['items'];
			$coupon_details     = $context['coupon_details'];
			$remaining_discount = isset( $coupon_details['coupon_discount'] ) ? $coupon_details['coupon_discount'] : 0;

			if ( ! empty( $coupon_details ) ) {
				foreach ( $items as &$item ) {
					if ( 'fixed' === $coupon_details['coupon_discount_type'] ) {
						if ( $remaining_discount >= $item->amount ) {
							$remaining_discount -= $item->amount;
							$item->amount        = 0.00;
						} else {
							$item->amount      -= $remaining_discount;
							$remaining_discount = 0.00;
						}

						if ( 0 == $item->amount ) {
							++$whole_discount;
						}
					} else {
						$item->amount = $item->amount - ( $item->amount * $coupon_details['coupon_discount'] / 100 );
					}
					$discount_amount += $item->amount;
				}
				unset( $item );
			}

			if ( $whole_discount == count( $items ) ) {
				return new WP_Error(
					'paypal_standard_zero_amount',
					__( 'PayPal Standard payment stopped. Total amount cannot be less than or equal to zero.', 'user-registration' )
				);
			}

			foreach ( $items as $item ) {
				$item_amount = user_registration_sanitize_amount( $item->amount, $context['currency'] );
				$item_name   = isset( $item->extra_params['label'] ) ? $item->extra_params['label'] : '';

				$paypal_args[ 'item_name_' . $i ] = stripslashes_deep( html_entity_decode( $item_name, ENT_COMPAT, 'UTF-8' ) );
				$paypal_args[ 'amount_' . $i ]    = $item_amount;
				++$i;
			}

			if ( ! empty( $coupon_details ) ) {
				update_user_meta( $context['user_id'], 'ur_payment_total_amount', $discount_amount );
			}
		} elseif ( '_donations' === $transaction ) {
			$item_names = array();
			foreach ( $context['items'] as $item ) {
				$item_name    = isset( $item->extra_params['label'] ) ? $item->extra_params['label'] : '';
				$item_names[] = stripslashes_deep( html_entity_decode( $item_name, ENT_COMPAT, 'UTF-8' ) );
			}

			$paypal_args['item_name'] = implode( '; ', $item_names );
			$paypal_args['amount']    = $context['total_amount'];
		} else {
			$discount_amount = $context['total_amount'];

			if ( ! empty( $context['coupon_details'] ) ) {
				$paypal_args['t2'] = ! empty( $context['recurring_period'] ) ? strtoupper( substr( $context['recurring_period'], 0, 1 ) ) : '';
				$paypal_args['p2'] = ! empty( $context['interval_count'] ) ? $context['interval_count'] : 1;
				$paypal_args['a2'] = $discount_amount;
			}

			$paypal_args['email']     = sanitize_email( $context['customer_email'] );
			$paypal_args['a3']        = $context['product_amount'];
			$paypal_args['item_name'] = ! empty( $context['plan_name'] ) ? $context['plan_name'] : '';
			$paypal_args['t3']        = ! empty( $context['recurring_period'] ) ? strtoupper( substr( $context['recurring_period'], 0, 1 ) ) : '';
			$paypal_args['p3']        = ! empty( $context['interval_count'] ) ? $context['interval_count'] : 1;
		}

		$paypal_args = apply_filters( 'user_registration_paypal_redirect_args', $paypal_args, $context['valid_form_data'], $context['user_id'] );
		$redirect   .= http_build_query( $paypal_args );
		$redirect    = str_replace( '&amp;', '&', $redirect );

		$logger->success(
			sprintf( '[User #%d][Form #%d] Built PayPal Standard redirect.', $context['user_id'], $context['form_id'] ) . "\n" .
			wp_json_encode(
				array(
					'transaction' => $transaction,
					'method'      => 'standard',
				),
				JSON_PRETTY_PRINT
			),
			array(
				'source'   => 'urm-pg-paypal',
				'user_id'  => $context['user_id'],
				'form_id'  => $context['form_id'],
				'function' => __FUNCTION__,
			)
		);

		return $redirect;
	}

	/**
	 * Build REST order redirect.
	 *
	 * @param array $context Context.
	 * @return string|WP_Error
	 */
	private function build_rest_order_redirect( $context ) {
		$logger    = ur_get_logger();
		$custom_id = $this->build_custom_id( $context );

		$payload = array(
			'intent'              => 'CAPTURE',
			'purchase_units'      => array(
				array(
					'reference_id' => (string) $custom_id,
					'custom_id'    => (string) $custom_id,
					'description'  => sanitize_text_field( $this->build_item_name( $context ) ),
					'amount'       => array(
						'currency_code' => $context['currency'],
						'value'         => number_format( (float) $context['total_amount'], 2, '.', '' ),
					),
				),
			),
			'application_context' => array(
				'return_url'          => $context['return_url'],
				'cancel_url'          => $context['cancel_url'],
				'user_action'         => 'PAY_NOW',
				'shipping_preference' => 'NO_SHIPPING',
				'brand_name'          => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			),
			'payer'               => array(
				'email_address' => sanitize_email( $context['customer_email'] ),
			),
		);

		$response = $this->create_paypal_rest_order( $payload, $context['paypal_options'] );
		if ( is_wp_error( $response ) ) {
			$logger->error(
				sprintf( '[User #%d][Form #%d] PayPal REST order creation failed.', $context['user_id'], $context['form_id'] ) . "\n" .
				wp_json_encode(
					array(
						'message' => $response->get_error_message(),
						'data'    => $response->get_error_data(),
					),
					JSON_PRETTY_PRINT
				),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $context['user_id'],
					'form_id'  => $context['form_id'],
					'function' => __FUNCTION__,
				)
			);

			return $response;
		}

		if ( ! empty( $response['id'] ) ) {
			update_user_meta( $context['user_id'], 'ur_paypal_order_id', sanitize_text_field( $response['id'] ) );
			update_user_meta( $context['user_id'], 'ur_paypal_rest_flow', 'order' );
		}

		$logger->success(
			sprintf( '[User #%d][Form #%d] PayPal REST order created successfully.', $context['user_id'], $context['form_id'] ) . "\n" .
			wp_json_encode(
				array(
					'paypal_order_id' => isset( $response['id'] ) ? $response['id'] : '',
					'total_amount'    => $context['total_amount'],
				),
				JSON_PRETTY_PRINT
			),
			array(
				'source'   => 'urm-pg-paypal',
				'user_id'  => $context['user_id'],
				'form_id'  => $context['form_id'],
				'function' => __FUNCTION__,
			)
		);

		return $this->extract_paypal_approval_url( $response );
	}

	/**
	 * Build REST subscription redirect.
	 *
	 * @param array $context Context.
	 * @return string|WP_Error
	 */
	private function build_rest_subscription_redirect( $context ) {
		$logger  = ur_get_logger();
		$plan_id = $this->get_or_create_paypal_plan_id_for_form( $context );
		if ( is_wp_error( $plan_id ) ) {
			return $plan_id;
		}

		$custom_id = $this->build_custom_id( $context );
		$payload   = array(
			'plan_id'             => sanitize_text_field( $plan_id ),
			'custom_id'           => (string) $custom_id,
			'subscriber'          => array(
				'email_address' => sanitize_email( $context['customer_email'] ),
			),
			'application_context' => array(
				'brand_name'          => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
				'user_action'         => 'SUBSCRIBE_NOW',
				'shipping_preference' => 'NO_SHIPPING',
				'return_url'          => $context['return_url'],
				'cancel_url'          => $context['cancel_url'],
			),
			'start_time'          => gmdate( 'Y-m-d\TH:i:s\Z', time() + 60 ),
		);

		$response = $this->create_paypal_subscription( $payload, $context['paypal_options'] );
		if ( is_wp_error( $response ) ) {
			$logger->error(
				sprintf( '[User #%d][Form #%d] PayPal REST subscription creation failed.', $context['user_id'], $context['form_id'] ) . "\n" .
				wp_json_encode(
					array(
						'message' => $response->get_error_message(),
						'data'    => $response->get_error_data(),
						'plan_id' => $plan_id,
					),
					JSON_PRETTY_PRINT
				),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $context['user_id'],
					'form_id'  => $context['form_id'],
					'function' => __FUNCTION__,
				)
			);

			return $response;
		}

		if ( ! empty( $response['id'] ) ) {
			update_user_meta( $context['user_id'], 'ur_payment_subscription', sanitize_text_field( $response['id'] ) );
			update_user_meta( $context['user_id'], 'ur_paypal_subscription_id', sanitize_text_field( $response['id'] ) );
			update_user_meta( $context['user_id'], 'ur_paypal_rest_flow', 'subscription' );
		}

		$logger->success(
			sprintf( '[User #%d][Form #%d] PayPal REST subscription created successfully.', $context['user_id'], $context['form_id'] ) . "\n" .
			wp_json_encode(
				array(
					'paypal_subscription_id' => isset( $response['id'] ) ? $response['id'] : '',
					'plan_id'                => $plan_id,
				),
				JSON_PRETTY_PRINT
			),
			array(
				'source'   => 'urm-pg-paypal',
				'user_id'  => $context['user_id'],
				'form_id'  => $context['form_id'],
				'function' => __FUNCTION__,
			)
		);

		return $this->extract_paypal_approval_url( $response );
	}

	/**
	 * Process PayPal IPN.
	 *
	 * Kept for email-based PayPal Standard flow only.
	 *
	 * @return void
	 */
	public function paypal_process_ipn() {
		$logger = ur_get_logger();

		if ( ! isset( $_GET['user-registration-listener'] ) || 'IPN' !== $_GET['user-registration-listener'] ) {
			return;
		}

		$data = wp_unslash( $_POST );

		if ( ! is_array( $data ) || empty( $data ) || empty( $data['invoice'] ) ) {
			$logger->notice(
				'PayPal IPN ignored because invoice is missing.',
				array(
					'source'   => 'urm-pg-paypal',
					'function' => __FUNCTION__,
				)
			);
			return;
		}

		$payment_id     = absint( $data['invoice'] );
		$form_id        = get_user_meta( $payment_id, 'ur_form_id', true );
		$payment_status = strtolower( $data['payment_status'] );

		if ( empty( $payment_id ) || empty( $form_id ) ) {
			$logger->notice(
				sprintf( '[User #%d] PayPal IPN ignored because form ID or payment ID is missing.', $payment_id ),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $payment_id,
					'form_id'  => $form_id,
					'function' => __FUNCTION__,
				)
			);
			return;
		}

		if ( $this->should_use_rest_api( $form_id ) ) {
			$logger->debug(
				sprintf( '[User #%d][Form #%d] Skipping IPN because REST flow is active.', $payment_id, $form_id ),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $payment_id,
					'form_id'  => $form_id,
					'function' => __FUNCTION__,
				)
			);
			return;
		}

		$override_global_paypal_settings = ur_get_single_post_meta( $form_id, 'user_registration_override_paypal_global_settings', false );
		$payment_mode                    = ! $override_global_paypal_settings ? get_option( 'user_registration_global_paypal_mode', 'test' ) : ur_get_single_post_meta( $form_id, 'user_registration_paypal_mode', 'test' );
		$payment_mode_key                = 'production' === $payment_mode ? 'live' : $payment_mode;
		$currency                        = get_option( 'user_registration_payment_currency', 'USD' );
		$receiver_email                  = ! $override_global_paypal_settings
			? get_option( sprintf( 'user_registration_global_paypal_%s_email_address', $payment_mode_key ), get_option( 'user_registration_global_paypal_email_address', get_option( 'admin_email' ) ) )
			: ur_get_single_post_meta( $form_id, 'user_registration_paypal_email_address', get_option( 'admin_email' ) );
		$amount                          = get_user_meta( $payment_id, 'ur_payment_total_amount', true );

		if ( ! $this->validate_ipn( $payment_mode ) ) {
			$logger->warning(
				sprintf( '[User #%d][Form #%d] PayPal IPN validation failed.', $payment_id, $form_id ),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $payment_id,
					'form_id'  => $form_id,
					'function' => __FUNCTION__,
				)
			);
			return;
		}

		if ( 'web_accept' !== $data['txn_type'] && 'cart' !== $data['txn_type'] && 'subscr_signup' !== $data['txn_type'] && 'subscr_payment' !== $data['txn_type'] ) {
			return;
		}

		$error = '';
		if ( empty( $receiver_email ) || ! is_email( $receiver_email ) || strtolower( $data['business'] ) !== strtolower( trim( $receiver_email ) ) ) {
			$error = esc_html__( 'Payment failed: recipient emails do not match', 'user-registration' );
		} elseif ( ! empty( $currency ) && strtolower( $data['mc_currency'] ) !== strtolower( $currency ) ) {
			$error = esc_html__( 'Payment failed: currency formats do not match', 'user-registration' );
		} elseif ( empty( $amount ) || number_format( (float) $data['mc_gross'] ) !== number_format( (float) $amount ) ) {
			$error = esc_html__( 'Payment failed: payment amounts do not match', 'user-registration' );
		}

		if ( ! empty( $error ) ) {
			$logger->error(
				sprintf( '[User #%d][Form #%d] PayPal IPN failed.', $payment_id, $form_id ) . "\n" . $error,
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $payment_id,
					'form_id'  => $form_id,
					'function' => __FUNCTION__,
				)
			);
			update_user_meta( $payment_id, 'ur_payment_status', 'failed' );
			return;
		}

		if ( 'completed' === $payment_status || 'production' !== $payment_mode ) {
			update_user_meta( $payment_id, 'ur_payment_status', 'completed' );
			update_user_meta( $payment_id, 'ur_payment_transaction', $data['txn_id'] );
			update_user_meta( $payment_id, 'ur_payment_note', '' );

			$this->create_payment_invoice(
				$payment_id,
				isset( $data['txn_id'] ) ? $data['txn_id'] : '',
				$currency,
				$payment_status
			);

			if ( empty( get_user_meta( $payment_id, 'ur_payment_email_sent', true ) ) ) {
				if ( ur_string_to_bool( get_option( 'user_registration_enable_payment_email', true ) ) ) {
					User_Registration_Pro_Frontend::send_success_email( $payment_id );
					User_Registration_Pro_Frontend::send_success_admin_email( $payment_id );
					update_user_meta( $payment_id, 'ur_payment_email_sent', true );
				}
			}

			if ( empty( get_user_meta( $payment_id, 'ur_welcome_email_sent', true ) ) ) {
				$user_data = get_user_meta( $payment_id );
				$profile   = user_registration_form_data( $payment_id, $form_id );
				$user      = get_user_by( 'id', $payment_id );

				$user_data['user_registration_first_name'] = isset( $user_data['first_name'] ) ? $user_data['first_name'] : array();
				$user_data['user_registration_last_name']  = isset( $user_data['last_name'] ) ? $user_data['last_name'] : array();
				$user_data['user_registration_user_login'] = isset( $user->user_login ) ? array( $user->user_login ) : array();
				$user_data['user_registration_user_email'] = isset( $user->user_email ) ? array( $user->user_email ) : array();

				$valid_form_data = array();
				foreach ( $user_data as $post_key => $post_data ) {
					$pos = strpos( $post_key, 'user_registration_' );
					if ( false !== $pos ) {
						$new_string = substr_replace( $post_key, '', $pos, strlen( 'user_registration_' ) );
						if ( ! empty( $new_string ) && 'geolocation' !== $new_string ) {
							$tmp_array       = ur_get_valid_form_data_format( $new_string, $post_key, $profile, $post_data[0] );
							$valid_form_data = array_merge( $valid_form_data, $tmp_array );
						}
					}
				}

				do_action( 'user_registration_after_register_user_action', $valid_form_data, $form_id, $payment_id );
				update_user_meta( $payment_id, 'ur_welcome_email_sent', true );
			}

			$logger->success(
				sprintf( '[User #%d][Form #%d] PayPal Standard IPN completed successfully.', $payment_id, $form_id ) . "\n" .
				wp_json_encode(
					array(
						'transaction_id' => isset( $data['txn_id'] ) ? $data['txn_id'] : '',
						'payment_status' => $payment_status,
					),
					JSON_PRETTY_PRINT
				),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $payment_id,
					'form_id'  => $form_id,
					'function' => __FUNCTION__,
				)
			);
		} elseif ( 'refunded' === $payment_status ) {
			$note = sprintf( esc_html__( 'Payment refunded: PayPal refund transaction ID: %s', 'user-registration' ), $data['txn_id'] );

			update_user_meta( $payment_id, 'ur_payment_status', 'refunded' );
			update_user_meta( $payment_id, 'ur_payment_note', $note );
		} elseif ( 'pending' === $payment_status && isset( $data['pending_reason'] ) ) {
			update_user_meta( $payment_id, 'ur_payment_status', 'pending' );
			update_user_meta( $payment_id, 'ur_payment_note', $this->get_pending_reason_note( $data['pending_reason'] ) );
		}

		do_action( 'user_registration_paypal_standard_process_complete', $payment_id, $data );
		exit;
	}

	/**
	 * Validate IPN.
	 *
	 * @param string $payment_mode Payment mode.
	 * @return bool
	 */
	public function validate_ipn( $payment_mode ) {
		$logger = ur_get_logger();
		$logger->notice(
			sprintf( 'Checking IPN response validity for payment mode %s.', $payment_mode ),
			array(
				'source'   => 'urm-pg-paypal',
				'function' => __FUNCTION__,
			)
		);

		$validate_ipn        = wp_unslash( $_POST );
		$validate_ipn['cmd'] = '_notify-validate';

		$params = array(
			'body'        => $validate_ipn,
			'timeout'     => 60,
			'httpversion' => '1.1',
			'compress'    => false,
			'decompress'  => false,
			'user-agent'  => 'User Registration IPN Verification',
		);

		$remote_post_url = ( ! empty( $payment_mode ) && 'production' === $payment_mode ) ? 'https://ipnpb.paypal.com/cgi-bin/webscr' : 'https://ipnpb.sandbox.paypal.com/cgi-bin/webscr';
		$response        = wp_safe_remote_post( $remote_post_url, $params );

		if ( ! is_wp_error( $response ) && isset( $response['response']['code'] ) && $response['response']['code'] >= 200 && $response['response']['code'] < 300 && false !== strstr( $response['body'], 'VERIFIED' ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Validate conditional logic for PayPal.
	 *
	 * @param int   $form_id Form ID.
	 * @param array $valid_form_data Valid form data.
	 * @return bool
	 */
	public function paypal_conditional_logic( $form_id, $valid_form_data ) {
		$paypal_integration = get_post_meta( $form_id, 'user_registration_paypal_conditional_integration', true );
		$is_valid           = true;

		if ( count( $paypal_integration ) > 0 ) {
			foreach ( $paypal_integration as $paypal_conditonal_data ) {
				if ( isset( $paypal_conditonal_data['enable_conditional_logic'] ) && ur_string_to_bool( $paypal_conditonal_data['enable_conditional_logic'] ) ) {
					switch ( $paypal_conditonal_data['conditional_logic_data']['conditional_operator'] ) {
						case 'is':
							$is_valid = $valid_form_data[ $paypal_conditonal_data['conditional_logic_data']['conditional_field'] ]->value === $paypal_conditonal_data['conditional_logic_data']['conditional_value'];
							break;
						case 'is_not':
							$is_valid = $valid_form_data[ $paypal_conditonal_data['conditional_logic_data']['conditional_field'] ]->value !== $paypal_conditonal_data['conditional_logic_data']['conditional_value'];
							break;
					}
				}
			}
		}

		return $is_valid;
	}

	/**
	 * Validate conditional logic for Stripe.
	 *
	 * @param int   $form_id Form ID.
	 * @param array $valid_form_data Valid form data.
	 * @return bool
	 */
	public function stripe_conditional_logic( $form_id, $valid_form_data ) {
		$stripe_integration = get_post_meta( $form_id, 'user_registration_stripe_conditional_integration', true );
		$is_valid           = true;

		if ( count( $stripe_integration ) > 0 ) {
			foreach ( $stripe_integration as $stripe_conditonal_data ) {
				if ( isset( $stripe_conditonal_data['enable_conditional_logic'] ) && ur_string_to_bool( $stripe_conditonal_data['enable_conditional_logic'] ) ) {
					switch ( $stripe_conditonal_data['conditional_logic_data']['conditional_operator'] ) {
						case 'is':
							$is_valid = $valid_form_data[ $stripe_conditonal_data['conditional_logic_data']['conditional_field'] ]->value === $stripe_conditonal_data['conditional_logic_data']['conditional_value'];
							break;
						case 'is_not':
							$is_valid = $valid_form_data[ $stripe_conditonal_data['conditional_logic_data']['conditional_field'] ]->value !== $stripe_conditonal_data['conditional_logic_data']['conditional_value'];
							break;
					}
				}
			}
		}

		$urcl_hide_fields = isset( $_POST['urcl_hide_fields'] ) ? (array) json_decode( stripslashes( $_POST['urcl_hide_fields'] ), true ) : array();
		if ( in_array( 'stripe_gateway', $urcl_hide_fields, true ) ) {
			$is_valid = false;
		}

		return $is_valid;
	}

	/**
	 * Handle PayPal response after registration.
	 *
	 * Supports:
	 * - standard return callback
	 * - REST one-time return with token
	 * - REST subscription return with subscription_id
	 *
	 * @return void
	 */
	public function handle_paypal_response_after_registration() {
		$logger = ur_get_logger();

		if ( ! isset( $_GET['user_registration_return'] ) ) {
			return;
		}

		$return = base64_decode( $_GET['user_registration_return'] );
		$query  = array();
		parse_str( $return, $query );

		$form_id = isset( $query['form_id'] ) ? absint( $query['form_id'] ) : 0;
		$user_id = isset( $query['user_id'] ) ? absint( $query['user_id'] ) : 0;

		if ( empty( $user_id ) || empty( $form_id ) ) {
			return;
		}

		$supplied_hash             = isset( $query['hash'] ) ? $query['hash'] : '';
		$paypal_verification_token = get_user_meta( $user_id, 'urm_paypal_verification_token', true );
		$expected_hash             = wp_hash( $form_id . ',' . $user_id . ',' . $paypal_verification_token );

		if ( empty( $supplied_hash ) || ! hash_equals( $supplied_hash, $expected_hash ) ) {
			$logger->warning(
				sprintf( '[User #%d][Form #%d] PayPal return hash validation failed.', $user_id, $form_id ),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $user_id,
					'form_id'  => $form_id,
					'function' => __FUNCTION__,
				)
			);
			return;
		}

		delete_user_meta( $user_id, 'urm_paypal_verification_token' );

		$paypal_is_enabled  = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_paypal_standard', false ) );
		$stripe_is_enabled  = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_stripe', false ) );
		$anet_is_enabled    = ur_string_to_bool( ur_get_single_post_meta( $form_id, 'user_registration_enable_authorize_net', false ) );
		$payment_is_enabled = apply_filters( 'user_registration_enable_payment', $paypal_is_enabled ? $paypal_is_enabled : ( $stripe_is_enabled || $anet_is_enabled ) );

		if ( ! $payment_is_enabled || ! $paypal_is_enabled ) {
			return;
		}

		// For REST API, activate payment now — the hash uses a single-use token (deleted
		// above) so the return URL cannot be replayed. For standard/IPN, the IPN handler
		// does this verification instead.
		if ( $this->should_use_rest_api( $form_id ) ) {
			$this->activate_rest_payment_for_user( $form_id, $user_id );
		}

		$login_option = ur_get_user_login_option( $user_id );
		if ( 'auto_login' === $login_option ) {
			wp_clear_auth_cookie();
			wp_set_auth_cookie( $user_id );
		}
	}

	/**
	 * Output conditional logic.
	 *
	 * @param int   $form_id Form ID.
	 * @param array $connection Connection.
	 * @return string
	 */
	public function output_paypal_conditional_logic( $form_id, $connection = array() ) {
		return user_registration_pro_render_conditional_logic( $connection, 'paypal', $form_id );
	}

	/**
	 * Unsubscribe the payment gateway on the user deletion.
	 *
	 * @param int   $user_id User ID.
	 * @param mixed $reassign Reassign target.
	 * @param mixed $user User object.
	 * @return void
	 */
	public function unsubscribe_payment_gateway_on_user_delete( $user_id, $reassign, $user ) {
		$logger = ur_get_logger();

		if ( null !== $reassign ) {
			return;
		}

		$subscription_id = get_user_meta( $user_id, 'ur_payment_subscription', true );
		if ( '' === $subscription_id ) {
			$logger->debug(
				sprintf( '[User #%d] Missing subscription id during PayPal unsubscribe.', $user_id ),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $user_id,
					'function' => __FUNCTION__,
				)
			);
			return;
		}

		$form_id = ur_get_form_id_by_userid( $user_id );

		if ( ! $this->should_use_rest_api( $form_id ) ) {
			$logger->debug(
				sprintf( '[User #%d][Form #%d] Skipping REST unsubscribe because standard flow is active.', $user_id, $form_id ),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $user_id,
					'form_id'  => $form_id,
					'function' => __FUNCTION__,
				)
			);
			return;
		}

		$paypal_options = array(
			'mode'       => $this->get_paypal_mode_for_form( $form_id ),
			'client_id'  => $this->get_paypal_client_id( $form_id ),
			'secret_key' => $this->get_paypal_client_secret( $form_id ),
		);

		$response = $this->cancel_paypal_subscription(
			$subscription_id,
			array(
				'reason' => 'User deleted from site',
			),
			$paypal_options
		);

		if ( is_wp_error( $response ) ) {
			$logger->warning(
				sprintf( '[User #%d][Form #%d] PayPal subscription cancellation failed on user delete.', $user_id, $form_id ) . "\n" .
				wp_json_encode(
					array(
						'subscription_id' => $subscription_id,
						'message'         => $response->get_error_message(),
						'data'            => $response->get_error_data(),
					),
					JSON_PRETTY_PRINT
				),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $user_id,
					'form_id'  => $form_id,
					'function' => __FUNCTION__,
				)
			);
			return;
		}

		$logger->success(
			sprintf( '[User #%d][Form #%d] PayPal subscription cancelled on user delete.', $user_id, $form_id ) . "\n" .
			wp_json_encode(
				array(
					'subscription_id' => $subscription_id,
				),
				JSON_PRETTY_PRINT
			),
			array(
				'source'   => 'urm-pg-paypal',
				'user_id'  => $user_id,
				'form_id'  => $form_id,
				'function' => __FUNCTION__,
			)
		);
	}

	/**
	 * Calculate coupon discount.
	 *
	 * @param array $coupon_details Coupon details.
	 * @param mixed $amount Amount.
	 * @return mixed
	 */
	public function calculate_coupon_discount( $coupon_details, $amount ) {
		if ( 'fixed' === $coupon_details['coupon_discount_type'] ) {
			$amount = $amount - $coupon_details['coupon_discount'];
		} elseif ( 'percent' === $coupon_details['coupon_discount_type'] ) {
			$amount = $amount - ( $amount * $coupon_details['coupon_discount'] / 100 );
		}

		return $amount;
	}

	/**
	 * Get PayPal client ID.
	 *
	 * @param int $form_id Form ID.
	 * @return string
	 */
	private function get_paypal_client_id( $form_id ) {
		$override_global = ur_get_single_post_meta( $form_id, 'user_registration_override_paypal_global_settings', false );
		$mode_key        = $this->get_paypal_mode_key( $form_id );

		return $override_global
			? ur_get_single_post_meta( $form_id, 'user_registration_paypal_client_id', '' )
			: get_option( sprintf( 'user_registration_global_paypal_%s_client_id', $mode_key ), get_option( 'user_registration_global_paypal_client_id', '' ) );
	}

	/**
	 * Get PayPal client secret.
	 *
	 * @param int $form_id Form ID.
	 * @return string
	 */
	private function get_paypal_client_secret( $form_id ) {
		$override_global = ur_get_single_post_meta( $form_id, 'user_registration_override_paypal_global_settings', false );
		$mode_key        = $this->get_paypal_mode_key( $form_id );

		return $override_global
			? ur_get_single_post_meta( $form_id, 'user_registration_paypal_client_secret', '' )
			: get_option( sprintf( 'user_registration_global_paypal_%s_client_secret', $mode_key ), get_option( 'user_registration_global_paypal_client_secret', '' ) );
	}

	/**
	 * Get PayPal mode for form.
	 *
	 * @param int $form_id Form ID.
	 * @return string
	 */
	private function get_paypal_mode_for_form( $form_id ) {
		$override_global = ur_get_single_post_meta( $form_id, 'user_registration_override_paypal_global_settings', false );

		return ! $override_global ? get_option( 'user_registration_global_paypal_mode', 'test' ) : ur_get_single_post_meta( $form_id, 'user_registration_paypal_mode', 'test' );
	}

	/**
	 * Get the option key segment for the current PayPal mode.
	 * Options are stored under _live_ / _test_ keys, but the mode value is 'production' / 'test'.
	 *
	 * @param int $form_id Form ID.
	 * @return string 'live' or 'test'
	 */
	private function get_paypal_mode_key( $form_id ) {
		$mode = $this->get_paypal_mode_for_form( $form_id );
		return 'production' === $mode ? 'live' : $mode;
	}

	/**
	 * Create payment invoice.
	 *
	 * @param int    $user_id User ID.
	 * @param string $invoice_no Invoice number.
	 * @param string $currency Currency.
	 * @param string $status Status.
	 * @return void
	 */
	private function create_payment_invoice( $user_id, $invoice_no, $currency, $status ) {
		$payment_invoice = array();

		$invoice                     = array();
		$invoice['invoice_date']     = date( 'Y-m-d H:i:s' );
		$invoice['invoice_no']       = $invoice_no;
		$invoice['invoice_item']     = get_user_meta( $user_id, 'ur_cart_items' );
		$invoice['invoice_currency'] = $currency;
		$invoice['invoice_amount']   = get_user_meta( $user_id, 'ur_payment_total_amount', true );
		$invoice['invoice_status']   = $status;

		array_push( $payment_invoice, $invoice );
		update_user_meta( $user_id, 'ur_payment_invoices', $payment_invoice );
	}

	/**
	 * Fetch PayPal order details via REST API.
	 *
	 * @param string $order_id      PayPal order ID.
	 * @param array  $paypal_options PayPal credentials/mode.
	 * @return array|WP_Error
	 */
	private function get_paypal_order_details( $order_id, $paypal_options ) {
		return $this->paypal_rest_request( 'GET', '/v2/checkout/orders/' . rawurlencode( $order_id ), null, $paypal_options );
	}

	/**
	 * Mark a REST payment as completed for a normal-registration user.
	 *
	 * Idempotent: safe to call from both the redirect handler and the webhook fallback.
	 *
	 * @param int    $user_id        WordPress user ID.
	 * @param int    $form_id        Form ID.
	 * @param string $transaction_id PayPal capture / transaction ID.
	 * @return void
	 */
	private function finalize_rest_payment( $user_id, $form_id, $transaction_id ) {
		$logger = ur_get_logger();

		if ( 'completed' === get_user_meta( $user_id, 'ur_payment_status', true ) ) {
			return;
		}

		$currency = get_option( 'user_registration_payment_currency', 'USD' );

		update_user_meta( $user_id, 'ur_payment_status', 'completed' );
		update_user_meta( $user_id, 'ur_payment_transaction', $transaction_id );
		update_user_meta( $user_id, 'ur_payment_note', '' );

		$this->create_payment_invoice( $user_id, $transaction_id, $currency, 'completed' );

		if ( empty( get_user_meta( $user_id, 'ur_payment_email_sent', true ) ) ) {
			if ( ur_string_to_bool( get_option( 'user_registration_enable_payment_email', true ) ) ) {
				User_Registration_Pro_Frontend::send_success_email( $user_id );
				User_Registration_Pro_Frontend::send_success_admin_email( $user_id );
				update_user_meta( $user_id, 'ur_payment_email_sent', true );
			}
		}

		if ( empty( get_user_meta( $user_id, 'ur_welcome_email_sent', true ) ) ) {
			$user_data = get_user_meta( $user_id );
			$profile   = user_registration_form_data( $user_id, $form_id );
			$user      = get_user_by( 'id', $user_id );

			$user_data['user_registration_first_name'] = isset( $user_data['first_name'] ) ? $user_data['first_name'] : array();
			$user_data['user_registration_last_name']  = isset( $user_data['last_name'] ) ? $user_data['last_name'] : array();
			$user_data['user_registration_user_login'] = isset( $user->user_login ) ? array( $user->user_login ) : array();
			$user_data['user_registration_user_email'] = isset( $user->user_email ) ? array( $user->user_email ) : array();

			$valid_form_data = array();
			foreach ( $user_data as $post_key => $post_data ) {
				$pos = strpos( $post_key, 'user_registration_' );
				if ( false !== $pos ) {
					$new_string = substr_replace( $post_key, '', $pos, strlen( 'user_registration_' ) );
					if ( ! empty( $new_string ) && 'geolocation' !== $new_string ) {
						$tmp_array       = ur_get_valid_form_data_format( $new_string, $post_key, $profile, $post_data[0] );
						$valid_form_data = array_merge( $valid_form_data, $tmp_array );
					}
				}
			}

			do_action( 'user_registration_after_register_user_action', $valid_form_data, $form_id, $user_id );
			update_user_meta( $user_id, 'ur_welcome_email_sent', true );
		}

		do_action( 'user_registration_paypal_standard_process_complete', $user_id, array( 'txn_id' => $transaction_id ) );

		$logger->success(
			sprintf( '[User #%d][Form #%d] PayPal REST payment finalized.', $user_id, $form_id ) . "\n" .
			wp_json_encode(
				array(
					'transaction_id' => $transaction_id,
				),
				JSON_PRETTY_PRINT
			),
			array(
				'source'   => 'urm-pg-paypal',
				'user_id'  => $user_id,
				'form_id'  => $form_id,
				'function' => __FUNCTION__,
			)
		);
	}

	/**
	 * Check the PayPal order status and activate payment for a normal-registration user.
	 *
	 * Called from the redirect handler after a successful hash verification.
	 *
	 * @param int $form_id Form ID.
	 * @param int $user_id WordPress user ID.
	 * @return void
	 */
	private function activate_rest_payment_for_user( $form_id, $user_id ) {
		$logger = ur_get_logger();

		if ( 'completed' === get_user_meta( $user_id, 'ur_payment_status', true ) ) {
			return;
		}

		$order_id = get_user_meta( $user_id, 'ur_paypal_order_id', true );
		if ( empty( $order_id ) ) {
			$logger->warning(
				sprintf( '[User #%d][Form #%d] REST return: no stored PayPal order ID.', $user_id, $form_id ),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $user_id,
					'form_id'  => $form_id,
					'function' => __FUNCTION__,
				)
			);
			return;
		}

		$paypal_options = array(
			'mode'       => $this->get_paypal_mode_for_form( $form_id ),
			'client_id'  => $this->get_paypal_client_id( $form_id ),
			'secret_key' => $this->get_paypal_client_secret( $form_id ),
		);

		$order_details = $this->get_paypal_order_details( $order_id, $paypal_options );
		if ( is_wp_error( $order_details ) ) {
			$logger->warning(
				sprintf( '[User #%d][Form #%d] REST return: failed to get order details.', $user_id, $form_id ) . "\n" .
				wp_json_encode( array( 'message' => $order_details->get_error_message() ), JSON_PRETTY_PRINT ),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $user_id,
					'form_id'  => $form_id,
					'function' => __FUNCTION__,
				)
			);
			return;
		}

		$order_status = isset( $order_details['status'] ) ? $order_details['status'] : '';

		if ( 'COMPLETED' === $order_status ) {
			$transaction_id = $this->extract_capture_id_from_order_response( $order_details );
			$this->finalize_rest_payment( $user_id, $form_id, $transaction_id );
			return;
		}

		if ( 'APPROVED' === $order_status ) {
			$capture_response = $this->capture_paypal_order( $order_id, $paypal_options );
			if ( is_wp_error( $capture_response ) ) {
				$logger->warning(
					sprintf( '[User #%d][Form #%d] REST return: capture failed.', $user_id, $form_id ) . "\n" .
					wp_json_encode( array( 'message' => $capture_response->get_error_message() ), JSON_PRETTY_PRINT ),
					array(
						'source'   => 'urm-pg-paypal',
						'user_id'  => $user_id,
						'form_id'  => $form_id,
						'function' => __FUNCTION__,
					)
				);
				return;
			}
			$transaction_id = $this->extract_capture_id_from_order_response( $capture_response );
			$this->finalize_rest_payment( $user_id, $form_id, $transaction_id );
			return;
		}

		$logger->notice(
			sprintf( '[User #%d][Form #%d] REST return: order in unexpected status (%s), skipping.', $user_id, $form_id, $order_status ),
			array(
				'source'   => 'urm-pg-paypal',
				'user_id'  => $user_id,
				'form_id'  => $form_id,
				'function' => __FUNCTION__,
			)
		);
	}

	/**
	 * Handle PayPal REST webhook for normal registration (not membership).
	 *
	 * Hooked as a fallback after the membership webhook handler returns false.
	 *
	 * @param bool  $result Current result (false from membership handler).
	 * @param array $event  Decoded PayPal webhook event payload.
	 * @return bool
	 */
	public function handle_rest_webhook_for_registration( $result, $event ) {
		$event_type = isset( $event['event_type'] ) ? $event['event_type'] : '';
		$resource   = isset( $event['resource'] ) ? $event['resource'] : array();
		$logger     = ur_get_logger();

		$logger->notice(
			sprintf( '[PayPal][Normal Registration] Webhook handler called for event: %s.', $event_type ),
			array( 'source' => 'urm-pg-paypal' )
		);

		switch ( $event_type ) {
			case 'CHECKOUT.ORDER.APPROVED':
				$outcome = $this->handle_registration_order_approved( $resource );
				break;

			case 'PAYMENT.CAPTURE.COMPLETED':
				$outcome = $this->handle_registration_capture_completed( $resource );
				break;

			default:
				return false;
		}

		$logger->notice(
			sprintf( '[PayPal][Normal Registration] Webhook handler result for %s: %s.', $event_type, $outcome ? 'success' : 'failed' ),
			array( 'source' => 'urm-pg-paypal' )
		);

		return $outcome;
	}

	/**
	 * Process CHECKOUT.ORDER.APPROVED for a normal-registration payment.
	 *
	 * Parses the two-part custom_id (form_id-user_id), captures the order,
	 * and finalises the payment.
	 *
	 * @param array $resource PayPal event resource.
	 * @return bool
	 */
	private function handle_registration_order_approved( $resource ) {
		$logger    = ur_get_logger();
		$custom_id = isset( $resource['purchase_units'][0]['custom_id'] ) ? $resource['purchase_units'][0]['custom_id'] : '';
		$parts     = explode( '-', $custom_id );

		if ( count( $parts ) !== 2 || ! ctype_digit( $parts[0] ) || ! ctype_digit( $parts[1] ) ) {
			$logger->debug(
				sprintf( '[PayPal][Normal Registration] CHECKOUT.ORDER.APPROVED skipped — custom_id "%s" is not a 2-part numeric registration ID.', $custom_id ),
				array( 'source' => 'urm-pg-paypal' )
			);
			return false;
		}

		$form_id = absint( $parts[0] );
		$user_id = absint( $parts[1] );

		if ( empty( $form_id ) || empty( $user_id ) || ! get_userdata( $user_id ) ) {
			$logger->debug(
				sprintf( '[PayPal][Normal Registration] CHECKOUT.ORDER.APPROVED skipped — form_id=%d or user_id=%d invalid.', $form_id, $user_id ),
				array( 'source' => 'urm-pg-paypal' )
			);
			return false;
		}

		if ( 'completed' === get_user_meta( $user_id, 'ur_payment_status', true ) ) {
			$logger->debug(
				sprintf( '[PayPal][Normal Registration] CHECKOUT.ORDER.APPROVED — payment already completed for user #%d, skipping.', $user_id ),
				array( 'source' => 'urm-pg-paypal' )
			);
			return true;
		}

		$order_id = isset( $resource['id'] ) ? sanitize_text_field( $resource['id'] ) : '';
		if ( empty( $order_id ) ) {
			return false;
		}

		$paypal_options = array(
			'mode'       => $this->get_paypal_mode_for_form( $form_id ),
			'client_id'  => $this->get_paypal_client_id( $form_id ),
			'secret_key' => $this->get_paypal_client_secret( $form_id ),
		);

		$capture_response = $this->capture_paypal_order( $order_id, $paypal_options );

		if ( is_wp_error( $capture_response ) ) {
			$error_data = $capture_response->get_error_data();
			$issue      = isset( $error_data['body']['details'][0]['issue'] ) ? $error_data['body']['details'][0]['issue'] : '';

			if ( 'ORDER_ALREADY_CAPTURED' === $issue ) {
				$order_details = $this->get_paypal_order_details( $order_id, $paypal_options );
				if ( ! is_wp_error( $order_details ) ) {
					$transaction_id = $this->extract_capture_id_from_order_response( $order_details );
					$this->finalize_rest_payment( $user_id, $form_id, $transaction_id );
					return true;
				}
			}

			$logger->warning(
				sprintf( '[User #%d][Form #%d] Webhook CHECKOUT.ORDER.APPROVED: capture failed.', $user_id, $form_id ) . "\n" .
				wp_json_encode( array( 'message' => $capture_response->get_error_message() ), JSON_PRETTY_PRINT ),
				array(
					'source'   => 'urm-pg-paypal',
					'user_id'  => $user_id,
					'form_id'  => $form_id,
					'function' => __FUNCTION__,
				)
			);
			return false;
		}

		$transaction_id = $this->extract_capture_id_from_order_response( $capture_response );
		$this->finalize_rest_payment( $user_id, $form_id, $transaction_id );
		return true;
	}

	/**
	 * Process PAYMENT.CAPTURE.COMPLETED for a normal-registration payment.
	 *
	 * Looks up the user by their stored PayPal order ID and finalises payment.
	 *
	 * @param array $resource PayPal event resource.
	 * @return bool
	 */
	private function handle_registration_capture_completed( $resource ) {
		$logger     = ur_get_logger();
		$order_id   = isset( $resource['supplementary_data']['related_ids']['order_id'] )
			? sanitize_text_field( $resource['supplementary_data']['related_ids']['order_id'] )
			: '';
		$capture_id = isset( $resource['id'] ) ? sanitize_text_field( $resource['id'] ) : '';

		$users       = array();
		$lookup_type = '';

		if ( ! empty( $order_id ) ) {
			$users       = get_users(
				array(
					'meta_key'   => 'ur_paypal_order_id',
					'meta_value' => $order_id,
					'number'     => 1,
					'fields'     => 'ID',
				)
			);
			$lookup_type = 'order_id';
		}

		// Fallback: look up by capture ID stored after a previous finalization attempt.
		if ( empty( $users ) && ! empty( $capture_id ) ) {
			$users = get_users(
				array(
					'meta_key'   => 'ur_payment_transaction',
					'meta_value' => $capture_id,
					'number'     => 1,
					'fields'     => 'ID',
				)
			);
			$lookup_type = 'capture_id';
		}

		if ( empty( $users ) ) {
			$logger->debug(
				sprintf( '[PayPal][Normal Registration] PAYMENT.CAPTURE.COMPLETED — no user found for order_id="%s", capture_id="%s".', $order_id, $capture_id ),
				array( 'source' => 'urm-pg-paypal' )
			);
			return false;
		}

		$user_id = absint( $users[0] );
		$form_id = absint( get_user_meta( $user_id, 'ur_form_id', true ) );

		if ( empty( $form_id ) ) {
			$logger->debug(
				sprintf( '[PayPal][Normal Registration] PAYMENT.CAPTURE.COMPLETED — user #%d found via %s but has no form_id meta.', $user_id, $lookup_type ),
				array( 'source' => 'urm-pg-paypal' )
			);
			return false;
		}

		$transaction_id = $capture_id;
		$this->finalize_rest_payment( $user_id, $form_id, $transaction_id );
		return true;
	}

	/**
	 * Get pending reason note.
	 *
	 * @param string $pending_reason Pending reason.
	 * @return string
	 */
	private function get_pending_reason_note( $pending_reason ) {
		switch ( strtolower( $pending_reason ) ) {
			case 'echeck':
				return esc_html__( 'Payment made via eCheck and will clear automatically in 5-8 days', 'user-registration' );
			case 'address':
				return esc_html__( 'Payment requires a confirmed customer address and must be accepted manually through PayPal', 'user-registration' );
			case 'intl':
				return esc_html__( 'Payment must be accepted manually through PayPal due to international account regulations', 'user-registration' );
			case 'multi-currency':
				return esc_html__( 'Payment received in non-shop currency and must be accepted manually through PayPal', 'user-registration' );
			case 'paymentreview':
			case 'regulatory_review':
				return esc_html__( 'Payment is being reviewed by PayPal staff as high-risk or in possible violation of government regulations', 'user-registration' );
			case 'unilateral':
				return esc_html__( 'Payment was sent to non-confirmed or non-registered email address.', 'user-registration' );
			case 'upgrade':
				return esc_html__( 'PayPal account must be upgraded before this payment can be accepted', 'user-registration' );
			case 'verify':
				return esc_html__( 'PayPal account is not verified. Verify account in order to accept this payment', 'user-registration' );
			case 'other':
				return esc_html__( 'Payment is pending for unknown reasons. Contact PayPal support for assistance', 'user-registration' );
			default:
				return esc_html( $pending_reason );
		}
	}

	/**
	 * Build item name.
	 *
	 * @param array $context Context.
	 * @return string
	 */
	private function build_item_name( $context ) {
		if ( ! empty( $context['plan_name'] ) ) {
			return $context['plan_name'];
		}

		$item_names = array();
		foreach ( $context['items'] as $item ) {
			$item_name = isset( $item->extra_params['label'] ) ? $item->extra_params['label'] : '';
			if ( ! empty( $item_name ) ) {
				$item_names[] = stripslashes_deep( html_entity_decode( $item_name, ENT_COMPAT, 'UTF-8' ) );
			}
		}

		return ! empty( $item_names ) ? implode( '; ', $item_names ) : __( 'Registration Payment', 'user-registration' );
	}

	/**
	 * Build custom id.
	 *
	 * @param array $context Context.
	 * @return string
	 */
	private function build_custom_id( $context ) {
		return $context['form_id'] . '-' . $context['user_id'];
	}

	/**
	 * Extract approval URL.
	 *
	 * @param array|WP_Error $response Response.
	 * @return string|WP_Error
	 */
	private function extract_paypal_approval_url( $response ) {
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		if ( empty( $response['links'] ) || ! is_array( $response['links'] ) ) {
			return new WP_Error(
				'paypal_missing_links',
				__( 'PayPal response does not contain approval links.', 'user-registration' )
			);
		}

		foreach ( $response['links'] as $link ) {
			if ( ! empty( $link['rel'] ) && in_array( $link['rel'], array( 'approve', 'payer-action' ), true ) && ! empty( $link['href'] ) ) {
				return esc_url_raw( $link['href'] );
			}
		}

		return new WP_Error(
			'paypal_missing_approve_url',
			__( 'PayPal approval URL not found.', 'user-registration' )
		);
	}

	/**
	 * Create PayPal REST order.
	 *
	 * @param array $payload Payload.
	 * @param array $paypal_options Options.
	 * @return array|WP_Error
	 */
	private function create_paypal_rest_order( $payload, $paypal_options ) {
		return $this->paypal_rest_request( 'POST', '/v2/checkout/orders', $payload, $paypal_options );
	}

	/**
	 * Capture PayPal order.
	 *
	 * @param string $order_id Order ID.
	 * @param array  $paypal_options Options.
	 * @return array|WP_Error
	 */
	private function capture_paypal_order( $order_id, $paypal_options ) {
		return $this->paypal_rest_request( 'POST', '/v2/checkout/orders/' . rawurlencode( $order_id ) . '/capture', null, $paypal_options );
	}

	/**
	 * Create PayPal subscription.
	 *
	 * @param array $payload Payload.
	 * @param array $paypal_options Options.
	 * @return array|WP_Error
	 */
	private function create_paypal_subscription( $payload, $paypal_options ) {
		return $this->paypal_rest_request( 'POST', '/v1/billing/subscriptions', $payload, $paypal_options );
	}

	/**
	 * Get PayPal subscription.
	 *
	 * @param string $subscription_id Subscription ID.
	 * @param array  $paypal_options Options.
	 * @return array|WP_Error
	 */
	private function get_paypal_subscription( $subscription_id, $paypal_options ) {
		return $this->paypal_rest_request( 'GET', '/v1/billing/subscriptions/' . rawurlencode( $subscription_id ), null, $paypal_options );
	}

	/**
	 * Cancel PayPal subscription.
	 *
	 * @param string $subscription_id Subscription ID.
	 * @param array  $payload Payload.
	 * @param array  $paypal_options Options.
	 * @return array|WP_Error
	 */
	private function cancel_paypal_subscription( $subscription_id, $payload, $paypal_options ) {
		return $this->paypal_rest_request( 'POST', '/v1/billing/subscriptions/' . rawurlencode( $subscription_id ) . '/cancel', $payload, $paypal_options );
	}

	/**
	 * Generic REST request helper.
	 *
	 * @param string     $method HTTP method.
	 * @param string     $path API path.
	 * @param array|null $payload Payload.
	 * @param array      $paypal_options Options.
	 * @return array|WP_Error
	 */
	private function paypal_rest_request( $method, $path, $payload, $paypal_options ) {
		$access_token = $this->get_paypal_access_token( $paypal_options );
		if ( is_wp_error( $access_token ) ) {
			return $access_token;
		}

		$args = array(
			'timeout' => 45,
			'method'  => strtoupper( $method ),
			'headers' => array(
				'Authorization'     => 'Bearer ' . $access_token,
				'Content-Type'      => 'application/json',
				'Accept'            => 'application/json',
				'PayPal-Request-Id' => wp_generate_uuid4(),
			),
		);

		if ( null !== $payload ) {
			$args['body'] = wp_json_encode( $payload );
		}

		$response = wp_remote_request( $this->get_paypal_api_base_url( $paypal_options['mode'] ) . $path, $args );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$status = wp_remote_retrieve_response_code( $response );
		$body   = wp_remote_retrieve_body( $response );
		$parsed = ! empty( $body ) ? json_decode( $body, true ) : array();

		if ( $status < 200 || $status >= 300 ) {
			return new WP_Error(
				'paypal_rest_request_failed',
				isset( $parsed['message'] ) ? $parsed['message'] : __( 'PayPal API request failed.', 'user-registration' ),
				array(
					'status' => $status,
					'body'   => $parsed,
				)
			);
		}

		return is_array( $parsed ) ? $parsed : array( 'status' => $status );
	}

	/**
	 * Get OAuth access token.
	 *
	 * @param array $paypal_options Options.
	 * @return string|WP_Error
	 */
	private function get_paypal_access_token( $paypal_options ) {
		$client_id  = trim( (string) $paypal_options['client_id'] );
		$secret_key = trim( (string) $paypal_options['secret_key'] );
		$mode       = ! empty( $paypal_options['mode'] ) ? $paypal_options['mode'] : 'test';

		if ( '' === $client_id || '' === $secret_key ) {
			return new WP_Error(
				'paypal_missing_credentials',
				__( 'PayPal client ID or secret key is missing.', 'user-registration' )
			);
		}

		$response = wp_remote_post(
			$this->get_paypal_api_base_url( $mode ) . '/v1/oauth2/token',
			array(
				'timeout' => 45,
				'headers' => array(
					'Accept'          => 'application/json',
					'Accept-Language' => 'en_US',
					'Authorization'   => 'Basic ' . base64_encode( $client_id . ':' . $secret_key ),
					'Content-Type'    => 'application/x-www-form-urlencoded',
				),
				'body'    => array(
					'grant_type' => 'client_credentials',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$status = wp_remote_retrieve_response_code( $response );
		$body   = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $status < 200 || $status >= 300 || empty( $body['access_token'] ) ) {
			return new WP_Error(
				'paypal_access_token_failed',
				isset( $body['error_description'] ) ? $body['error_description'] : __( 'Unable to retrieve PayPal access token.', 'user-registration' ),
				$body
			);
		}

		return $body['access_token'];
	}

	/**
	 * Get API base URL.
	 *
	 * @param string $mode Mode.
	 * @return string
	 */
	private function get_paypal_api_base_url( $mode ) {
		return 'production' === $mode ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
	}

	/**
	 * Extract capture ID from order response.
	 *
	 * @param array $capture_response Capture response.
	 * @return string
	 */
	private function extract_capture_id_from_order_response( $capture_response ) {
		if ( ! empty( $capture_response['purchase_units'][0]['payments']['captures'][0]['id'] ) ) {
			return sanitize_text_field( $capture_response['purchase_units'][0]['payments']['captures'][0]['id'] );
		}

		if ( ! empty( $capture_response['id'] ) ) {
			return sanitize_text_field( $capture_response['id'] );
		}

		return '';
	}

	/**
	 * Get or create PayPal product.
	 *
	 * @param array $context Context.
	 * @return string|WP_Error
	 */
	private function get_or_create_paypal_product_id_for_form( $context ) {
		$product_meta_key = '_ur_paypal_product_id_rest';
		$product_id       = get_post_meta( $context['form_id'], $product_meta_key, true );

		if ( ! empty( $product_id ) ) {
			return sanitize_text_field( $product_id );
		}

		// $product_payload = array(
		//  'name'        => sanitize_text_field( ! empty( $context['plan_name'] ) ? $context['plan_name'] : $this->build_item_name( $context ) ),
		//  'description' => sanitize_text_field( $this->build_item_name( $context ) ),
		//  'type'        => 'SERVICE',
		//  'category'    => 'SOFTWARE',
		// );

		$form_post  = get_post( $context['form_id'] );
		$form_title = ! empty( $form_post ) && ! empty( $form_post->post_title ) ? $form_post->post_title : __( 'Registration Product', 'user-registration' );

		$form_title = apply_filters( 'ur_override_product_name_title', $form_title );

		$product_payload = array(
			'name'        => sanitize_text_field( $form_title ),
			'description' => sanitize_text_field( $form_title ),
			'type'        => 'SERVICE',
			'category'    => 'SOFTWARE',
		);

		$response = $this->paypal_rest_request( 'POST', '/v1/catalogs/products', $product_payload, $context['paypal_options'] );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$product_id = isset( $response['id'] ) ? $response['id'] : '';
		if ( empty( $product_id ) ) {
			return new WP_Error(
				'paypal_product_create_failed',
				__( 'PayPal product could not be created.', 'user-registration' )
			);
		}

		update_post_meta( $context['form_id'], $product_meta_key, sanitize_text_field( $product_id ) );

		return sanitize_text_field( $product_id );
	}

	/**
	 * Get or create PayPal plan ID for form subscription.
	 *
	 * @param array $context Context.
	 * @return string|WP_Error
	 */
	private function get_or_create_paypal_plan_id_for_form( $context ) {
		$formatted_amount = number_format( (float) $context['product_amount'], 2, '.', '' );
		$plan_name        = ! empty( $context['plan_name'] ) ? $context['plan_name'] : __( 'Registration Subscription Plan', 'user-registration' );

		$plan_cache_key = md5(
			wp_json_encode(
				array(
					'form_id'                => (int) $context['form_id'],
					'currency'               => (string) $context['currency'],
					'amount'                 => number_format( (float) $context['product_amount'], 2, '.', '' ),
					'recurring_period'       => (string) $context['recurring_period'],
					'interval_count'         => (int) $context['interval_count'],
					'plan_name'              => (string) $context['plan_name'],
					'trial_period_enable'    => ! empty( $context['trial_period_enable'] ),
					'trial_interval_count'   => isset( $context['trial_interval_count'] ) ? (int) $context['trial_interval_count'] : 1,
					'trial_recurring_period' => isset( $context['trial_recurring_period'] ) ? (string) $context['trial_recurring_period'] : '',
				)
			)
		);

		$stored_plans = get_post_meta( $context['form_id'], '_ur_paypal_rest_plan_map', true );
		$stored_plans = is_array( $stored_plans ) ? $stored_plans : array();

		if ( ! empty( $stored_plans[ $plan_cache_key ] ) ) {
			return sanitize_text_field( $stored_plans[ $plan_cache_key ] );
		}

		$product_id = $this->get_or_create_paypal_product_id_for_form( $context );
		if ( is_wp_error( $product_id ) ) {
			return $product_id;
		}

		$interval_unit  = $this->normalize_interval_unit( $context['recurring_period'] );
		$interval_count = max( 1, (int) $context['interval_count'] );
		$plan_name      = ! empty( $context['plan_name'] ) ? $context['plan_name'] : __( 'Registration Subscription Plan', 'user-registration' );
		$amount_value   = number_format( (float) $context['product_amount'], 2, '.', '' );

		$billing_cycles = array(
			array(
				'frequency'      => array(
					'interval_unit'  => $interval_unit,
					'interval_count' => $interval_count,
				),
				'tenure_type'    => 'REGULAR',
				'sequence'       => 1,
				'total_cycles'   => 0,
				'pricing_scheme' => array(
					'fixed_price' => array(
						'currency_code' => $context['currency'],
						'value'         => $amount_value,
					),
				),
			),
		);

		if ( ! empty( $context['trial_period_enable'] ) ) {
			$trial_interval_unit  = $this->normalize_interval_unit( $context['trial_recurring_period'] );
			$trial_interval_count = max( 1, (int) $context['trial_interval_count'] );

			$billing_cycles = array(
				array(
					'frequency'    => array(
						'interval_unit'  => $trial_interval_unit,
						'interval_count' => $trial_interval_count,
					),
					'tenure_type'  => 'TRIAL',
					'sequence'     => 1,
					'total_cycles' => 1,
				),
				array(
					'frequency'      => array(
						'interval_unit'  => $interval_unit,
						'interval_count' => $interval_count,
					),
					'tenure_type'    => 'REGULAR',
					'sequence'       => 2,
					'total_cycles'   => 0,
					'pricing_scheme' => array(
						'fixed_price' => array(
							'currency_code' => $context['currency'],
							'value'         => $amount_value,
						),
					),
				),
			);
		}

		$plan_payload = array(
			'product_id'          => sanitize_text_field( $product_id ),
			'name'                => sanitize_text_field( $plan_name ),
			'description'         => sanitize_text_field( $plan_name ),
			'status'              => 'ACTIVE',
			'billing_cycles'      => $billing_cycles,
			'payment_preferences' => array(
				'auto_bill_outstanding'     => true,
				'setup_fee_failure_action'  => 'CONTINUE',
				'payment_failure_threshold' => 3,
			),
		);

		$response = $this->paypal_rest_request( 'POST', '/v1/billing/plans', $plan_payload, $context['paypal_options'] );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$plan_id = isset( $response['id'] ) ? $response['id'] : '';
		if ( empty( $plan_id ) ) {
			return new WP_Error(
				'paypal_plan_create_failed',
				__( 'PayPal plan could not be created.', 'user-registration' )
			);
		}

		$stored_plans[ $plan_cache_key ] = sanitize_text_field( $plan_id );
		update_post_meta( $context['form_id'], '_ur_paypal_rest_plan_map', $stored_plans );
		update_post_meta( $context['form_id'], '_ur_paypal_latest_plan_id_rest', sanitize_text_field( $plan_id ) );

		return sanitize_text_field( $plan_id );
	}

	/**
	 * Normalize recurring period to PayPal interval unit.
	 *
	 * @param string $period Period.
	 * @return string
	 */
	private function normalize_interval_unit( $period ) {
		$period = strtoupper( (string) $period );
		if ( in_array( $period, array( 'DAY', 'WEEK', 'MONTH', 'YEAR' ), true ) ) {
			return $period;
		}

		$first = strtoupper( substr( $period, 0, 1 ) );
		switch ( $first ) {
			case 'D':
				return 'DAY';
			case 'W':
				return 'WEEK';
			case 'Y':
				return 'YEAR';
			case 'M':
			default:
				return 'MONTH';
		}
	}

	/**
	 * Get login access.
	 *
	 * Backward-compatible utility method.
	 *
	 * @param string $url URL.
	 * @param string $client_id Client ID.
	 * @param string $client_secret Client secret.
	 * @return array|null
	 */
	public static function get_login_access( $url, $client_id, $client_secret ) {
		try {
			$ch = curl_init();

			curl_setopt( $ch, CURLOPT_URL, $url . 'v1/oauth2/token' );
			curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
			curl_setopt( $ch, CURLOPT_USERPWD, $client_id . ':' . $client_secret );
			curl_setopt( $ch, CURLOPT_POSTFIELDS, 'grant_type=client_credentials' );
			curl_setopt( $ch, CURLOPT_POST, true );

			$response    = curl_exec( $ch );
			$result      = json_decode( $response );
			$status_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );

			curl_close( $ch );

			return array(
				'access_token' => isset( $result->access_token ) ? $result->access_token : '',
				'status_code'  => $status_code,
			);
		} catch ( Exception $e ) {
			$logger = ur_get_logger();
			$logger->error(
				sprintf( 'PayPal login access retrieval failed.' ) . "\n" . $e->getMessage(),
				array(
					'source'   => 'urm-pg-paypal',
					'function' => __FUNCTION__,
				)
			);
		}

		return null;
	}
}

new User_Registration_Pro_PayPal_Standard();
